# CoachCare SDK

Typescript SDK for the CoachCare REST API

## Setting up the project

Clone the project and run:

```bash
yarn install
```

## Generating SDK documentation

To generate the library documentation, run:

```bash
yarn documentation
```

and open `./documentation/index.html` with your browser.

## Testing locally

For some typescript projects that doesn't rely on Webpack it could be enough to symlink

```bash
ln -s ../../sdk/ node_modules/@coachcare/sdk
```

from the project directory, but in Angular the symlinks aren't loaded by Webpack, and the alternative to this problem is
`wix/wml`. [See here](https://github.com/wix/wml) for extra details and documentation.

```bash
sudo npm install -g wml
sudo wml add ./sdk ./your_app/node_modules/@coachcare/sdk
wml start
```

Take in account that `ng serve` seems to cache the node_modules libraries, so it needs to be restarted after a branch
swap that contains new API methods or definitions on it.

## Basic usage and examples

Authentication token container should be created once and shared between different instances of the API service to ensure
consistent handling of authentication process (login, logout, session token maintenance) between all service instances.

```typescript
import { AuthenticationToken, ApiService } from '@coachcare/sdk';

const token = new AuthenticationToken();

const generalService = new ApiService({
    token
});

const restrictedRateLimitService = new ApiService({
    token
});
```

### Throttling

Request throttling/delaying is **disabled** by default and has to be explicitly enabled:

```typescript
const service = new ApiService({
    token,
    throttling: {
        enabled: true
    }
});
```

The general recommendation is to create an instance of API service per a set of routes that have similar rate limits - for example, more restrictive endpoints should have a dedicated API service for access.

Enabling throttling will delay any subsequent requests that are executed right when we're at the rate limit. The rate limit is calculated as requests / second, and is refreshed every second or on every call to the API.

See the definition of `ThrottlingAdapterOptions` for all the available toggles, values and options.

### Short-lived caching

Short lived response caching for identical requests is **enabled** by default, and is an equivalent of:

```typescript
const service = new ApiService({
    token,
    caching: {
        enabled: true
    }
});
```

Caching is enabled for `HEAD`, `GET` and `OPTIONS` requests, and it caches the exact same repeated requests for a short period (3-5 seconds).

This is mostly to avoid the same duplicated calls hitting the server over & over again, while allowing the application components to be independently structured.
