export interface TwilioMobileActivity {
    id: string;
}
