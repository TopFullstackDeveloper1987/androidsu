import { MinimalDataPointType } from '../../providers/measurement/dataPointType';
import { chain } from 'lodash';

export enum SyntheticDataPointTypeId {
    BloodPressure = '-10',
}

export enum DataPointKind {
    Regular,
    Synthetic,
}

export type DataPoint<T, U extends MinimalDataPointType> = T & {
    kind: DataPointKind.Regular;
    type: U;
};

export interface SyntheticDataPoint<T, U extends MinimalDataPointType> {
    kind: DataPointKind.Synthetic;
    sources: DataPoint<T, U>[];
}

export type DataPointLikeEntry<T, U extends MinimalDataPointType> =
    | DataPoint<T, U>
    | SyntheticDataPoint<T, U>;

export interface SyntheticDataPointType {
    id: string;
    sourceTypeIds: string[];
}

export const SYNTHETIC_TYPES: SyntheticDataPointType[] = [
    {
        id: SyntheticDataPointTypeId.BloodPressure,
        sourceTypeIds: ['5', '6'],
    },
];

export function parseWithSyntheticDataPointTypes<
    T,
    U extends MinimalDataPointType = MinimalDataPointType,
>(entries: DataPoint<T, U>[]): DataPointLikeEntry<T, U>[] {
    const typeIdGrouping = chain(entries)
        .groupBy((e) => e.type.id)
        .value();

    const applicableSyntheticTypes = SYNTHETIC_TYPES.filter((t) =>
        t.sourceTypeIds.every((src) => typeIdGrouping[src]),
    );

    return entries.map((entry) => {
        const syntheticData = applicableSyntheticTypes.find((synthetic) =>
            synthetic.sourceTypeIds.includes(entry.type.id),
        );

        if (!syntheticData) {
            return {
                ...entry,
                kind: DataPointKind.Regular,
            };
        }

        const sourceDataPoints = chain(syntheticData.sourceTypeIds)
            .flatMap((src) => typeIdGrouping[src])
            .value();

        const syntheticDataPoint: SyntheticDataPoint<T, U> = {
            kind: DataPointKind.Synthetic,
            sources: sourceDataPoints,
        };

        return syntheticDataPoint;
    });
}
