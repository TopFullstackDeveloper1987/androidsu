import { UserMeasurementPreferenceType } from '../../providers/user/requests/userMeasurementPreference.type';

export type MeasurementUnit = 'g' | 'ppm';

export interface MeasurementUnitConverter {
    convertToReadableFormat(
        value: number,
        measurementPreference: UserMeasurementPreferenceType,
    ): number;

    convertFromReadableFormat(
        value: number,
        measurementPreference: UserMeasurementPreferenceType,
    ): number;

    getMeasurementPreferenceUnit(
        measurementPreference: UserMeasurementPreferenceType,
    ): string;
}

export const MeasurementUnitConversions: {
    [key: string]: MeasurementUnitConverter;
} = {
    /**
     * Unit GRAMS (g)
     *
     * To: g -> kg / lbs
     * From: kg / lbs -> g
     */
    g: {
        convertToReadableFormat: (
            value: number,
            measurementPreference: UserMeasurementPreferenceType,
        ) => {
            switch (measurementPreference) {
                case 'metric':
                    return value / 1000;

                case 'uk':
                case 'us':
                    return value * 0.00220462;
            }
        },
        convertFromReadableFormat: (
            value: number,
            measurementPreference: UserMeasurementPreferenceType,
        ) => {
            switch (measurementPreference) {
                case 'metric':
                    return value * 1000;

                case 'uk':
                case 'us':
                    return value * 453.592;
            }
        },
        getMeasurementPreferenceUnit: (
            measurementPreference: UserMeasurementPreferenceType,
        ) => {
            switch (measurementPreference) {
                case 'metric':
                    return 'kg';

                case 'uk':
                case 'us':
                    return 'lbs';
            }
        },
    },

    /**
     * Unit KILOGRAMS (kg)
     *
     * To: kg -> kg / lbs
     * From: kg / lbs -> kg
     */
    kg: {
        convertToReadableFormat: (
            value: number,
            measurementPreference: UserMeasurementPreferenceType,
        ) => {
            switch (measurementPreference) {
                case 'metric':
                    return value;

                case 'uk':
                case 'us':
                    return value * 2.20462;
            }
        },
        convertFromReadableFormat: (
            value: number,
            measurementPreference: UserMeasurementPreferenceType,
        ) => {
            switch (measurementPreference) {
                case 'metric':
                    return value;

                case 'uk':
                case 'us':
                    return value * 0.453592;
            }
        },
        getMeasurementPreferenceUnit: (
            measurementPreference: UserMeasurementPreferenceType,
        ) => {
            switch (measurementPreference) {
                case 'metric':
                    return 'kg';

                case 'uk':
                case 'us':
                    return 'lbs';
            }
        },
    },

    /**
     * Unit METERS (m)
     *
     * To: m -> km / mi
     * From: km / mi -> m
     */
    m: {
        convertToReadableFormat: (
            value: number,
            measurementPreference: UserMeasurementPreferenceType,
        ) => {
            switch (measurementPreference) {
                case 'uk':
                case 'metric':
                    return value / 1000;

                case 'us':
                    return value * 0.000621371;
            }
        },
        convertFromReadableFormat: (
            value: number,
            measurementPreference: UserMeasurementPreferenceType,
        ) => {
            switch (measurementPreference) {
                case 'uk':
                case 'metric':
                    return value * 1000;

                case 'us':
                    return value * 1609.34;
            }
        },
        getMeasurementPreferenceUnit: (
            measurementPreference: UserMeasurementPreferenceType,
        ) => {
            switch (measurementPreference) {
                case 'uk':
                case 'metric':
                    return 'km';

                case 'us':
                    return 'mi';
            }
        },
    },

    /**
     * Unit MILLIMETERS (mm)
     *
     * To: mm -> mm / in
     * From: mm / in -> mm
     */
    mm: {
        convertToReadableFormat: (
            value: number,
            measurementPreference: UserMeasurementPreferenceType,
        ) => {
            switch (measurementPreference) {
                case 'metric':
                    return value;

                case 'uk':
                case 'us':
                    return value * 0.0393701;
            }
        },
        convertFromReadableFormat: (
            value: number,
            measurementPreference: UserMeasurementPreferenceType,
        ) => {
            switch (measurementPreference) {
                case 'metric':
                    return value;

                case 'uk':
                case 'us':
                    return value * 25.4;
            }
        },
        getMeasurementPreferenceUnit: (
            measurementPreference: UserMeasurementPreferenceType,
        ) => {
            switch (measurementPreference) {
                case 'metric':
                    return 'mm';

                case 'uk':
                case 'us':
                    return 'in';
            }
        },
    },

    /**
     * Unit MILLIMETERS (mmCm)
     *
     * To: mm -> cm / in
     * From: cm /in -> mm
     */
    mmCm: {
        convertToReadableFormat: (
            value: number,
            measurementPreference: UserMeasurementPreferenceType,
        ) => {
            switch (measurementPreference) {
                case 'metric':
                    return value / 10;

                case 'uk':
                case 'us':
                    return value * 0.0393701;
            }
        },
        convertFromReadableFormat: (
            value: number,
            measurementPreference: UserMeasurementPreferenceType,
        ) => {
            switch (measurementPreference) {
                case 'metric':
                    return value * 10;

                case 'uk':
                case 'us':
                    return value * 25.4;
            }
        },
        getMeasurementPreferenceUnit: (
            measurementPreference: UserMeasurementPreferenceType,
        ) => {
            switch (measurementPreference) {
                case 'metric':
                    return 'cm';

                case 'uk':
                case 'us':
                    return 'in';
            }
        },
    },

    /**
     * Unit MILLILITERS (ml)
     *
     * To: ml -> l / oz
     * From: l / oz -> ml
     */
    ml: {
        convertToReadableFormat: (
            value: number,
            measurementPreference: UserMeasurementPreferenceType,
        ) => {
            switch (measurementPreference) {
                case 'uk':
                case 'metric':
                    return value / 1000;

                case 'us':
                    return value * 0.033814;
            }
        },
        convertFromReadableFormat: (
            value: number,
            measurementPreference: UserMeasurementPreferenceType,
        ) => {
            switch (measurementPreference) {
                case 'uk':
                case 'metric':
                    return value * 1000;

                case 'us':
                    return value * 29.5735;
            }
        },
        getMeasurementPreferenceUnit: (
            measurementPreference: UserMeasurementPreferenceType,
        ) => {
            switch (measurementPreference) {
                case 'uk':
                case 'metric':
                    return 'l';

                case 'us':
                    return 'oz';
            }
        },
    },

    /**
     * Unit CELSIUS (C)
     *
     * To: C -> C / F
     * From: C / F -> C
     */
    C: {
        convertToReadableFormat: (
            value: number,
            measurementPreference: UserMeasurementPreferenceType,
        ) => {
            switch (measurementPreference) {
                case 'uk':
                case 'metric':
                    return value;

                case 'us':
                    return value * (9 / 5) + 32;
            }
        },
        convertFromReadableFormat: (
            value: number,
            measurementPreference: UserMeasurementPreferenceType,
        ) => {
            switch (measurementPreference) {
                case 'uk':
                case 'metric':
                    return value;

                case 'us':
                    return (value - 32) * (5 / 9);
            }
        },
        getMeasurementPreferenceUnit: (
            measurementPreference: UserMeasurementPreferenceType,
        ) => {
            switch (measurementPreference) {
                case 'uk':
                case 'metric':
                    return 'C';

                case 'us':
                    return 'F';
            }
        },
    },

    /**
     * Unit SECONDS (s)
     *
     * To: s -> m
     * From: m -> s
     */
    s: {
        convertToReadableFormat: (value: number) => {
            return Math.floor(value / 60);
        },
        convertFromReadableFormat: (value: number) => {
            return value * 60;
        },
        getMeasurementPreferenceUnit: () => {
            return 'm';
        },
    },
};
