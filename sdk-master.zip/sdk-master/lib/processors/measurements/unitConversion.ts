import { MeasurementUnitConverter } from './unit';
import { UNIT_TRANSLATIONS_MAP } from './unit-translations.map';
import { MeasurementDataPointMinimalType } from '../../providers/measurement/dataPoint';
import { UserMeasurementPreferenceType } from '../../providers/user/requests/userMeasurementPreference.type';
import { DataPointTypes } from './data-types';
import { MeasurementUnitConversions } from './unit';

export function convertToReadableFormat(
    quantity: number,
    type: MeasurementDataPointMinimalType,
    measurementPreference: UserMeasurementPreferenceType,
): number {
    const scaledQuantity = quantity / type.multiplier;

    switch (type.id) {
        case DataPointTypes.WAIST_CIRCUMFERENCE:
        case DataPointTypes.ARM_CIRCUMFERENCE:
        case DataPointTypes.HIP_CIRCUMFERENCE:
        case DataPointTypes.CHEST_CIRCUMFERENCE:
        case DataPointTypes.THIGH_CIRCUMFERENCE:
        case DataPointTypes.NECK_CIRCUMFERENCE:
        case DataPointTypes.THORAX_CIRCUMFERENCE:
            return (
                MeasurementUnitConversions['mmCm']?.convertToReadableFormat(
                    scaledQuantity,
                    measurementPreference,
                ) ?? scaledQuantity
            );

        case DataPointTypes.VISCERAL_ADIPOSE_TISSUE:
            return (
                MeasurementUnitConversions[
                    type.unit?.symbol ?? ''
                ]?.convertToReadableFormat(scaledQuantity, 'metric') ??
                scaledQuantity
            );
    }

    return (
        MeasurementUnitConversions[
            type.unit?.symbol ?? ''
        ]?.convertToReadableFormat(scaledQuantity, measurementPreference) ??
        scaledQuantity
    );
}

export function convertFromReadableFormat(
    quantity: number,
    type: MeasurementDataPointMinimalType,
    measurementPreference: UserMeasurementPreferenceType,
): number {
    const scaledQuantity = quantity * type.multiplier;

    switch (type.id) {
        case DataPointTypes.WAIST_CIRCUMFERENCE:
        case DataPointTypes.ARM_CIRCUMFERENCE:
        case DataPointTypes.HIP_CIRCUMFERENCE:
        case DataPointTypes.CHEST_CIRCUMFERENCE:
        case DataPointTypes.THIGH_CIRCUMFERENCE:
        case DataPointTypes.NECK_CIRCUMFERENCE:
        case DataPointTypes.THORAX_CIRCUMFERENCE:
            return (
                MeasurementUnitConversions['mmCm']?.convertFromReadableFormat(
                    scaledQuantity,
                    measurementPreference,
                ) ?? scaledQuantity
            );

        case DataPointTypes.VISCERAL_ADIPOSE_TISSUE:
            return (
                MeasurementUnitConversions[
                    type.unit?.symbol ?? ''
                ]?.convertFromReadableFormat(scaledQuantity, 'metric') ??
                scaledQuantity
            );
        case DataPointTypes.TEMPERATURE:
            return (
                MeasurementUnitConversions[
                    type.unit?.symbol ?? ''
                ]?.convertFromReadableFormat(quantity, measurementPreference) *
                    type.multiplier ?? scaledQuantity
            );
    }

    return (
        MeasurementUnitConversions[
            type.unit?.symbol ?? ''
        ]?.convertFromReadableFormat(scaledQuantity, measurementPreference) ??
        scaledQuantity
    );
}

export function convertUnitToPreferenceFormat(
    type: MeasurementDataPointMinimalType,
    measurementPreference: UserMeasurementPreferenceType,
    lang = 'en',
): string {
    const cleanLang = lang.split('-')[0].toLowerCase();

    let unit: string;
    let converter: MeasurementUnitConverter;

    switch (type.id) {
        case DataPointTypes.WAIST_CIRCUMFERENCE:
        case DataPointTypes.ARM_CIRCUMFERENCE:
        case DataPointTypes.HIP_CIRCUMFERENCE:
        case DataPointTypes.CHEST_CIRCUMFERENCE:
        case DataPointTypes.THIGH_CIRCUMFERENCE:
        case DataPointTypes.NECK_CIRCUMFERENCE:
        case DataPointTypes.THORAX_CIRCUMFERENCE:
            converter = MeasurementUnitConversions['mmCm'];
            unit =
                converter?.getMeasurementPreferenceUnit(
                    measurementPreference,
                ) ?? type.unit?.symbol;
            break;

        case DataPointTypes.VISCERAL_ADIPOSE_TISSUE:
            converter = MeasurementUnitConversions[type.unit?.symbol ?? ''];
            unit =
                converter?.getMeasurementPreferenceUnit('metric') ??
                type.unit?.symbol;
            break;

        default:
            converter = MeasurementUnitConversions[type.unit?.symbol ?? ''];
            unit =
                converter?.getMeasurementPreferenceUnit(
                    measurementPreference,
                ) ?? type.unit?.symbol;
            break;
    }

    return UNIT_TRANSLATIONS_MAP[cleanLang] &&
        UNIT_TRANSLATIONS_MAP[cleanLang][unit]
        ? UNIT_TRANSLATIONS_MAP[cleanLang][unit]
        : unit;
}
