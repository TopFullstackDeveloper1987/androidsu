/**
 * Type Interface for api environment
 */

export type Environment = 'ccrDemo' | 'dev' | 'prod' | 'test';
