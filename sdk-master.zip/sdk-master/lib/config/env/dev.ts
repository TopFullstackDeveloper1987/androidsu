import { PartialConfig } from '../interfaces';

export const config: PartialConfig = {
    apiUrl: 'https://api.coachcare.loc/',
};
