import { Config } from '../interfaces';

export const config: Config = {
    apiUrl: 'https://test.api.coachcare.com/',
};
