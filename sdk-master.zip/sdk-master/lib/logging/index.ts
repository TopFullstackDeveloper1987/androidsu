import axios, { AxiosAdapter, AxiosInstance } from 'axios';
import { EMPTY, mergeMap, Observable, Subject } from 'rxjs';

export type LogLevel = 'trace' | 'debug' | 'info' | 'warn' | 'error' | 'fatal';

type LogLevelLookup = Readonly<Record<LogLevel, number>>;

const LOG_LEVEL_NUMBER: LogLevelLookup = Object.freeze({
    trace: 10,
    debug: 20,
    info: 30,
    warn: 40,
    error: 50,
    fatal: 60,
});

/**
 * This value has to match our 'boundary regexp' in Sumologic HTTP source, which is managed in Terraform
 */
const DEFAULT_MULTILINE_DELIMETER = '\r';

export interface LoggerOptions {
    /**
     * Logger name
     */
    readonly name: string;

    /**
     * Minimum log level to record
     */
    readonly minimumLogLevel?: LogLevel | 'off';

    /**
     * Tags that should be applied to the whole logger instance
     */
    readonly tags?: Record<string, unknown>;

    /**
     * Enables or disables diagnostic notification emission
     *
     * @default true
     */
    readonly emitDiagnosticNotifications?: boolean;

    /**
     * Indicates a delimeter used for multiline log processing
     * This value has to match our 'boundary regexp' in Sumologic HTTP source, which is managed in Terraform
     */
    readonly multilineDelimiter?: string;
}

export type SumologicLoggerOptions = LoggerOptions & {
    /**
     * Sumologic collector URL
     */
    readonly url: string;
};

/**
 * Structured log data
 */
export type StructuredLogData = {
    /**
     * Error to capture
     */
    readonly error?: Error;

    /**
     * Log message
     */
    readonly message: string;

    /**
     * Data properties & tags to include in the structured log
     */
    readonly tags?: Record<string, unknown>;
};

export type DiagnosticEvent = {
    readonly timestamp: Date;
    readonly action: 'dispatch' | 'skip';
    readonly level: LogLevel;
    readonly data: Record<string, unknown>;
};

/**
 * Allows to dispose underlying resources on demand
 */
export interface Disposable {
    /**
     * Releases underlying resources
     */
    dispose(): void;
}

export interface LoggerMetadata extends Disposable {
    /**
     * Indicates if a given log level is enabled
     * @param level Log level
     */
    isEnabled(level: LogLevel): boolean;

    /**
     * Logger options
     */
    readonly options: LoggerOptions;

    /**
     * A stream of of diagnostic log events
     */
    readonly event$: Observable<DiagnosticEvent>;
}

/**
 * An error thrown when a log message cannot be dispatched to a remote collector
 */
export class LogDispatchError extends Error {
    public constructor(
        public readonly error: Error,
        public readonly data: StructuredLogData,
        public readonly level: LogLevel,
        public readonly options: LoggerOptions,
    ) {
        super('Failed to dispatch a log message');
    }
}

/**
 * Asynchronous logging function
 */
type AsyncLogFunction = (data: StructuredLogData) => Promise<void>;

/**
 * Synchronous logging function
 */
type LogFunction = (data: StructuredLogData) => void;

type AsyncLogMethods = {
    readonly [P in LogLevel]: AsyncLogFunction;
};

type LogMethods = {
    readonly [P in LogLevel]: LogFunction;
};

/**
 * Asynchronous logger
 */
export interface AsyncLogger extends LoggerMetadata, AsyncLogMethods {
    /**
     * Creates a child logger with a predefined set of tags
     * @param tags Tag definitions
     * @returns {AsyncLogger} A new logger instance
     */
    child(tags: Record<string, unknown>): AsyncLogger;
}

/**
 * Synchronous logger
 */
export interface Logger extends LoggerMetadata, LogMethods {
    /**
     * Creates a child logger with a predefined set of tags
     * @param tags Tag definitions
     * @returns {Logger} A new logger instance
     */
    child(tags: Record<string, unknown>): Logger;
}

/**
 * Async logger that sends the log messages to Sumologic
 */
export class SumologicLogger implements AsyncLogger {
    private readonly httpClient: AxiosInstance;
    private readonly logLevelLookup: Partial<LogLevelLookup>;
    private readonly diagnostics$: Subject<DiagnosticEvent> | undefined;
    private readonly delimiter: string;
    private readonly adapter: AxiosAdapter | undefined;

    public get event$() {
        return this.diagnostics$?.asObservable() ?? EMPTY;
    }

    public constructor(
        public readonly options: SumologicLoggerOptions,
        adapter?: AxiosAdapter,
    ) {
        const {
            minimumLogLevel = 'info',
            emitDiagnosticNotifications: enableDiagnosticNotifications = true,
            multilineDelimiter = DEFAULT_MULTILINE_DELIMETER,
        } = options;
        const cutoff =
            minimumLogLevel === 'off'
                ? Number.MAX_SAFE_INTEGER
                : LOG_LEVEL_NUMBER[minimumLogLevel];
        this.delimiter = multilineDelimiter;
        this.logLevelLookup = Object.entries(LOG_LEVEL_NUMBER)
            .filter(([, value]) => value >= cutoff)
            .reduce(
                (lookup, [key, value]) => ({
                    ...lookup,
                    [key]: value,
                }),
                {},
            );

        this.diagnostics$ = enableDiagnosticNotifications
            ? new Subject<DiagnosticEvent>()
            : undefined;
        this.adapter = adapter;
        this.httpClient = axios.create({
            adapter: this.adapter,
            headers: {
                'Content-Type': 'application/json',
            },
        });
    }
    dispose(): void {
        this.diagnostics$?.complete();
        this.diagnostics$?.unsubscribe();
    }

    isEnabled(level: LogLevel): boolean {
        return this.logLevelLookup[level] !== undefined;
    }

    public child(tags: Record<string, unknown>): AsyncLogger {
        return new SumologicLogger(
            {
                ...this.options,
                tags: {
                    ...this.options.tags,
                    ...tags,
                },
            },
            this.adapter,
        );
    }

    private async dispatch(
        level: LogLevel,
        data: StructuredLogData,
    ): Promise<void> {
        const numericLevel = this.logLevelLookup[level];
        if (numericLevel === undefined) {
            this.diagnostics$?.next({
                data,
                level,
                timestamp: new Date(),
                action: 'skip',
            });
            return;
        }

        try {
            const rawTimestamp = Date.now();
            const timestamp = new Date(rawTimestamp);
            const request = {
                ...this.options.tags,
                ...data.tags,
                level: numericLevel,
                level_name: level,
                msg: data.message,
                err:
                    data.error !== undefined
                        ? {
                              name: data.error.name,
                              message: data.error.message,
                              stack:
                                  data.error.stack
                                      ?.split('\n')
                                      ?.map((line) => line.trim()) ?? [],
                          }
                        : undefined,
                name: this.options.name,
                time: rawTimestamp,
            };
            this.diagnostics$?.next({
                data: request,
                level,
                timestamp,
                action: 'dispatch',
            });
            await this.httpClient.post(
                this.options.url,
                /*
                    This looks odd, but otherwise Sumologic seems to drop requests if we do 'one log per request' with raw JSON.
                    We can easily serialize JSON on our own, and then add the delimiter at the end to indicate that it's the "end of the log line"
                    It also leaves us an option to batch a few JSON log lines together in one request
                */
                JSON.stringify(request) + this.delimiter,
            );
        } catch (error) {
            throw new LogDispatchError(
                error as Error,
                data,
                level,
                this.options,
            );
        }
    }

    /**
     * @throws LogDispatchError
     */
    public trace(data: StructuredLogData): Promise<void> {
        return this.dispatch('trace', data);
    }

    /**
     * @throws LogDispatchError
     */
    public debug(data: StructuredLogData): Promise<void> {
        return this.dispatch('debug', data);
    }

    /**
     * @throws LogDispatchError
     */
    public info(data: StructuredLogData): Promise<void> {
        return this.dispatch('info', data);
    }

    /**
     * @throws LogDispatchError
     */
    public warn(data: StructuredLogData): Promise<void> {
        return this.dispatch('warn', data);
    }

    /**
     * @throws LogDispatchError
     */
    public error(data: StructuredLogData): Promise<void> {
        return this.dispatch('error', data);
    }

    /**
     * @throws LogDispatchError
     */
    public fatal(data: StructuredLogData): Promise<void> {
        return this.dispatch('fatal', data);
    }
}

/**
 * A logger that dispatches the log messages to be processed in the background.
 * Error notifications will also be emitted asynchronously using the `error$` observable stream
 */
export class BackgroundDispatchLogger implements Logger {
    private readonly dispatchErrorSubject$ = new Subject<LogDispatchError>();
    private readonly dispatchQueue$ = new Subject<
        [StructuredLogData, LogLevel]
    >();

    public get options() {
        return this.logger.options;
    }

    public constructor(
        /**
         * Underlying asynchronous logger
         */
        private readonly logger: AsyncLogger,
        /**
         * Indicates how many log messages can be processed concurrently in the background.
         * Setting it to a value larger than `1` may cause the logs to be processed out of order, but at a higher throughput.
         */
        private readonly concurrency = 1,
    ) {
        this.dispatchQueue$
            .pipe(
                mergeMap(async ([data, level]) => {
                    try {
                        await this.logger[level](data);
                        return;
                    } catch (error) {
                        return error;
                    }
                }, concurrency),
            )
            .subscribe((failure) => {
                if (!(failure instanceof LogDispatchError)) {
                    return;
                }

                this.dispatchErrorSubject$.next(failure);
            });
    }

    public get event$() {
        return this.logger.event$;
    }

    dispose(): void {
        this.dispatchErrorSubject$.complete();
        this.dispatchErrorSubject$.unsubscribe();
        this.dispatchQueue$.complete();
        this.dispatchQueue$.unsubscribe();
        this.logger.dispose();
    }

    /**
     * A notification stream of internal dispatch errors
     */
    public get dispatchError(): Observable<LogDispatchError> {
        return this.dispatchErrorSubject$.asObservable();
    }

    child(tags: Record<string, unknown>): Logger {
        return new BackgroundDispatchLogger(
            this.logger.child(tags),
            this.concurrency,
        );
    }

    isEnabled(level: LogLevel): boolean {
        return this.logger.isEnabled(level);
    }

    public trace(data: StructuredLogData): void {
        this.dispatchQueue$.next([data, 'trace']);
    }

    public debug(data: StructuredLogData): void {
        this.dispatchQueue$.next([data, 'debug']);
    }

    public info(data: StructuredLogData): void {
        this.dispatchQueue$.next([data, 'info']);
    }

    public warn(data: StructuredLogData): void {
        this.dispatchQueue$.next([data, 'warn']);
    }

    public error(data: StructuredLogData): void {
        this.dispatchQueue$.next([data, 'error']);
    }

    public fatal(data: StructuredLogData): void {
        this.dispatchQueue$.next([data, 'fatal']);
    }
}
