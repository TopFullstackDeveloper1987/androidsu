// eslint-disable-next-line @typescript-eslint/ban-types
export type DeepPartial<T> = T extends Function
    ? T
    : // eslint-disable-next-line @typescript-eslint/ban-types
      T extends object
      ? { [P in keyof T]?: DeepPartial<T[P]> }
      : T;
