export interface DiagnosticMessage {
    /**
     * Diagnostic message
     */
    readonly message: string;
    /**
     * Severity of the message
     */
    readonly severity: 'trace' | 'debug' | 'info' | 'warn' | 'error';
}
