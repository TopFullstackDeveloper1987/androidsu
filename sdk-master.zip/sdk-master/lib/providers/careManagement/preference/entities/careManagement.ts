import { Entity, NamedEntity } from '../../../common/entities';
import { CareManagementServiceType } from '../../management/entities';
import { CareManagementType } from './careManagementType';

/**
 * Care Management Organization Preference
 */
export interface CareManagementOrganizationPreference {
    id: string;
    organization: Entity;
    isActive: boolean;
    serviceType: CareManagementServiceType;
    isSubscriptionTarget: boolean;
    deviceSetupNotification: 'enabled' | 'disabled';
    automatedTimeTracking: 'enabled' | 'disabled';
    taxIdentificationNumber?: string;
    billing: CareManagementType;
    monitoring: CareManagementType;
    dataTransmissionTypes: NamedEntity[];
    plans: {
        id: string;
        name: string;
        device: {
            name: string;
        };
    }[];
}
