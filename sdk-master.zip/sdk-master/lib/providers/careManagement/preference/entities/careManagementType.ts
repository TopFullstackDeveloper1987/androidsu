export type CareManagementType = 'managed' | 'self-service';
