import { CareManagementOrganizationPreference } from '../entities/careManagement';

export interface GetAllCareManagementPreferencesResponse {
    data: Array<CareManagementOrganizationPreference>;
}
