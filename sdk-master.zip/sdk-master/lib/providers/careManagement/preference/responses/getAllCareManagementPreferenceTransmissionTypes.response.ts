export interface CareManagementTransmissionType {
    id: number;
    name: string;
    createdAt: string;
    status: 'active' | 'inactive';
}

export interface CareManagementTransmissionTypesResponse {
    data: Array<CareManagementTransmissionType>;
}
