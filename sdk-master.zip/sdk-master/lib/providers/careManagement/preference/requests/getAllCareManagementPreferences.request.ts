/**
 * Interface for GET /care-management/preference/organization
 */

export interface GetAllCareManagementPreferencesRequest {
    organization: string;
    serviceType?: string;
}
