/**
 * Interface for GET /care-management/preference/data-transmission/type
 */

export interface GetAllCareManagementTransmissionTypesRequest {
    status?: 'active' | 'inactive' | 'all';
    limit?: number;
    offset?: number;
}
