/**
 * Interface for POST /care-management/preference/organization
 */

import { CareManagementType } from '../entities';

export interface CreateCareManagementPreferenceRequest {
    organization: string;
    isActive: boolean;
    serviceType: string;
    isSubscriptionTarget?: boolean;
    taxIdentificationNumber?: string;
    deviceSetupNotification?: 'enabled' | 'disabled';
    automatedTimeTracking?: 'enabled' | 'disabled';
    billing?: CareManagementType;
    monitoring?: CareManagementType;
    dataTransmissionTypes?: number[];
    plans?: number[];
}
