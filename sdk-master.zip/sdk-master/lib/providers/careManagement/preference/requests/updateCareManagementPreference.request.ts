/**
 * Interface for PATCH /care-management/preference/organization/:id
 */

import { CareManagementType } from '../entities';

export interface UpdateCareManagementPreferenceRequest {
    id: string;
    isActive?: boolean;
    isSubscriptionTarget?: boolean;
    taxIdentificationNumber?: string;
    deviceSetupNotification?: 'enabled' | 'disabled';
    automatedTimeTracking?: 'enabled' | 'disabled';
    billing?: CareManagementType;
    monitoring?: CareManagementType;
    dataTransmissionTypes?: number[];
    plans?: number[];
}
