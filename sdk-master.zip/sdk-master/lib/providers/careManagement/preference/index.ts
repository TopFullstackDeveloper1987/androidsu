import { ApiService } from '../../../services';
import { Entity } from '../../common/entities';
import { CareManagementOrganizationPreference } from './entities/careManagement';
import {
    CreateCareManagementPreferenceRequest,
    GetAllCareManagementPreferencesRequest,
    UpdateCareManagementPreferenceRequest,
} from './requests';
import { GetAllCareManagementTransmissionTypesRequest } from './requests/getAllCareManagementPreferencesTransmissionTypes.request';
import { GetAllCareManagementPreferencesResponse } from './responses';
import { CareManagementTransmissionTypesResponse } from './responses/getAllCareManagementPreferenceTransmissionTypes.response';

/**
 * Care management preference provider service
 */
export class CareManagementPreference {
    public constructor(private readonly apiService: ApiService) {}

    /**
     * Creates a new care management service preference for an organization
     * @param request must implement CreateCareManagementPreferenceRequest
     * @returns Promise<Entity>
     */
    public createCareManagementPreference(
        request: CreateCareManagementPreferenceRequest,
    ): Promise<Entity> {
        return this.apiService.request({
            data: request,
            endpoint: `/care-management/preference/organization`,
            method: 'POST',
            version: '1.0',
        });
    }

    /**
     * Updates a care management service preference
     * @param request must implement UpdateCareManagementPreferenceRequest
     * @returns Promise<void>
     */
    public updateCareManagementPreference(
        request: UpdateCareManagementPreferenceRequest,
    ): Promise<void> {
        return this.apiService.request({
            data: request,
            endpoint: `/care-management/preference/organization/${request.id}`,
            method: 'PATCH',
            version: '1.0',
        });
    }

    /**
     * Removes a care management service preference
     * @param id must implement string
     * @returns Promise<void>
     */
    public deleteCareManagementPreference(id: string): Promise<void> {
        return this.apiService.request({
            endpoint: `/care-management/preference/organization/${id}`,
            method: 'DELETE',
            version: '1.0',
        });
    }

    /**
     * Retrieves all care management organization preferences per service type in a given organization's hierarchy
     * @param request must implement GetAllCareManagementPreferencesRequest
     * @returns Promise<GetAllCareManagementPreferencesResponse>
     */
    public getAllCareManagementPreferences(
        request: GetAllCareManagementPreferencesRequest,
    ): Promise<GetAllCareManagementPreferencesResponse> {
        return this.apiService.request({
            data: request,
            endpoint: `/care-management/preference/organization`,
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Retrieves a care management organization preference by ID
     * @param id must implement string
     * @returns Promise<CareManagementOrganizationPreference>
     */
    public getCareManagementPreferenceSingle(
        id: string,
    ): Promise<CareManagementOrganizationPreference> {
        return this.apiService.request({
            endpoint: `/care-management/preference/organization/${id}`,
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Retrieves a data transmission type collection to be used with the organization preferences
     * @returns Promise<CareManagementTransmissionTypesResponse>
     */

    public getCareManagementPreferenceTransmissionTypes(
        request: GetAllCareManagementTransmissionTypesRequest,
    ): Promise<CareManagementTransmissionTypesResponse> {
        return this.apiService.request({
            data: request,
            endpoint: `/care-management/preference/data-transmission/type`,
            method: 'GET',
            version: '1.0',
        });
    }
}
