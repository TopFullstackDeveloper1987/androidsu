/**
 * CareManagementDiagnosis
 */

export interface CareManagementDiagnosis {
    primary: string;
    secondary?: string;
    other?: string;
}
