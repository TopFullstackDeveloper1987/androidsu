import { AccountFullData, AccountRef } from '../../../account/entities';
import { Entity } from '../../../common/entities';
import { CareManagementServiceType } from '../../management/entities';
import { CareManagementStateConditions } from './conditions';
import { CareManagementDiagnosis } from './diagnosis';
import { CareManagementPlan } from './plan';
import { CareManagementStateReason } from './reason';

/**
 * Care Management State
 */
export interface CareManagementStateEntity {
    account: Entity;
    conditions: CareManagementStateConditions;
    createdAt: string;
    createdBy: AccountFullData;
    id: string;
    isActive: boolean;
    note?: string;
    organization: Entity;
    plan?: CareManagementPlan;
    reason?: CareManagementStateReason;
    targetDeactivationDate?: string;
    startedAt?: string;
    supervisingProvider?: AccountRef;
    diagnosis?: CareManagementDiagnosis;
    serviceType: CareManagementServiceType;
}
