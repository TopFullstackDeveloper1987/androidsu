import { AccountRef } from '../../../account/entities';
import { Entity } from '../../../common/entities';

export interface CareManagementStateDiagnosisAuditNote {
    current?: string;
    previous?: string;
}

export interface CareManagementStateDiagnosisAuditEntry {
    account: AccountRef;
    createdAt?: string;
    note?: string;
    primary: CareManagementStateDiagnosisAuditNote;
    secondary?: CareManagementStateDiagnosisAuditNote;
    other?: CareManagementStateDiagnosisAuditNote;
    state: Entity;
}
