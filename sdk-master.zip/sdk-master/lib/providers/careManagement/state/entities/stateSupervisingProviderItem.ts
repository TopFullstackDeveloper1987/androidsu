import { Entity } from '../../../common/entities';

interface SupervisingProviderInfo extends Entity {
    firstName: string;
    lastName: string;
}

export interface CareManagementStateSupervisingProviderItem {
    id: number;
    changedAt: string;
    note: string;
    state: {
        id: number;
    };
    changedBy: SupervisingProviderInfo;
    current: SupervisingProviderInfo;
    previous?: SupervisingProviderInfo;
}
