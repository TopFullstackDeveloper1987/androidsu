export type CareManagementStatus = 'active' | 'inactive' | 'all';
