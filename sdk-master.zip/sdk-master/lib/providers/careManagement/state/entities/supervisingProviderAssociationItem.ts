import { AccountRef } from '../../../account/entities';
import { NamedEntity } from '../../../common/entities';

export interface CareManagementSupervisingProviderAssociationItem {
    id: string;
    account: AccountRef;
    organization: NamedEntity;
}
