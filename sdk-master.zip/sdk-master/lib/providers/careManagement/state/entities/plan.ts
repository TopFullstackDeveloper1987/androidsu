/**
 * Care Management Plan
 */

export interface CareManagementPlan {
    id: string;
    name: string;
    isActive: boolean;
    dataPointTypes: number[];
}
