/**
 * Care Management State Conditions
 */
export interface CareManagementStateConditions {
    goalsSet: boolean;
    hadFaceToFace: boolean;
    hasMedicalNecessity: boolean;
    patientConsented: boolean;
    receivedDevice?: boolean;
}
