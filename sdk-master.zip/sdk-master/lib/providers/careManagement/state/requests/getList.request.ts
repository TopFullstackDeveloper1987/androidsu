/**
 * Interface for GET /care-management/state
 */

import { CareManagementStatus } from '../entities';

export interface GetCareManagementStateListRequest {
    account: string;
    asOf?: string;
    limit?: number | 'all';
    offset?: number;
    organization: string;
    reason?: string;
    strict?: boolean;
    status?: CareManagementStatus;
    serviceType?: string;
}
