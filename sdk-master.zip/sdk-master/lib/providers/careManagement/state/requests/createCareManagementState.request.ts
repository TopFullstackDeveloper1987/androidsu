import {
    CareManagementDiagnosis,
    CareManagementStateConditions,
} from '../entities';

/**
 * Interface for POST /care-management/state
 */
interface StateRequest {
    account: string;
    organization: string;
    serviceType: string;
    note?: string;
}

type ActiveStateCreationRequest = StateRequest & {
    isActive: true;
    conditions: CareManagementStateConditions;
    diagnosis: CareManagementDiagnosis;
    plan: string | null;
    supervisingProvider: string;
    targetDeactivationDate?: string;
};

type InactiveStateCreationRequest = StateRequest & {
    isActive: false;
    conditions?: CareManagementStateConditions;
    reason: string;
    note?: string;
};

export type CreateCareManagementStateRequest =
    | ActiveStateCreationRequest
    | InactiveStateCreationRequest;
