/**
 * Interface for POST /care-management/supervising-provider
 */

export interface AddCareManagementStateSupervisingProviderRequest {
    account: string;
    organization: string;
}
