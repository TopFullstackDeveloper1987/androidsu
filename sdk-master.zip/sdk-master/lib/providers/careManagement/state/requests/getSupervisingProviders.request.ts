/**
 * Interface for GET /care-management/supervising-provider
 */

export interface GetCareManagementSupervisingProvidersRequest {
    organization: string;
    limit?: number | 'all';
    offset?: number;
    query?: string;
}
