/**
 * Interface for GET /care-management/state/audit
 */
export interface GetCareManagementStateAuditListRequest {
    account: string;
    asOf?: string;
    limit?: number | 'all';
    offset?: number;
    organization: string;
    strict?: boolean;
    reason?: string;
    status?: 'active' | 'inactive' | 'all';
}
