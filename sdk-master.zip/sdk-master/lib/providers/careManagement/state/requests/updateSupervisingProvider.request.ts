/**
 * Interface for POST /care-management/state/${state}/supervising-provider
 */

export interface UpdateCareManagementStateSupervisingProviderRequest {
    account: string;
    note: string;
}
