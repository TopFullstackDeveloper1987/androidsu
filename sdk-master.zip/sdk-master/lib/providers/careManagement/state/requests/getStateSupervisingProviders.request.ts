/**
 * Interface for GET /v1/care-management/state/{state}/supervising-provider/audit
 */

export interface GetCareManagementStateSupervisingProvidersRequest {
    state: string;
    limit?: number | 'all';
    offset?: number;
}
