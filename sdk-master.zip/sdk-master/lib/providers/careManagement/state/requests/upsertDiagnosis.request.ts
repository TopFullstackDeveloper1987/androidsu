/**
 * Interface for PUT /care-management/state/:id/diagnosis
 */

export interface UpsertDiagnosisRequest {
    id: string;
    /** A note indicating why the diagnosis is being changed. Required for audited updates, discarded otherwise. */
    note?: string;
    primary: string;
    secondary?: string;
    other?: string;
}
