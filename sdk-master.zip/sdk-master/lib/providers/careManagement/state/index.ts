import { ApiService } from '../../../services';
import { Entity, PagedResponse } from '../../common/entities';
import {
    CareManagementStateDiagnosisAuditEntry,
    CareManagementStateEntity,
    CareManagementStateReason,
    CareManagementStateSupervisingProviderItem,
    CareManagementSupervisingProviderAssociationItem,
} from './entities';

import {
    GetCareManagementStateAuditListRequest,
    GetCareManagementStateListRequest,
    UpdateCareManagementStateSupervisingProviderRequest,
    GetCareManagementStateSupervisingProvidersRequest,
    CreateCareManagementStateRequest,
    GetCareManagementReasonsRequest,
    UpsertDiagnosisRequest,
    AddCareManagementStateSupervisingProviderRequest,
    GetCareManagementSupervisingProvidersRequest,
} from './requests';

/**
 * Care management state provider service
 */
export class CareManagementState {
    public constructor(private readonly apiService: ApiService) {}

    /**
     * Adds a supervising provider with a given account ID to the supervising provider list for an organization.
     * @param request must implement AddCareManagementStateSupervisingProviderRequest
     * @returns Promise<void>
     */
    public addSupervisingProvider(
        request: AddCareManagementStateSupervisingProviderRequest,
    ): Promise<Entity> {
        return this.apiService.request({
            data: request,
            endpoint: `/care-management/supervising-provider`,
            method: 'POST',
            version: '1.0',
        });
    }

    /**
     * Updates supervising provider on state
     * @param state must implement String
     * @param request must implement UpdateSupervisingProviderRequest
     * @returns Promise<Entity>
     */
    public updateSupervisingProvider(
        state: string,
        request: UpdateCareManagementStateSupervisingProviderRequest,
    ): Promise<Entity> {
        return this.apiService.request({
            data: request,
            endpoint: `/care-management/state/${state}/supervising-provider`,
            method: 'POST',
            version: '1.0',
        });
    }

    /**
     * Removes a supervising provider with a given association ID from the supervising provider list for an organization.
     * @param request must implement Entity
     * @returns Promise<void>
     */
    public removeSupervisingProvider(request: Entity): Promise<void> {
        return this.apiService.request({
            data: request,
            endpoint: `/care-management/supervising-provider/${request.id}`,
            method: 'DELETE',
            version: '1.0',
        });
    }

    /**
     * Retrieves a supervising provider listing for a given organization.
     * The most applicable listing is retrieved based on the organization hierarchy traversal.
     * @param request must implement GetCareManagementSupervisingProvidersRequest
     * @returns Promise<PagedResponse<CareManagementSupervisingProviderAssociationItem>>
     */
    public getSupervisingProviders(
        request: GetCareManagementSupervisingProvidersRequest,
    ): Promise<
        PagedResponse<CareManagementSupervisingProviderAssociationItem>
    > {
        return this.apiService.request({
            data: request,
            endpoint: `/care-management/supervising-provider`,
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Retrieves a paginated list of state supervising provider update audit entries.
     * @param request must implement GetCareManagementStateSupervisingProvidersRequest
     * @returns Promise<PagedResponse<CareManagementStateSupervisingProviderItem>>
     */
    public getStateSupervisingProviders(
        request: GetCareManagementStateSupervisingProvidersRequest,
    ): Promise<PagedResponse<CareManagementStateSupervisingProviderItem>> {
        return this.apiService.request({
            data: request,
            endpoint: `/care-management/state/${request.state}/supervising-provider/audit`,
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Create care management state entry
     * @param request must implement CreateCareManagementStateRequest
     * @returns Entity
     */
    public create(request: CreateCareManagementStateRequest): Promise<Entity> {
        return this.apiService.request({
            data: request,
            endpoint: '/care-management/state',
            method: 'POST',
            version: '1.0',
        });
    }

    /**
     * Get care management state entry audit listing
     * @param request must implement GetAuditListRequest
     * @returns PagedResponse<CareManagementStateEntity>
     */
    public getAuditList(
        request: GetCareManagementStateAuditListRequest,
    ): Promise<PagedResponse<CareManagementStateEntity>> {
        return this.apiService.request({
            data: request,
            endpoint: '/care-management/state/audit',
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Retrieves care management state deactivation reason listing
     * @param request must implement GetCareManagementReasonsRequest
     * @returns Promise<PagedResponse<CareManagementStateReason>>
     */
    public getReasons(
        request: GetCareManagementReasonsRequest,
    ): Promise<PagedResponse<CareManagementStateReason>> {
        return this.apiService.request({
            data: request,
            endpoint: '/care-management/state/reason',
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Retrieve a listing of diagnosis audit log entries
     * @param request must implement Entity
     * @returns Promise<PagedResponse<CareManagementStateDiagnosisAuditEntry>>
     */
    public getDiagnosisAuditList(
        request: Entity,
    ): Promise<PagedResponse<CareManagementStateDiagnosisAuditEntry>> {
        return this.apiService.request({
            data: request,
            endpoint: `/care-management/state/${request.id}/diagnosis/audit`,
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Get care management state entry listing
     * @param request must implement GetCareManagementStateListRequest
     * @returns PagedResponse<CareManagementStateEntity>
     */
    public getList(
        request: GetCareManagementStateListRequest,
    ): Promise<PagedResponse<CareManagementStateEntity>> {
        return this.apiService.request({
            data: request,
            endpoint: '/care-management/state',
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Creates or updates the diagnosis for care management state subscription.
     * Diagnosis can only be edited once, with audit note, after the grace period is up.
     * During the grace period, the diagnosis can be updated in-place without limits.
     * This call replaces both primary & secondary diagnosis in one go.
     * @param request must implement UpsertDiagnosisRequest
     * @returns Promise<void>
     */
    public upsertCareManagementStateDiagnosis(
        request: UpsertDiagnosisRequest,
    ): Promise<void> {
        return this.apiService.request({
            data: request,
            endpoint: `/care-management/state/${request.id}/diagnosis`,
            method: 'PUT',
            version: '1.0',
        });
    }
}
