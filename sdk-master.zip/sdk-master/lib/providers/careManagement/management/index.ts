import { ApiService } from '../../../services';
import { Entity } from '../../common/entities';
import { AccountCareManagementServiceType } from './entities';
import {
    CreateAccountCareManagementServiceTypeRequest,
    GetAccountCareManagementServiceTypesRequest,
    GetCareManagementIndividualSummaryRequest,
    UpdateAccountCareManagementServiceTypeRequest,
} from './requests';
import {
    GetAccountCareManagementServiceTypesResponse,
    GetCareManagementPlansResponse,
    GetCareManagementServiceTypesResponse,
} from './responses';

/**
 * Care management preference provider service
 */
export class CareManagementProvider {
    public constructor(private readonly apiService: ApiService) {}
    /**
     * Retrieves Care management service type listing
     * @returns Promise<GetCareManagementServiceTypesResponse>
     */
    public getServiceTypes(): Promise<GetCareManagementServiceTypesResponse> {
        return this.apiService.request({
            endpoint: `/care-management/service-type`,
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Retrieve a list of care management plan entries
     * @returns Promise<GetCareManagementPlansResponse>
     */
    public getPlans(): Promise<GetCareManagementPlansResponse> {
        return this.apiService.request({
            endpoint: `/care-management/plan`,
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Retrieves a list of care management service type account associations
     * @param request must implement GetAccountCareManagementServiceTypesRequest
     * @returns Promise<GetAccountCareManagementServiceTypesResponse>
     */
    public getAccountServiceTypes(
        request: GetAccountCareManagementServiceTypesRequest,
    ): Promise<GetAccountCareManagementServiceTypesResponse> {
        return this.apiService.request({
            endpoint: `/care-management/service-type/account`,
            method: 'GET',
            version: '1.0',
            data: request,
        });
    }

    /**
     * Retrieve care management service type account association entry
     * @param id must implement string
     * @returns Promise<AccountCareManagementServiceType>
     */
    public getAccountServiceTypeSingle(
        id: string,
    ): Promise<AccountCareManagementServiceType> {
        return this.apiService.request({
            endpoint: `/care-management/service-type/account/${id}`,
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Create service type account association entry
     * @param request must implement CreateAccountCareManagementServiceTypeRequest
     * @returns Promise<Entity>
     */
    public createAccountServiceType(
        request: CreateAccountCareManagementServiceTypeRequest,
    ): Promise<Entity> {
        return this.apiService.request({
            endpoint: `/care-management/service-type/account`,
            method: 'POST',
            version: '1.0',
            data: request,
        });
    }

    /**
     * Update care management service type account association entry
     * @param request must implement string
     * @returns Promise<Entity>
     */
    public updateAccountServiceType(
        request: UpdateAccountCareManagementServiceTypeRequest,
    ): Promise<void> {
        return this.apiService.request({
            endpoint: `/care-management/service-type/account/${request.id}`,
            method: 'PATCH',
            version: '1.0',
            data: request,
        });
    }

    /**
     * Remove care management service type account association entry
     * @param id must implement string
     * @returns Promise<Entity>
     */
    public deleteAccountServiceType(id: string): Promise<void> {
        return this.apiService.request({
            endpoint: `/care-management/service-type/account/${id}`,
            method: 'DELETE',
            version: '1.0',
        });
    }

    /**
     * Retrieve individual summary for a patient with care management episode of care in excel format
     * @param request The request settings used to obtain the summary
     * @param language Language in which the summary will be returned
     * @returns Promise<Blob>
     */
    public getIndividualSummaryAsExcel(
        request: GetCareManagementIndividualSummaryRequest,
        language?: string,
    ): Promise<Blob> {
        return this.getIndividualSummary(
            request,
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            language,
        );
    }

    /**
     * Retrieve individual summary for a patient with care management episode of care in PDF format
     * @param request The request settings used to obtain the summary
     * @param language Language in which the summary will be returned
     * @returns Promise<Blob>
     */
    public getIndividualSummaryAsPDF(
        request: GetCareManagementIndividualSummaryRequest,
        language?: string,
    ): Promise<Blob> {
        return this.getIndividualSummary(request, 'application/pdf', language);
    }

    private getIndividualSummary(
        request: GetCareManagementIndividualSummaryRequest,
        format: string,
        language?: string,
    ): Promise<Blob> {
        // The Accept-language header is overwritten here as there's no parameter in the request to send the current language
        // and this one can differ from the site current language as it can be selected only for this specific purpose
        return this.apiService.request({
            data: request,
            endpoint: `/care-management/individual-summary`,
            headers: {
                Accept: format,
                'Accept-language': language ?? undefined,
            },
            method: 'GET',
            responseType: 'blob',
            version: '1.0',
        });
    }
}
