import { Entity } from '../../../common/entities';
import { CareManagementServiceType } from './careManagementServiceType';

/**
 * Care Management Service Type
 */
export interface AccountCareManagementServiceType {
    id: string;
    account: Entity;
    serviceType: CareManagementServiceType;
    createdAt: string;
    updatedAt?: string;
    status: 'active' | 'inactive';
}
