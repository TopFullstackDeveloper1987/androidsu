import { DataPointTypes } from '../../../../processors';

/**
 * Care Management PlanEntry
 */
export interface CareManagementPlanEntry {
    id: string;
    isActive: true;
    name: string;
    device: {
        name: string;
    };
    dataPointTypes: {
        id: DataPointTypes;
    }[];
}
