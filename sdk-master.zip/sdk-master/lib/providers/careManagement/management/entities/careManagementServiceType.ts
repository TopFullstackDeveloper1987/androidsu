/**
 * Care Management Service Type
 */
export interface CareManagementServiceType {
    id: string;
    name: string;
    tag: string;
}

export enum CareManagementServiceTypeId {
    RPM = '1',
    CCM = '2',
}
