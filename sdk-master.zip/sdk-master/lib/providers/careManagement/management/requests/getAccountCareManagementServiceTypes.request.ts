export interface GetAccountCareManagementServiceTypesRequest {
    account: string;
    status?: 'active' | 'inactive' | 'all';
}
