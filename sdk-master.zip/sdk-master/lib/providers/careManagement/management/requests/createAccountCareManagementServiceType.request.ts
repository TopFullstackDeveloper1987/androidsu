export interface CreateAccountCareManagementServiceTypeRequest {
    account: string;
    serviceType: string;
    status?: 'active' | 'inactive';
}
