export interface UpdateAccountCareManagementServiceTypeRequest {
    id: string;
    status: 'active' | 'inactive';
}
