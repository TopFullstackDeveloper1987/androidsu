export interface GetCareManagementIndividualSummaryRequest {
    account: string;
    organization: string;
    start: string;
    end: string;
    serviceType: string;
    status?: 'active' | 'all';
    type?:
        | number[]
        | {
              include?: number[];
              exclude?: number[];
          };
    source?: {
        include?: number[];
        exclude?: number[];
    };
}
