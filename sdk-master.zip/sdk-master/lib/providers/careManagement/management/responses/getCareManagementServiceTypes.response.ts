import { PaginationResponse } from '../../../common/entities';
import { CareManagementServiceType } from '../entities';

export interface GetCareManagementServiceTypesResponse {
    data: Array<CareManagementServiceType>;
    pagination: PaginationResponse;
}
