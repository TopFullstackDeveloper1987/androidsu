import { PaginationResponse } from '../../../common/entities';
import { CareManagementPlanEntry } from '../entities';

export interface GetCareManagementPlansResponse {
    data: Array<CareManagementPlanEntry>;
    pagination: PaginationResponse;
}
