import { PaginationResponse } from '../../../common/entities';
import { AccountCareManagementServiceType } from '../entities';

export interface GetAccountCareManagementServiceTypesResponse {
    data: Array<AccountCareManagementServiceType>;
    pagination: PaginationResponse;
}
