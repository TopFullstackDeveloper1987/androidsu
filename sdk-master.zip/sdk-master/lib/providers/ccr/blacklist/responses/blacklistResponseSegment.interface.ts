/**
 * Interface for object blacklist segment (response)
 */

export interface BlacklistSegment {
    id: string;
    email: string;
}
