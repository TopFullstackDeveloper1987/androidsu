/*
 * Export all interfaces
 */

export { BlacklistSegment } from './blacklistResponseSegment.interface';
