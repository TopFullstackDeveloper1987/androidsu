/**
 * Export all interfaces
 */

export { ClientRegisterRequest } from './clientRegister.request';
export { ClinicRegisterRequest } from './clinicRegister.request';
