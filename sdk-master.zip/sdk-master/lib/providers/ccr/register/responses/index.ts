/**
 * Export all interfaces
 */

export { ClientRegisterResponse } from './clientRegister.response';
export { ClinicRegisterResponse } from './clinicRegister.response';
