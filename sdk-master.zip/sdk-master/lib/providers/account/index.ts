import {
    AccActivityRequest,
    AccAddRequest,
    AccCheckRequest,
    AccListAllRequest,
    AccListRequest,
    AccPreferencesRequest,
    AccUpdatePasswordMFARequest,
    AccUpdatePasswordRequest,
    AccUpdateRequest,
    CreateAccountRequest,
    GetLoginHistoryRequest,
    SetActiveAccountRequest,
    AddCellularDeviceRequest,
    RemoveCellularDeviceRequest,
    GetCellularDeviceHistoryRequest,
    SyncCellularDeviceRequest,
} from '../../providers/account/requests';
import {
    AccAddResponse,
    AccAvatarResponse,
    AccListAllResponse,
    AccListResponse,
    AccPreferencesResponse,
    AccSingleResponse,
    FetchAccountPreference,
    GetTitlesAccountResponse,
    GetTypesAccountResponse,
    UpdateAvatarResponse,
    GetAllCellularDeviceResponse,
    GetAllTypesResponse,
    GetCellularDeviceHistoryResponse,
} from '../../providers/account/responses';
import { ApiService } from '../../services/api.service';
import { Entity, PagedResponse } from '../common/entities';
import { AccountActivityEvent, LoginHistoryItem } from './entities';

/**
 * Account posting/getting/updating v2
 */
class Account {
    /**
     * Init Api Service
     */
    public constructor(private readonly apiService: ApiService) {}

    /**
     * Activate an account. Only admin users have permission to this endpoint
     * @param accountId Account ID
     * @returns Promise<void>
     */
    public activate(accountId: string): Promise<void> {
        const accActivityRequest: AccActivityRequest = {
            account: accountId,
            isActive: true,
        };
        return this.apiService.request({
            endpoint: `/account/${accActivityRequest.account}/activity`,
            method: 'PATCH',
            data: accActivityRequest,
            version: '2.0',
        });
    }

    /**
     * Creates a new account. Password for the account is generated automatically
     * @param accAddRequest must implement AccAddRequest
     * @returns Promise<AccAddResponse>
     */
    public add(accAddRequest: AccAddRequest): Promise<AccAddResponse> {
        return this.apiService.request({
            endpoint: '/account',
            method: 'POST',
            data: accAddRequest,
            version: '2.0',
        });
    }

    /**
     * Emits a user activity event for a logged in user
     * @param request must implement AccountActivityEvent
     * @returns Promise<AccountActivityEvent>
     */
    public addActivityEvent(
        request: AccountActivityEvent,
    ): Promise<AccountActivityEvent> {
        return this.apiService.request({
            endpoint: '/account/activity/event',
            method: 'POST',
            data: request,
            version: '1.0',
        });
    }

    /**
     * Check if an account exists
     * @param accCheckRequest must implement AccCheckRequest
     * @returns Promise<void>
     */
    public check(accCheckRequest: AccCheckRequest): Promise<void> {
        return this.apiService.request({
            endpoint:
                '/account?email=' + encodeURIComponent(accCheckRequest.email),
            method: 'HEAD',
            data: accCheckRequest,
            version: '2.0',
        });
    }

    /*
     * Creates a new account. Password for the account is generated automatically.
     * Permissions: Admin, Provider, OrgAdmin
     *
     * @param request must implement CreateAccountRequest
     * @return Promise<Entity>
     */
    public create(request: CreateAccountRequest): Promise<Entity> {
        return this.apiService.request({
            endpoint: `/account`,
            method: 'POST',
            version: '2.0',
            data: request,
        });
    }

    /**
     * Set an account to inactive. Only admin users have permission to this endpoint
     * @param accountId Account ID
     * @returns Promise<void>
     */
    public deactivate(accountId: string): Promise<void> {
        const accActivityRequest: AccActivityRequest = {
            account: accountId,
            isActive: false,
        };
        return this.apiService.request({
            endpoint: `/account/${accActivityRequest.account}/activity`,
            method: 'PATCH',
            data: accActivityRequest,
            version: '2.0',
        });
    }

    /**
     * Removes the profile picture for specified account
     * @param accountId Account ID
     * @returns Promise<void>
     */
    public deleteAvatar(accountId: string): Promise<void> {
        return this.apiService.request({
            endpoint: `/account/${accountId}/avatar`,
            method: 'DELETE',
            version: '2.0',
        });
    }

    /**
     * Retrieves a the preferences for specified account.
     * @param accountId Account ID
     * @returns void
     */
    public fetchPreferences(
        accountId: string,
    ): Promise<FetchAccountPreference> {
        return (
            this.apiService
                .request<FetchAccountPreference>({
                    endpoint: `/account/${accountId}/preference`,
                    method: 'GET',
                    version: '2.0',
                })
                // return empty preferences if it's not found
                .catch((err) =>
                    err === 'Endpoint not found' ? {} : Promise.reject(err),
                )
        );
    }

    /**
     * Fetch listing of user accounts. Restricted to admins
     * @param accListAllRequest must implement AccListAllRequest
     * @returns Promise<AccListAllResponse>
     */
    public getAll(
        accListAllRequest: AccListAllRequest,
    ): Promise<AccListAllResponse> {
        return this.apiService.request({
            endpoint: '/account',
            method: 'GET',
            data: accListAllRequest,
            version: '2.0',
        });
    }

    /**
     * Retrieves a profile picture for specified account. Returns a url
     * @param accountId Account ID
     * @returns Promise<AccAvatarResponse>
     */
    public getAvatar(accountId: string): Promise<AccAvatarResponse> {
        return this.apiService.request({
            endpoint: `/account/${accountId}/avatar`,
            method: 'GET',
            version: '3.0',
        });
    }

    /**
     * Get a listing of accessible accounts for an account
     * @param accListRequest must implement AccListRequest
     * @returns Promise<AccListResponse>
     */
    public getList(accListRequest: AccListRequest): Promise<AccListResponse> {
        return this.apiService.request({
            endpoint: '/access/account',
            method: 'GET',
            data: accListRequest,
            version: '2.0',
            omitHeaders: ['organization'],
        });
    }

    /**
     * Fetches a paginated list of login history entries for an account.
     * @param request must implement GetLoginHistoryRequest
     * @returns PagedResponse<LoginHistoryItem>
     */
    public getLoginHistory(
        request: GetLoginHistoryRequest,
    ): Promise<PagedResponse<LoginHistoryItem>> {
        return this.apiService.request({
            data: request,
            endpoint: `/account/${request.account}/login-history`,
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Retrieves an account preferences
     * @param accountId Account ID
     * @returns Promise<AccPreferenceReponse>
     */
    public getPreferences(accountId: string): Promise<AccPreferencesResponse> {
        return this.apiService.request({
            endpoint: `/account/${accountId}/preference`,
            method: 'GET',
            version: '2.0',
        });
    }

    /**
     * Fetch single account data
     * @param id mixed requested account ID
     * @returns Promise<AccSingleResponse>
     */
    public getSingle(id: string | number): Promise<AccSingleResponse> {
        return this.apiService.request({
            endpoint: `/account/${id}`,
            method: 'GET',
            version: '2.0',
            omitHeaders: ['organization'],
        });
    }

    /**
     * Get the listing of all titles in the system. Restricted to Admins and Providers.
     * Permissions: Admin, Provider
     *
     * @return Promise<GetTitlesAccountResponse>
     */
    public getTitles(): Promise<GetTitlesAccountResponse> {
        return this.apiService.request({
            endpoint: `/account-title`,
            method: 'GET',
            version: '2.0',
        });
    }

    /**
     * Get the listing of all user types in the system. Restricted to Admins and Providers.
     * Permissions: Admin, Provider
     *
     * @return Promise<GetTypesAccountResponse>
     */
    public getTypes(): Promise<GetTypesAccountResponse> {
        return this.apiService.request({
            endpoint: `/account-type`,
            method: 'GET',
            version: '2.0',
        });
    }

    /**
     * Creates preference entry for specified account
     * @param accSavePreferencesRequest must implement AccPreferencesRequest
     * @returns Promise<void>
     */
    public savePreferences(
        accSavePreferencesRequest: AccPreferencesRequest,
    ): Promise<void> {
        const { account, ...data } = accSavePreferencesRequest;

        return this.apiService.request({
            endpoint: `/account/${account}/preference`,
            method: 'POST',
            data,
            version: '2.0',
        });
    }

    /**
     * Update basic account data
     * @param accUpdateRequest must implement AccUpdateRequest
     * @returns Promise<boolean>
     */
    public update(accUpdateRequest: AccUpdateRequest): Promise<boolean> {
        return this.apiService.request({
            endpoint: `/account/${accUpdateRequest.id}`,
            method: 'PATCH',
            data: accUpdateRequest,
            version: '2.0',
        });
    }

    /**
     * Update account password
     * @param accUpdatePasswordRequest must implement accUpdatePasswordRequest
     * @returns Promise<void>
     */
    public updatePassword(
        accUpdatePasswordRequest: AccUpdatePasswordRequest,
    ): Promise<void> {
        return this.apiService.request({
            endpoint: `/account/password`,
            method: 'POST',
            data: accUpdatePasswordRequest,
            version: '2.0',
        });
    }

    /**
     * Change password of currently authenticated account using MFA token
     * @param accUpdatePasswordMFARequest must implement accUpdatePasswordMFARequest
     * @returns Promise<void>
     */
    public updatePasswordMFA(
        accUpdatePasswordMFARequest: AccUpdatePasswordMFARequest,
    ): Promise<void> {
        return this.apiService.request({
            endpoint: `/account/password/mfa`,
            method: 'POST',
            data: accUpdatePasswordMFARequest,
            version: '2.0',
        });
    }

    /**
     * Updates preference entry for specified account
     * @param accUpdatePreferencesRequest must implement AccPreferencesRequest
     * @returns Promise<boolean>
     */
    public updatePreferences(
        accUpdatePreferencesRequest: AccPreferencesRequest,
    ): Promise<boolean> {
        const { account, ...data } = accUpdatePreferencesRequest;

        return this.apiService.request({
            endpoint: `/account/${account}/preference`,
            method: 'PATCH',
            data,
            version: '2.0',
        });
    }

    /**
     * Upload the profile picture for specified account
     * @param accountId Account ID
     * @returns Promise<UpdateAvatarResponse>
     */
    public uploadAvatar(accountId: string): Promise<UpdateAvatarResponse> {
        return this.apiService.request({
            endpoint: `/account/${accountId}/avatar/upload`,
            method: 'POST',
            version: '3.0',
        });
    }

    /**
     * Set an account to active/inactive. Deactivates all associations and assignments along with account deactivation.
     * Only admin users have permission to this endpoint.
     * Permissions: Admin
     *
     * @param request must implement SetActiveAccountRequest
     * @return Promise<void>
     */
    public setActive(request: SetActiveAccountRequest): Promise<void> {
        return this.apiService.request({
            endpoint: `/account/${request.id}/activity`,
            method: 'PATCH',
            version: '2.0',
            data: request,
        });
    }

    /**
     * Checks if an account has an active session.
     * The response is the HTTP code.
     * @param request must implement Entity
     * @returns Promise<void>
     */
    public checkActiveSession(request: Entity): Promise<void> {
        return this.apiService.request({
            endpoint: `/account/${request.id}/session`,
            method: 'HEAD',
            version: '1.0',
            data: request,
        });
    }

    /**
     * Returns a list of all cellular devices
     * @param accountId account id
     * @returns Promise<GetAllCellularDeviceResponse>
     */
    public getAllCellularDevices(
        accountId: string,
    ): Promise<GetAllCellularDeviceResponse> {
        return this.apiService.request({
            endpoint: `/account/${accountId}/cellular-device`,
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Returns a list of device assignment history
     * @param request GetCellularDeviceHistoryRequest
     * @returns Promise<GetCellularDeviceHistoryResponse>
     */
    public getCellularDeviceHistory(
        request: GetCellularDeviceHistoryRequest,
    ): Promise<GetCellularDeviceHistoryResponse> {
        return this.apiService.request({
            endpoint: `/account/cellular-device/${request.id}`,
            method: 'GET',
            version: '1.0',
            data: request,
        });
    }

    /**
     * Returns a list of all cellular device types
     * @returns Promise<GetAllTypesResponse>
     */
    public getAllCellularDeviceTypes(): Promise<GetAllTypesResponse> {
        return this.apiService.request({
            endpoint: `/cellular-device/type`,
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Sync data readings for a cellular device
     * @param request SyncCellularDeviceRequest
     * @returns Promise<void>
     */
    public syncCellularDevice(
        request: SyncCellularDeviceRequest,
    ): Promise<void> {
        return this.apiService.request({
            endpoint: `/cellular-device/sync`,
            method: 'POST',
            version: '1.0',
            data: request,
            sendRawError: true,
        });
    }

    /**
     * Creates a new cellular device.
     * @param request AddCellularDeviceRequest
     * @returns Promise<void>
     */
    public addCellularDevice(request: AddCellularDeviceRequest): Promise<void> {
        const { account, data } = request;

        return this.apiService.request({
            endpoint: `/account/${account}/cellular-device`,
            method: 'POST',
            data: data,
            version: '1.0',
        });
    }

    /**
     * Removes cellular device.
     * @param request RemoveCellularDeviceRequest
     * @returns Promise<void>
     */
    public removeCellularDevice(
        request: RemoveCellularDeviceRequest,
    ): Promise<void> {
        const { account, id } = request;

        return this.apiService.request({
            endpoint: `/account/${account}/cellular-device/${id}`,
            method: 'DELETE',
            version: '1.0',
        });
    }
}

export { Account };
