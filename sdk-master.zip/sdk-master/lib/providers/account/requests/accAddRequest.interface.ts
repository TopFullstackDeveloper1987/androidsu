/**
 * Interface for POST /account
 */

import { AllOrgPermissions } from '../../organization/entities';
import {
    AccountMeasurementPreferenceType,
    AccountTitleId,
    AccountProfileData,
    PhoneType,
} from '../entities';

export interface AccAddRequest {
    title?: AccountTitleId;
    firstName: string;
    lastName: string;
    email: string;
    accountType: string;
    association?: {
        organization: string;
        permissions?: Partial<AllOrgPermissions>;
        notification?: 'enabled' | 'disabled';
    };
    phone: string;
    phoneType?: PhoneType;
    countryCode?: string;
    measurementPreference?: AccountMeasurementPreferenceType;
    timezone?: string;
    preferredLocales?: Array<string>;
    /** @deprecated prefer the 'profile' property instead */
    client?: Partial<AccountProfileData>;
    profile?: Partial<AccountProfileData>;
}
