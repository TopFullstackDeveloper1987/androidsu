/**
 * Interface for HEAD /account
 */

export interface AccCheckRequest {
    email: string;
}
