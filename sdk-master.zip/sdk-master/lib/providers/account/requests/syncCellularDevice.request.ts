/**
 * POST /v1/cellular-device/sync
 */

export interface SyncCellularDeviceRequest {
    device: string;
    start: string;
    end: string;
}
