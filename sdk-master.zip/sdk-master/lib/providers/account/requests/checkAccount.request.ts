/**
 * HEAD /account
 */

export interface CheckAccountRequest {
    /** Email address to check the account for. */
    email: string;
}
