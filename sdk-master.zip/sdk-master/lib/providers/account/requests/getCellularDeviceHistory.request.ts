/**
 * GET /v1/account/cellular-device/${id}
 */

import { PageOffset, PageSize } from '../../common/entities';

export interface GetCellularDeviceHistoryRequest {
    /** Cellular Device ID */
    id: string;
    /** Page entry limit. Takes a number or can be set to 'all' to fetch all entries. */
    limit?: PageSize;
    /** The page offset. */
    offset?: PageOffset;
}
