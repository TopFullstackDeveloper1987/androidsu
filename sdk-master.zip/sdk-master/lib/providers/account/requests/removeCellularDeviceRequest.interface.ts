export interface RemoveCellularDeviceRequest {
    account: string;
    id: string;
}
