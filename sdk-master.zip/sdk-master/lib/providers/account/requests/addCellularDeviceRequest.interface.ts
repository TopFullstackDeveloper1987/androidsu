export interface AddCellularDeviceRequest {
    account: string;
    data: {
        identifier: string;
        type: string;
    };
}
