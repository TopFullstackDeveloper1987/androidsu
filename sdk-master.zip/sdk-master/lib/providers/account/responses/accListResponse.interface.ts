/**
 * Interface for GET /access/account (response)
 */

import { CountedPaginatedResponse } from '../../reports/entities';
import { AccountAccessData } from '../entities';

export type AccListResponse = CountedPaginatedResponse<AccountAccessData>;
