/**
 * GET /account
 */

import { PagedResponse } from '../../common/entities';
import { AccountFullData } from '../entities';

export type GetAllAccountResponse = PagedResponse<AccountFullData>;
