/**
 * Interface for GET /account/:id/avatar (response)
 */

export interface AccAvatarResponse {
    url: string;
}
