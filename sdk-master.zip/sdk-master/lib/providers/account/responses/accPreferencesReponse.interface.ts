/**
 * Interface for GET /account/:account/preference (response)
 */

import { AccountPreferences } from '../entities';

/* eslint-disable-next-line @typescript-eslint/no-empty-interface */
export interface AccPreferencesResponse extends AccountPreferences {}
