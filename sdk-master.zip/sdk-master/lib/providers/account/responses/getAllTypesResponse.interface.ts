import { CellularDeviceType } from '../entities';
import { PaginationResponse } from './paginationResponse.interface';

export interface GetAllTypesResponse {
    data: Array<CellularDeviceType>;
    pagination: PaginationResponse;
}
