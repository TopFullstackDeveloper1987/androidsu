import { AccountCellularDevice } from '../entities';
import { PaginationResponse } from './paginationResponse.interface';

export interface GetAllCellularDeviceResponse {
    data: Array<AccountCellularDevice>;
    pagination: PaginationResponse;
}
