/**
 * GET /access/account
 */

import { PagedResponse } from '../../common/entities';
import { AccountAccessData } from '../entities';

export type GetListAccountResponse = PagedResponse<AccountAccessData>;
