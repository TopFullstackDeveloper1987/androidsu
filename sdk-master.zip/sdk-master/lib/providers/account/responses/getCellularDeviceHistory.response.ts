import { Pagination } from '../../common/entities';
import { CellularDeviceHistory } from '../entities';

export interface GetCellularDeviceHistoryResponse {
    data: Array<CellularDeviceHistory>;
    pagination: Pagination;
}
