/**
 * Interface for GET /account/:id (response)
 */

import {
    AccountFullData,
    AccountPreferences,
    AccountTitle,
    AccountProfileData,
} from '../entities';

export interface AccSingleResponse extends AccountFullData {
    title?: AccountTitle;
    /** @deprecated prefer the 'profile' property instead */
    clientData?: Partial<AccountProfileData>; // only loaded for clients
    preferredLocales: Array<string>;
    preference: AccountPreferences;
    profile?: Partial<AccountProfileData>;
}
