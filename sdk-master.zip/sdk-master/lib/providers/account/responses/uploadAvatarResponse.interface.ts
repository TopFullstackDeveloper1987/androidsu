/**
 * POST /account/:accountId/avatar/upload
 */
export interface UpdateAvatarResponse {
    url: string;
}
