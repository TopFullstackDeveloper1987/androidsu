/**
 * Interface for POST /account (response)
 */

export interface AccAddResponse {
    id: string;
}
