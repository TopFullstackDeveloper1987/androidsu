import { NamedEntity, UserAccountItem } from '../../common/entities';

interface DeviceType extends NamedEntity {
    provider: NamedEntity;
}

export interface CellularDeviceHistory {
    account: UserAccountItem;
    assignedAt: string;
    removedAt?: string;
    device: DeviceType;
}
