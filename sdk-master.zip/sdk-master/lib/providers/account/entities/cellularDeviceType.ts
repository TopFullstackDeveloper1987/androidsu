import { NamedEntity } from '../../common/entities';

export interface CellularDeviceType extends NamedEntity {
    id: string;
    name: string;
    status: 'active' | 'inactive';
    createdAt: string;
    updatedAt?: string;
}
