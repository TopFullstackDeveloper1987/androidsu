import { NamedEntity } from '../../common/entities';
export interface AccountCellularDevice {
    id: string;
    device: {
        identifier: string;
        type: NamedEntity;
    };
    account: {
        id: string;
    };
    createdAt: string;
    lastSyncedAt?: string;
    deletedAt?: string;
}
