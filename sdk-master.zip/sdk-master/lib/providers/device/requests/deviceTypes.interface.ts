export enum DeviceType {
    Withings = 1,
    ScaleV1 = 2,
    Manual = 3,
    Band = 4,
    ScaleV2 = 5,
}
