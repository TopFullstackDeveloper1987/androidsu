/*
 * Export all interfaces
 */
export * from './deviceTypes.interface';
