/*
 * Export all interfaces
 */

export { FetchAllDevicesResponse } from './fetchAllDevicesResponse.interface';
