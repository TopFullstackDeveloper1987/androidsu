/**
 * Interface for GET /account/:accountId/address
 */

export interface GetAccountAddressListRequest {
    account: string;
    offset?: number;
    limit?: number | 'all';
}
