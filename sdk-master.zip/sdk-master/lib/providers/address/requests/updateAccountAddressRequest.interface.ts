/*
 * Interface for PATCH /account/:accountId/address/:id
 */

export interface UpdateAccountAddressRequest {
    account: string;
    id: string;
    name?: string | null;
    address1?: string;
    address2?: string | null;
    city?: string;
    stateProvince?: string;
    country?: string;
    postalCode?: string;
    labels?: Array<string>;
    verification?: 'enabled' | 'disabled';
}
