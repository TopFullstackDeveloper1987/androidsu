/**
 * Interface for GET /address/suggestion/us
 */

export interface GetAddressSuggestionRequest {
    query: string;
    state?: string;
}
