/**
 * Interface for POST /account/:accountId/address
 */

export interface CreateAccountAddressRequest {
    account: string;
    name?: string;
    address1: string;
    address2?: string;
    city: string;
    stateProvince?: string;
    country: string;
    postalCode?: string;
    labels: Array<string>;
    verification?: 'enabled' | 'disabled';
}
