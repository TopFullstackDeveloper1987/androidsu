/*
 * Interface for DELETE /account/:accountId/address/:id
 */

export interface DeleteAccountAddressRequest {
    account: string;
    id: string;
}
