import * as _ from 'lodash';
import { Entity } from '../common/entities';
import { ApiService } from '../../services/api.service';
import {
    CreateAccountAddressRequest,
    DeleteAccountAddressRequest,
    GetAccountAddressListRequest,
    GetAddressSuggestionRequest,
    UpdateAccountAddressRequest,
} from './requests';
import {
    GetAddressLabelsResponse,
    GetAccountAddressListResponse,
    GetAddressSuggestionResponse,
} from './responses';

/**
 * Password reset request and handling
 */
class AddressProvider {
    /**
     * Init Api Service
     */
    public constructor(private readonly apiService: ApiService) {}

    /**
     * Retrieve address label listing.
     * @returns Promise<GetAddressLabelsResponse>
     */

    public getAddressLabels(): Promise<GetAddressLabelsResponse> {
        return this.apiService.request({
            endpoint: '/address/label',
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Retrieve the user address listing
     * @returns Promise<GetAccountAddressListRequest>
     * @param request must implement GetAccountAddressListResponse
     */

    public getAddressList(
        request: GetAccountAddressListRequest,
    ): Promise<GetAccountAddressListResponse> {
        return this.apiService.request({
            endpoint: `/account/${request.account}/address`,
            data: request,
            method: 'GET',
            version: '1.0',
            omitHeaders: ['organization'],
        });
    }

    /**
     * Create new address for a user
     * @returns Promise<Entity>
     * @param request must implement CreateAccountAddressRequest
     */

    public createAddress(
        request: CreateAccountAddressRequest,
    ): Promise<Entity> {
        return this.apiService.request({
            endpoint: `/account/${request.account}/address`,
            data: _.omit(request, ['account']),
            method: 'POST',
            version: '1.0',
        });
    }

    /**
     * Update an address
     * @returns Promise<void>
     * @param request must implement UpdateAccountAddressRequest
     */

    public updateAddress(request: UpdateAccountAddressRequest): Promise<void> {
        return this.apiService.request({
            endpoint: `/account/${request.account}/address/${request.id}`,
            data: _.omit(request, ['account', 'id']),
            method: 'PATCH',
            version: '1.0',
        });
    }

    /**
     * Remove and address
     * @returns Promise<void>
     * @param request must implement DeleteAccountAddressRequest
     */

    public deleteAddress(request: DeleteAccountAddressRequest): Promise<void> {
        return this.apiService.request({
            endpoint: `/account/${request.account}/address/${request.id}`,
            method: 'DELETE',
            version: '1.0',
        });
    }

    /**
     * Get US address autocomplete / suggestions listing
     * @returns Promise<void>
     * @param request must implement GetAddressSuggestionRequest
     */

    public getAddressSuggestion(
        request: GetAddressSuggestionRequest,
    ): Promise<GetAddressSuggestionResponse> {
        return this.apiService.request({
            endpoint: `/address/suggestion/us`,
            data: request,
            method: 'GET',
            version: '1.0',
        });
    }
}

export { AddressProvider };
