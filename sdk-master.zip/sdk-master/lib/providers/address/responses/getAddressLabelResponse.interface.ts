/**
 * Interface for GET /address/label
 */

import { AddressLabel } from '../../common/entities';

export interface GetAddressLabelsResponse {
    data: AddressLabel[];
}
