import { PaginationResponse } from '../../..';
import { AccountAddress } from '../../common/entities';
/**
 * Interface for GET /account/:accountId/address
 */

export interface GetAccountAddressListResponse {
    data: AccountAddress[];
    pagination: PaginationResponse;
}
