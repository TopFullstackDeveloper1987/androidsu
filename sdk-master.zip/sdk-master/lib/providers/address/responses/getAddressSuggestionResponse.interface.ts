/**
 * Interface for GET /address/suggestion/us
 */

export interface AddressSuggestion {
    address1: string;
    city: string;
    country: string;
    postalCode: string;
    stateProvince: string;
}

export interface GetAddressSuggestionResponse {
    data: Array<AddressSuggestion>;
}
