/**
 * Interface for GET chart (response)
 */

export interface DataSegment {
    date: string;
    percentage: number;
    mass: number;
}
