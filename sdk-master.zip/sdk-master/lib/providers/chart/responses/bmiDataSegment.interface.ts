/**
 * Interface for GET chart (response)
 */

export interface BmiDataSegment {
    date: string;
    bmi: number;
}
