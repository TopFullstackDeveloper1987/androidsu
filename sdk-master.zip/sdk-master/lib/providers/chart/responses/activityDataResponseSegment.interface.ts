export interface ActivityDataResponseSegment {
    date: string;
    stepTotal?: number;
    stepAverage?: number;
    distanceTotal?: number;
    distanceAverage?: number;
}
