export interface BmiSummarySegment {
    currentBmi: number;
    firstBmi: number;
    changeBmi: number;
}
