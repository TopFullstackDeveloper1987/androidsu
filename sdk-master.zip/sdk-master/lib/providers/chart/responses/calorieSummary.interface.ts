/**
 * Interface for GET chart (response)
 */

export interface CalorieSummary {
    current: number;
    average: number;
}
