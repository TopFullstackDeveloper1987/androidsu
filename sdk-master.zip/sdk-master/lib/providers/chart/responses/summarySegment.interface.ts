export interface SummarySegment {
    currentPercentage?: number;
    firstPercentage?: number;
    changePercentage?: number;
    currentMass: number;
    firstMass: number;
    changeMass: number;
}
