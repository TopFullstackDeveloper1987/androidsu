/**
 * Interface for GET chart/activity (response)
 */

export interface ActivitySummary {
    current: number;
    average: number;
    goal: number;
}
