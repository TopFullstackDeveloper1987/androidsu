export interface SleepSummary {
    current: number;
    average: number;
    goal: number;
}
