export type SleepData = 'total' | 'average' | 'sleepQuality';
