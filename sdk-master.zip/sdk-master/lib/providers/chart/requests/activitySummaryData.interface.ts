/**
 * Interface for activity summary data
 */

export type SummaryData = 'steps' | 'distance';
