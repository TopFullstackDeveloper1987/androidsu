export type SummaryAggregation =
    | 'average'
    | 'min'
    | 'max'
    | 'mostRecent'
    | 'oldest';
