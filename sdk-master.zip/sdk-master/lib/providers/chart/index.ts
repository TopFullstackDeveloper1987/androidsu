/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import * as moment from 'moment';
import { ApiService, GoalV2 } from '../../services';
import { GoalTypeId } from '../goal2/entities';
import { FetchGoalRequest } from '../goal2/requests';
import {
    ActivityMeasurementRequest,
    BodyMeasurementRequest,
    SleepRequest,
} from './requests';
import {
    ActivityResponse,
    BmiResponse,
    BodyFatResponse,
    LeanMassResponse,
    SleepResponse,
    WeightResponse,
} from './responses';
import { CircumferenceResponse } from './responses';
import { ActivityDataResponseSegment } from './responses/activityDataResponseSegment.interface';

/**
 * Chart provider to fetch chart data and summaries
 */
class Chart {
    private goalV2: GoalV2;

    /**
     * Init Api Service
     */
    public constructor(private readonly apiService: ApiService) {
        this.goalV2 = new GoalV2(apiService);
    }

    /**
     * Fetch activity chart summary
     * @param fetchActivityRequest must implement FetchActivityRequest
     * @returns ActivityResponse
     */
    public async activity(
        fetchActivityRequest: ActivityMeasurementRequest,
    ): Promise<ActivityResponse> {
        const activityRequest = {
            clientId: fetchActivityRequest.account,
            data: ['steps', 'distance'],
            startDate: fetchActivityRequest.startDate,
            endDate: fetchActivityRequest.endDate,
            max: fetchActivityRequest.max,
            unit: fetchActivityRequest.unit,
            device: fetchActivityRequest.device,
        };

        const goalRequest: FetchGoalRequest = {
            account:
                fetchActivityRequest.account !== undefined
                    ? fetchActivityRequest.account
                    : undefined,
        };

        const request = [
            this.apiService.request<{
                data: ActivityDataResponseSegment[];
                summary: { stepsAverage: number };
            }>({
                endpoint: `/measurement/activity/summary`,
                method: `GET`,
                data: activityRequest,
            }),
            this.goalV2.fetch(goalRequest),
        ] as const;

        return Promise.all(request).then(([activity, goal]) => {
            return {
                data: activity.data,
                summary: {
                    current: activity.data.length
                        ? activity.data.slice().reverse()[0].stepTotal ?? 0
                        : 0,
                    average: activity.summary.stepsAverage,
                    goal:
                        goal?.data?.find(
                            (entry) => entry.type.id === GoalTypeId.dailyStep,
                        )?.quantity || 0,
                },
            };
        });
    }

    /**
     * Fetch sleep chart and summary
     * @param fetchSleepRequest must implement SleepRequest
     * @returns SleepResponse
     */
    public async sleep(
        fetchSleepRequest: SleepRequest,
    ): Promise<SleepResponse> {
        const sleepRequest = {
            clientId: fetchSleepRequest.account,
            data: ['total', 'average', 'sleepQuality'],
            startDate: fetchSleepRequest.startDate,
            endDate: fetchSleepRequest.endDate,
            max: fetchSleepRequest.max,
            unit: fetchSleepRequest.unit,
        };

        const goalRequest: FetchGoalRequest = {
            account:
                fetchSleepRequest.account !== undefined
                    ? fetchSleepRequest.account
                    : undefined,
        };

        const request = [
            // TODO: Fix typing
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            this.apiService.request<any>({
                endpoint: `/measurement/sleep/summary`,
                method: `GET`,
                data: sleepRequest,
            }),
            this.goalV2.fetch(goalRequest),
        ] as const;

        return Promise.all(request).then((response) => {
            const [sleep, goal] = response;
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            const data = sleep.data.map((item: any) => {
                return {
                    date: item.date,
                    duration: moment
                        // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
                        .duration(item.sleepMinutes, 'second')
                        .asHours(),
                    average: moment
                        // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
                        .duration(item.averageMinutes, 'second')
                        .asHours(),
                    quality: item.sleepQuality,
                };
            });

            const current = sleep.data.length
                ? moment
                      .duration(
                          // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
                          sleep.data.slice().reverse()[0].sleepMinutes,
                          'second',
                      )
                      .asHours()
                : 0;
            const average = sleep.data.length
                ? moment
                      .duration(
                          // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
                          sleep.data.slice().reverse()[0].averageMinutes,
                          'second',
                      )
                      .asHours()
                : 0;

            return {
                data: data,
                summary: {
                    current: current,
                    average: average,
                    goal:
                        goal?.data?.find(
                            (entry) => entry.type.id == GoalTypeId.dailySleep,
                        )?.quantity || 0,
                },
            };
        });
    }

    /**
     * Fetch lean mass chart and summary
     * @param fetchLeanMassRequest must implement BodyMeasurementRequest
     * @returns LeanMassResponse
     */
    public async leanMass(
        fetchLeanMassRequest: BodyMeasurementRequest,
    ): Promise<LeanMassResponse> {
        fetchLeanMassRequest.data = ['weight', 'bodyFat', 'fatMassWeight'];

        return (
            this.apiService
                // TODO: Fix typing
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                .request<any>({
                    endpoint: `/measurement/body/summary`,
                    method: 'GET',
                    data: fetchLeanMassRequest,
                })
                .then((response) => {
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    const data = response.data.map((item: any) => {
                        let mass = 0,
                            percentage = 0;
                        // FIXME: for some reasons fatMassWeight always 0, that's why we calculate it manually
                        const fatMassWeight = Math.round(
                            (item.weight * item.bodyFat) / 100000,
                        );
                        if (item.weight > 0 && fatMassWeight > 0) {
                            percentage =
                                Math.round(
                                    ((item.weight - fatMassWeight) /
                                        item.weight) *
                                        1000,
                                ) / 10;
                            mass = item.weight - fatMassWeight;
                        }
                        return {
                            date: item.date,
                            percentage: percentage,
                            mass: mass,
                        };
                    });

                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    let initial = data.find((item: any) => item.mass > 0);
                    let current = data
                        .slice()
                        .reverse()
                        // eslint-disable-next-line @typescript-eslint/no-explicit-any
                        .find((item: any) => item.mass > 0);

                    if (initial === undefined && data.length) {
                        initial = data[0];
                    }

                    if (current === undefined && data.length) {
                        current = data.slice().reverse()[0];
                    }

                    const error =
                        initial === undefined || current === undefined;
                    const summary = {
                        currentPercentage: error ? 0 : current.percentage,
                        firstPercentage: error ? 0 : initial.percentage,
                        changePercentage: error
                            ? 0
                            : initial.percentage - current.percentage,
                        currentMass: error ? 0 : current.mass,
                        firstMass: error ? 0 : initial.mass,
                        changeMass: error ? 0 : initial.mass - current.mass,
                    };

                    return {
                        data: data,
                        summary: summary,
                    };
                })
        );
    }

    /**
     * Fetch bmi chart and summary
     * @param fetchBmiRequest must implement BodyMeasurementRequest
     * @returns BmiResponse
     */
    public async bmi(
        fetchBmiRequest: BodyMeasurementRequest,
    ): Promise<BmiResponse> {
        fetchBmiRequest.data = ['bmi'];

        return (
            this.apiService
                // TODO: Fix typing
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                .request<any>({
                    endpoint: `/measurement/body/summary`,
                    method: 'GET',
                    data: fetchBmiRequest,
                })
                .then((response) => {
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    const data = response.data.map((item: any) => {
                        return {
                            date: item.date,
                            bmi: item.bmi,
                        };
                    });

                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    let initial = data.find((item: any) => item.bmi > 0);
                    let current = data
                        .slice()
                        .reverse()
                        // eslint-disable-next-line @typescript-eslint/no-explicit-any
                        .find((item: any) => item.bmi > 0);

                    if (initial === undefined && data.length) {
                        initial = data[0];
                    }

                    if (current === undefined && data.length) {
                        current = data.slice().reverse()[0];
                    }

                    const error =
                        initial === undefined || current === undefined;
                    const summary = {
                        currentBmi: error ? 0 : current.bmi,
                        firstBmi: error ? 0 : initial.bmi,
                        changeBmi: error ? 0 : initial.bmi - current.bmi,
                    };

                    return {
                        data: data,
                        summary: summary,
                    };
                })
        );
    }

    /**
     * Fetch body fat chart data and request
     * @param fetchBodyFatRequest must implement BodyMeasurementRequest
     * @returns BodyFatResponse
     */
    public async bodyFat(
        fetchBodyFatRequest: BodyMeasurementRequest,
    ): Promise<BodyFatResponse> {
        fetchBodyFatRequest.data = ['bodyFat', 'fatMassWeight', 'weight'];

        return (
            this.apiService
                // TODO: Fix typing
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                .request<any>({
                    endpoint: `/measurement/body/summary`,
                    method: 'GET',
                    data: fetchBodyFatRequest,
                })
                .then((response) => {
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    const data = response.data.map((item: any) => {
                        // FIXME: for some reasons fatMassWeight always 0, that's why we calculate it manually
                        return {
                            date: item.date,
                            percentage: Math.round(item.bodyFat / 100) / 10,
                            mass: Math.round(
                                (item.weight * item.bodyFat) / 100000,
                            ),
                        };
                    });

                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    let initial = data.find((item: any) => item.mass > 0);
                    let current = data
                        .slice()
                        .reverse()
                        // eslint-disable-next-line @typescript-eslint/no-explicit-any
                        .find((item: any) => item.mass > 0);

                    if (initial === undefined && data.length) {
                        initial = data[0];
                    }

                    if (current === undefined && data.length) {
                        current = data.slice().reverse()[0];
                    }

                    const error =
                        initial === undefined || current === undefined;
                    const summary = {
                        currentPercentage: error ? 0 : current.percentage,
                        firstPercentage: error ? 0 : initial.percentage,
                        changePercentage: error
                            ? 0
                            : initial.percentage - current.percentage,
                        currentMass: error ? 0 : current.mass,
                        firstMass: error ? 0 : initial.mass,
                        changeMass: error ? 0 : initial.mass - current.mass,
                    };

                    return {
                        data: data,
                        summary: summary,
                    };
                })
        );
    }

    /**
     * Fetch weight chart data and summary
     * @param fetchWeightRequest must implement BodyMeasurementRequest
     * @returns WeightResponse
     */
    public async weight(
        fetchWeightRequest: BodyMeasurementRequest,
    ): Promise<WeightResponse> {
        fetchWeightRequest.data = ['weight', 'bodyFat', 'fatMassWeight'];

        return (
            this.apiService
                // TODO: Fix typing
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                .request<any>({
                    endpoint: `/measurement/body/summary`,
                    method: 'GET',
                    data: fetchWeightRequest,
                })
                .then((response) => {
                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    const data = response.data.map((item: any) => {
                        // FIXME: for some reasons fatMassWeight always 0, that's why we calculate it manually
                        return {
                            date: item.date,
                            weight: item.weight,
                            bodyFat: item.bodyFat,
                            leanMass:
                                item.weight > 0 && item.bodyFat > 0
                                    ? item.weight -
                                      Math.round(
                                          (item.weight * item.bodyFat) / 100000,
                                      )
                                    : 0,
                        };
                    });

                    // eslint-disable-next-line @typescript-eslint/no-explicit-any
                    let initial = data.find((item: any) => item.weight > 0);
                    let current = data
                        .slice()
                        .reverse()
                        // eslint-disable-next-line @typescript-eslint/no-explicit-any
                        .find((item: any) => item.weight > 0);

                    if (initial === undefined && data.length) {
                        initial = data[0];
                    }

                    if (current === undefined && data.length) {
                        current = data.slice().reverse()[0];
                    }

                    const error =
                        initial === undefined || current === undefined;
                    const summary = {
                        currentMass: error ? 0 : current.weight,
                        firstMass: error ? 0 : initial.weight,
                        changeMass: error ? 0 : initial.weight - current.weight,
                    };

                    return {
                        data: data,
                        summary: summary,
                    };
                })
        );
    }

    /**
     * Fetch circumference chart data
     * @param fetchCircumferenceRequest must implement BodyMeasurementRequest
     * @returns CircumferenceResponse
     */
    public async circumference(
        fetchCircumferenceRequest: BodyMeasurementRequest,
    ): Promise<CircumferenceResponse> {
        fetchCircumferenceRequest.data = [
            'waist',
            'arm',
            'hip',
            'chest',
            'thigh',
            'neck',
            'thorax',
        ];

        return this.apiService
            .request<{ data: Record<string, number>[] }>({
                endpoint: `/measurement/body/summary`,
                method: 'GET',
                data: fetchCircumferenceRequest,
            })
            .then((response) => {
                const data = [];

                for (const item of response.data) {
                    if (
                        (item.waist !== null && item.waist > 0) ||
                        (item.arm !== null && item.arm > 0) ||
                        (item.hip !== null && item.hip > 0) ||
                        (item.chest !== null && item.chest > 0) ||
                        (item.thigh !== null && item.thigh > 0) ||
                        (item.neck !== null && item.neck > 0) ||
                        (item.thorax !== null && item.thorax > 0)
                    ) {
                        data.push({
                            date: moment.utc(item.date).format('YYYY-MM-DD'),
                            waist: item.waist || 0,
                            arm: item.arm || 0,
                            hip: item.hip || 0,
                            chest: item.chest || 0,
                            thigh: item.thigh || 0,
                            neck: item.neck || 0,
                            thorax: item.thorax || 0,
                        });
                    }
                }

                return {
                    data: data,
                };
            });
    }
}

export { Chart };
