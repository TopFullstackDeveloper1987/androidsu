/**
 * Interface for GET /authentication/:service
 */

export interface OAuthResponse {
    url: string;
}
