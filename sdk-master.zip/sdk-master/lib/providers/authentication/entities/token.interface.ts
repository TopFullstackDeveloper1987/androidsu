/**
 * Token of the accounts authentications
 */

export interface AuthenticationToken {
    createdAt: string;
}
