export * from './segment.interface';
export * from './service.interface';
export * from './synced.interface';
export * from './syncDate.interface';
export * from './token.interface';
export * from './urlEntity.interface';
