export interface URLEntity {
    url: string;
}
