/**
 * Supported services
 */

export type AuthenticationService = 'fitbit' | 'google' | 'healthkit';

export type AuthenticationTitle = 'Fitbit' | 'GoogleFit' | 'Healthkit';
