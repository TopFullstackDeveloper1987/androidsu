/**
 * Synced service date
 */

export interface SyncDate {
    syncDate: string; // Timestamp of last sync in ISO-8601 format. Defaulted to the current timestamp.
}
