/**
 * Interface for POST /1.0/authentication/shopify
 */

export interface ShopifyRequest {
    /** The account ID override available only for administrator */
    account?: string;
    /** The organization ID */
    organization: string;
}
