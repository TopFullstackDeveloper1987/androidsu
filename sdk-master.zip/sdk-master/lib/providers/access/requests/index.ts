/**
 * Export all interfaces
 */

export * from './resetPassword.interface';
export * from './updatePassword.interface';
