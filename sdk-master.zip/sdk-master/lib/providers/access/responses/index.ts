export * from './updatePassword.response';
