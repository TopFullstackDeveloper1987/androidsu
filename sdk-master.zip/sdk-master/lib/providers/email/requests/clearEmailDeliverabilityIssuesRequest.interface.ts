/**
 * Interface for DELETE /account/:accountId/email/issue
 */

export interface ClearEmailDeliverabilityIssuesRequest {
    id: string;
    sendgrid: string;
}
