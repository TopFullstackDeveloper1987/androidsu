/**
 * Interface for GET /account/:accountId/email/message
 */

export interface GetAccountEmailMessagesRequest {
    id: string;
    sendgrid: string;
}
