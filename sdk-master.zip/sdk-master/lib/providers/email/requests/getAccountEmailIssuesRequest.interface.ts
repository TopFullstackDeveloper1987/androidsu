/**
 * Interface for GET /account/:accountId/email/issue
 */

export interface GetAccountEmailIssuesRequest {
    id: string;
    sendgrid: string;
}
