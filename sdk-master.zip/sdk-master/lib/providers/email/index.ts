import { ApiService } from '../../services/api.service';
import {
    ClearEmailDeliverabilityIssuesRequest,
    GetAccountEmailIssuesRequest,
    GetAccountEmailMessagesRequest,
} from './requests';
import {
    GetAccountEmailIssuesResponse,
    GetAccountEmailMessagesResponse,
    GetSendGridAccountListResponse,
} from './responses';

/**
 * Password reset request and handling
 */
class EmailProvider {
    /**
     * Init Api Service
     */
    public constructor(private readonly apiService: ApiService) {}

    /**
     * Retrieve Sendgrid email account collection.
     * @returns Promise<GetSendGridAccountListResponse>
     */

    public getSendgridAccounts(): Promise<GetSendGridAccountListResponse> {
        return this.apiService.request({
            endpoint: '/email/sendgrid/account',
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Retrieve the user email messages list
     * @returns Promise<GetAccountEmailMessagesRequest>
     * @param request must implement GetAccountEmailMessagesResponse
     */

    public getAccountEmailMessages(
        request: GetAccountEmailMessagesRequest,
    ): Promise<GetAccountEmailMessagesResponse> {
        return this.apiService.request({
            endpoint: `/account/${request.id}/email/message`,
            data: request,
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Retrieve the user mail deliverability issues
     * @returns Promise<GetAccountEmailIssuesRequest>
     * @param request must implement GetAccountEmailIssuesResponse
     */

    public getAccountEmailDeliverabilityIssues(
        request: GetAccountEmailIssuesRequest,
    ): Promise<GetAccountEmailIssuesResponse> {
        return this.apiService.request({
            endpoint: `/account/${request.id}/email/issue`,
            data: request,
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Attempt to clear deliverability issues
     * @returns Promise<ClearEmailDeliverabilityIssuesRequest>
     * @param request must implement void
     */

    public clearEmailDeliverabilityIssues(
        request: ClearEmailDeliverabilityIssuesRequest,
    ): Promise<void> {
        return this.apiService.request({
            endpoint: `/account/${request.id}/email/issue`,
            data: request,
            method: 'DELETE',
            version: '1.0',
        });
    }
}

export { EmailProvider };
