import { PaginationResponse } from '../../..';
import { NamedEntity } from '../../common/entities';
/**
 * Interface for GET /email/sendgrid/account
 */

export interface GetSendGridAccountListResponse {
    data: NamedEntity[];
    pagination: PaginationResponse;
}
