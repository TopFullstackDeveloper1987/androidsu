/**
 * Interface for GET /account/:accountId/email/issue
 */

import { EmailIssue, PaginationResponse } from '../../common/entities';

export interface GetAccountEmailIssuesResponse {
    data: EmailIssue[];
    pagination: PaginationResponse;
}
