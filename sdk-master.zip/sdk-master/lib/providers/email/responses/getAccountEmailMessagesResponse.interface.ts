/**
 * Interface for GET /account/:accountId/email/message
 */

import { EmailMessage, PaginationResponse } from '../../common/entities';

export interface GetAccountEmailMessagesResponse {
    data: EmailMessage[];
    pagination: PaginationResponse;
}
