export interface ExerciseType {
    id: string;
    name: string;
    description?: string;
    isActive: boolean;
}
