/**
 * POST /measurement/exercise/type
 */

export interface CreateExerciseTypeRequest {
    name: string;
    description?: string;
}
