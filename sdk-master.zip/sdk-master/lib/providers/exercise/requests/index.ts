export * from './createExerciseAssociation.request';
export * from './getAllExerciseAssociation.request';
export * from './updateExerciseAssociation.request';

export * from './createExercise.request';
export * from './getAllExercise.request';
export * from './updateExercise.request';

export * from './createExerciseType.request';
export * from './getAllExerciseType.request';
export * from './updateExerciseType.request';
