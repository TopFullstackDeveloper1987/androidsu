/**
 * Interface for DELETE /association
 */

export interface RemoveAssociationRequest {
    account: string;
    organization: string;
}
