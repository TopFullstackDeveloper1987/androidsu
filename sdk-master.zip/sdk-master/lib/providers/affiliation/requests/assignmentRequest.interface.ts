/**
 * Interface for POST/DELETE /assignment
 */

export interface AssignmentRequest {
    client: string;
    provider: string;
    organization: string;
}
