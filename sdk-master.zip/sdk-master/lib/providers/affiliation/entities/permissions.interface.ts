/**
 * Affiliation Permissions
 */

export interface AffiliationPermissions {
    viewAll: boolean;
    admin: boolean;
    allowClientPhi: boolean;
}
