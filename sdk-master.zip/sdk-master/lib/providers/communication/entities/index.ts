export * from './communicationPreference.single';
