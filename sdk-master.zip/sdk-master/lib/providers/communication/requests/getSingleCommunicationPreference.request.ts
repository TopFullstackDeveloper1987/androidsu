/**
 * Interface for GET /communication/preference
 */

export interface GetSingleCommunicationPreferenceRequest {
    /** Organization ID */
    organization: string;
}
