import { ApiService } from '../../services/api.service';
import { PagedResponse } from '../common/entities';

import { DeleteFoodPreferenceTabLocaleRequest } from './requests/deleteFoodPreferenceTabLocale.request';
import { GetFoodPreferenceTabLocale } from './requests/getFoodPreferenceTabLocale.request';
import { UpdateFoodPreferenceTabLocaleRequest } from './requests/updateFoodPreferenceTabLocale.request';
import { GetFoodPreferenceTabLocaleResponse } from './responses/getFoodPreferenceTabLocaleLocale.response';

export class FoodPreferenceTabLocale {
    public constructor(private readonly apiService: ApiService) {}

    /**
     * List all translations for a tab
     *
     * @param request must implement GetFoodPreferenceTabLocale
     * @return Promise<PagedResponse<GetFoodPreferenceTabLocaleResponse>>
     */
    public get(
        request: GetFoodPreferenceTabLocale,
    ): Promise<PagedResponse<GetFoodPreferenceTabLocaleResponse>> {
        return this.apiService.request({
            endpoint: `/food/preference/tab/${request.id}/locale`,
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Upsert a translation for a tab
     * Permissions: Provider, Admin
     *
     * @param request must implement UpdateFoodPreferenceTabLocaleRequest
     * @return Promise<void>
     */
    public update(
        request: UpdateFoodPreferenceTabLocaleRequest,
    ): Promise<void> {
        return this.apiService.request({
            endpoint: `/food/preference/tab/${request.id}/locale/${request.locale}`,
            method: 'PUT',
            version: '1.0',
            data: request,
        });
    }

    /**
     * Remove a translation for a tab
     * Permissions: Provider, Admin
     *
     * @param request must implement DeleteFoodKeyLocaleRequest
     * @return Promise<void>
     */
    public delete(
        request: DeleteFoodPreferenceTabLocaleRequest,
    ): Promise<void> {
        return this.apiService.request({
            endpoint: `/food/preference/tab/${request.id}/locale/${request.locale}`,
            method: 'DELETE',
            version: '1.0',
        });
    }
}
