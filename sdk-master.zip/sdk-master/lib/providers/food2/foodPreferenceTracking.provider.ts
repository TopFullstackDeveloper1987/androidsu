import { ApiService } from '../../services/api.service';
import { PagedResponse } from '../common/entities';

import { CreateFoodPreferenceTrackingRequest } from './requests/createFoodPreferenceTracking.request';
import { DeleteFoodPreferenceTrackingRequest } from './requests/deleteFoodPreferenceTracking.request';
import { GetAllFoodPreferenceTracking } from './requests/getAllFoodPreferenceTracking.request';
import { UpdateFoodPreferenceTrackingRequest } from './requests/updateFoodPreferenceTracking.request';
import { GetAllFoodPreferenceTrackingResponse } from './responses/getAllFoodPreferenceTracking.response';

export class FoodPreferenceTracking {
    public constructor(private readonly apiService: ApiService) {}

    /**
     * List all food tracking modes
     *
     * @param request must implement GetAllFoodPreferenceTracking
     * @return Promise<PagedResponse<GetAllFoodPreferenceTrackingResponse>>
     */
    public getAll(
        request: GetAllFoodPreferenceTracking,
    ): Promise<PagedResponse<GetAllFoodPreferenceTrackingResponse>> {
        return this.apiService.request({
            endpoint: `/food/preference/tracking`,
            method: 'GET',
            version: '2.0',
            data: request,
        });
    }

    /**
     * Add a food tracking mode for an organization
     * Permissions: Provider, Admin
     *
     * @param request must implement CreateFoodPreferenceTrackingRequest
     * @return Promise<void>
     */
    public create(request: CreateFoodPreferenceTrackingRequest): Promise<void> {
        return this.apiService.request({
            endpoint: `/food/preference/tracking`,
            method: 'POST',
            version: '2.0',
            data: request,
        });
    }

    /**
     * Toggle the food tracking mode status for an organization
     * Permissions: Provider, Admin
     *
     * @param request must implement UpdateFoodPreferenceTrackingRequest
     * @return Promise<void>
     */
    public update(request: UpdateFoodPreferenceTrackingRequest): Promise<void> {
        return this.apiService.request({
            endpoint: `/food/preference/tracking`,
            method: 'PATCH',
            version: '2.0',
            data: request,
        });
    }

    /**
     * Remove a food tracking mode for an organization.
     * Permissions: Provider, Admin
     *
     * @param request must implement DeleteFoodPreferenceTrackingRequest
     * @return Promise<void>
     */
    public delete(request: DeleteFoodPreferenceTrackingRequest): Promise<void> {
        return this.apiService.request({
            endpoint: `/food/preference/tracking/${request.organization}/mode/${request.mode}`,
            method: 'DELETE',
            version: '2.0',
            data: request,
        });
    }
}
