import { ApiService } from '../../services/api.service';
import { FoodPreferenceTabTypeItem } from './entities/foodPreferenceTabTypeItem';

import { CreateFoodPreferenceTabTypeRequest } from './requests/createFoodPreferenceTabType.request';
import { DeleteSingleFoodPreferenceTabTypeRequest } from './requests/deleteSingleFoodPreferenceTabType.request';
import { GetAllFoodPreferenceTabTypeRequest } from './requests/getAllFoodPreferenceTabType.request';
import { GetSingleFoodPreferenceTabTypeRequest } from './requests/getSingleFoodPreferenceTabType.request';
import { UpdateFoodPreferenceTabTypeRequest } from './requests/updateFoodPreferenceTabType.request';
import { GetAllFoodPreferenceTabTypeResponse } from './responses/getAllFoodPreferenceTabType.response';

export class FoodPreferenceTabType {
    public constructor(private readonly apiService: ApiService) {}

    /**
     * List all food tab types
     *
     * @param request must implement GetAllFoodPreferenceTabTypeRequest
     * @return Promise<PagedResponse<GetAllFoodPreferenceTabTypeResponse>>
     */
    public getAll(
        request: GetAllFoodPreferenceTabTypeRequest,
    ): Promise<GetAllFoodPreferenceTabTypeResponse> {
        return this.apiService.request({
            endpoint: `/food/preference/tab/type`,
            method: 'GET',
            version: '1.0',
            data: request,
        });
    }

    /**
     * Retrieve a food tab type
     *
     * @param request must implement Entity
     * @return Promise<ContentSingle>
     */
    public getSingle(
        request: GetSingleFoodPreferenceTabTypeRequest,
    ): Promise<FoodPreferenceTabTypeItem> {
        return this.apiService.request({
            endpoint: `/food/preference/tab/type/${request.id}`,
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Create a new food tab type
     * Permissions: Admin
     *
     * @param request must implement CreateFoodPreferenceTabTypeRequest
     * @return Promise<void>
     */
    public create(request: CreateFoodPreferenceTabTypeRequest): Promise<void> {
        return this.apiService.request({
            endpoint: `/food/preference/tab/type`,
            method: 'POST',
            version: '1.0',
            data: request,
        });
    }

    /**
     * Update a food tab type
     * Permissions: Admin
     *
     * @param request must implement UpdateFoodPreferenceTabTypeRequest
     * @return Promise<void>
     */
    public update(request: UpdateFoodPreferenceTabTypeRequest): Promise<void> {
        return this.apiService.request({
            endpoint: `/food/preference/tab/type/${request.id}`,
            method: 'PATCH',
            version: '1.0',
            data: request,
        });
    }

    /**
     * Remove a food tab type
     * Permissions: Admin
     *
     * @param request must implement DeleteSingleFoodPreferenceTabTypeRequest
     * @return Promise<void>
     */
    public delete(
        request: DeleteSingleFoodPreferenceTabTypeRequest,
    ): Promise<void> {
        return this.apiService.request({
            endpoint: `/food/preference/tab/type/${request.id}`,
            method: 'DELETE',
            version: '1.0',
            data: request,
        });
    }
}
