import { ApiService } from '../../services/api.service';
import { Entity } from '../common/entities';
import { FoodPreferenceTabItem } from './entities/foodPreferenceTabItem';
import { CreateFoodPreferenceTabRequest } from './requests/createFoodPreferenceTab.request';
import { GetAllFoodPreferenceTabRequest } from './requests/getAllFoodPreferenceTab.request';
import { UpdateFoodPreferenceTabRequest } from './requests/updateFoodPreferenceTab.request';
import { GetAllFoodPreferenceTabResponse } from './responses/getAllFoodPreferenceTab.response';

export class FoodPreferenceTab {
    public constructor(private readonly apiService: ApiService) {}

    /**
     * List all food tabs
     *
     * @param request must implement GetAllFoodPreferenceTabRequest
     * @return Promise<GetAllFoodPreferenceTabResponse>
     */
    public getAll(
        request: GetAllFoodPreferenceTabRequest,
    ): Promise<GetAllFoodPreferenceTabResponse> {
        return this.apiService.request({
            endpoint: `/food/preference/tab`,
            method: 'GET',
            version: '1.0',
            data: request,
        });
    }

    /**
     * Retrieve a food tab
     * Permissions: Provider, Client, OrgAccess, OrgClientPHI
     *
     * @param request must implement Entity
     * @return Promise<FoodPreferenceTab>
     */
    public getSingle(request: Entity): Promise<FoodPreferenceTabItem> {
        return this.apiService.request({
            endpoint: `/food/preference/tab/${request.id}`,
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Create a new food tab for an organization
     * Permissions: Provider, Admin
     *
     * @param request must implement CreateFoodPreferenceRequest
     * @return Promise<void>
     */
    public create(request: CreateFoodPreferenceTabRequest): Promise<Entity> {
        return this.apiService.request({
            endpoint: `/food/preference/tab`,
            method: 'POST',
            version: '1.0',
            data: request,
        });
    }

    /**
     * Update a food tab
     * Permissions: Provider, Admin
     *
     * @param request must implement Entity
     * @return Promise<void>
     */
    public update(request: UpdateFoodPreferenceTabRequest): Promise<void> {
        return this.apiService.request({
            endpoint: `/food/preference/tab/${request.id}`,
            method: 'PATCH',
            version: '1.0',
            data: request,
        });
    }

    /**
     * Remove a food tab
     * Permissions: Provider, Admin
     *
     * @param request must implement Entity
     * @return Promise<void>
     */
    public delete(request: Entity): Promise<void> {
        return this.apiService.request({
            endpoint: `/food/preference/tab/${request.id}`,
            method: 'DELETE',
            version: '1.0',
            data: request,
        });
    }
}
