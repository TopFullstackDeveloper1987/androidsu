/**
 * FoodMealItemV3
 */

export interface FoodMealItemV3 {
    /** The id of the meal that was consumed. */
    id: string;
    /** The name of the meal record. */
    name: string;
    /** The notice of the meal. */
    notice: string;
    /** The status of meal */
    status: 'active' | 'inactive';
}
