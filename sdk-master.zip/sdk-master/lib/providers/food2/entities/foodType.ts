/**
 * FoodType
 */

export type FoodType = 'branded' | 'common';

export const foodTypes: Array<FoodType> = ['branded', 'common'];
