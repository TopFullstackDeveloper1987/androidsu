export interface ConsumedMealIngredients {
    name: string;
    calories: string;
    servingQuantity: number;
    displayUnit: number;
}
