import { ConsumedMealIngredients } from './consumedMealIngredients';
import { IngredientMetadata } from './ingredientMetadata';

export interface SingleConsumedMeal {
    id: string;
    mealId: string;
    name: string;
    type: string;
    imageUrl: string;
    consumedDate: string;
    note: string;
    calories: number;
    protein: number;
    totalFat: number;
    saturatedFat: number;
    cholesterol: number;
    fiber: number;
    sugar: number;
    sodium: number;
    carbohydrate: number;
    ingredients?: Array<ConsumedMealIngredients>;
    metadata: IngredientMetadata;
}
