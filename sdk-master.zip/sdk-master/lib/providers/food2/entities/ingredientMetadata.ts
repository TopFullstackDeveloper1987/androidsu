export type IngredientMetadata = null | { [key: string]: unknown };
