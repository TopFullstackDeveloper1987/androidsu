export type NutritionSummaryDataOption =
    | 'calories'
    | 'protein'
    | 'carbohydrates'
    | 'fiber'
    | 'sugar'
    | 'potassium'
    | 'sodium'
    | 'totalFat'
    | 'saturatedFat'
    | 'cholesterol';
