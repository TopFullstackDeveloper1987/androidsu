/**
 * Meal
 */

import { FoodMealPlanSegment } from './foodMealPlanSegment';
import { FoodMealServingItem } from './foodMealServingItem';
import { TracedEntity } from '../../content/entities';
import { FoodMealSegment } from './foodMealSegment';

export interface MealV2 extends FoodMealSegment {
    /** Flag showing if meal is public (does not have associated account) */
    isPublic: boolean;
    /** List of servings for the meal. */
    servings: Array<FoodMealServingItem>;
    /** A collection of keys associated with a meal. */
    keys: Array<TracedEntity>;
    /** An array of associated meal plans. */
    mealPlans: Array<FoodMealPlanSegment>;
}
