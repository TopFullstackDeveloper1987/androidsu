/**
 * Interface for NutritionSummaryData
 */

export interface NutritionSummaryData {
    dailyAverage: number;
    total: number;
}
