/**
 * FoodRegion
 */

export type FoodRegion = 'US' | 'CA' | 'IL' | 'AU' | 'SA';
