/**
 * FoodMealServingEntry
 */

import { FoodMealSummary } from '../entities';

export interface FoodMealServingEntry extends FoodMealSummary {
    /** A description of a serving. */
    description: string;
    /** A measurement description. */
    measurementDescription?: string;
    /** Unit of a serving. */
    unit: string;
    /** Amount of a serving in the specified unit. */
    amount: number;
    /** Flag for default */
    isDefault?: boolean;
    /** External ID of a serving. */
    externalId?: string;
}
