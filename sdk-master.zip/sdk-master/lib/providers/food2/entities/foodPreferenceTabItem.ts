export interface FoodPreferenceTabItem {
    id: string;
    name: string;
    organization?: {
        id: string | number;
    };
    status: 'active' | 'inactive';
    type: {
        id: number;
        name: string;
        status: 'active' | 'inactive';
    };
    sortOrder?: number;
}
