/**
 * FoodPreferenceTabTypeItem
 */

export interface FoodPreferenceTabTypeItem {
    id: number;
    name: string;
    status: 'active' | 'inactive';
}
