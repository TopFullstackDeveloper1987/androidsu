/**
 * FoodMealServingItemSummarized
 */

import { FoodMealSummary } from '.';
import { FoodMealIngredient } from './foodMealIngredient';
import { FoodMealServingItem } from './foodMealServingItem';

export interface FoodMealServingItemSummarized
    extends FoodMealServingItem,
        FoodMealSummary {
    /** The amount of calories in a serving (mg) */
    calorie: number;
    /** Ingredient of this serving */
    ingredient: FoodMealIngredient;
}
