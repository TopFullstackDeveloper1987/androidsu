import { ApiService } from '../../services/api.service';
import { GetNutritionSummaryRequest } from './requests';
import { GetNutritionSummaryResponse } from './responses';

/**
 * Nutrition for clients and providers
 */
export class Nutrition {
    /**
     * Init Api Service
     */
    public constructor(private readonly apiService: ApiService) {}

    /**
     * Fetch Nutrition summary data
     * @param request must implement GetNutritionSummaryRequest
     * @returns FetchAllFoodResponse
     */
    public fetchSummary(
        request: GetNutritionSummaryRequest,
    ): Promise<Array<GetNutritionSummaryResponse>> {
        return this.apiService
            .request<{ data: Array<GetNutritionSummaryResponse> }>({
                endpoint: `/nutrition/summary`,
                method: `GET`,
                data: request,
                version: '2.0',
            })
            .then((response) => {
                return response.data;
            });
    }
}
