export { ConsultationListingResponse } from './consultationListingResponse.interface';
export { ConsultationResponse } from './consultationResponse.interface';
