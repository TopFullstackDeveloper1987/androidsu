export interface ConsultationListingRequest {
    clientId?: string;
    providerId?: string;
    startDate?: string;
    endDate?: string;
}
