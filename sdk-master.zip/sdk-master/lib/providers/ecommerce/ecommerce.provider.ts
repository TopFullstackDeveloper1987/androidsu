import { ApiService } from '../../services';
import {
    EcommerceCreateTokenRequest,
    EcommerceCreateExternalIdentifierRequest,
} from './requests';
import { EcommerceCreateTokenResponse } from './responses';

export class EcommerceProvider {
    public constructor(private readonly apiService: ApiService) {}

    /**
     * Creates an access token for a user that can be used access the ecommerce platform storefront API
     * @param request must implement interface EcommerceCreateTokenRequest
     * @returns Promise<EcommerceCreateTokenResponse>
     */
    public createToken(
        request: EcommerceCreateTokenRequest,
    ): Promise<EcommerceCreateTokenResponse> {
        return this.apiService.request({
            method: 'POST',
            endpoint: '/ecommerce/login/token',
            data: request,
            version: '1.0',
        });
    }

    public createExternalIdentifier(
        request: EcommerceCreateExternalIdentifierRequest,
    ): Promise<void> {
        return this.apiService.request({
            method: 'POST',
            endpoint: '/ecommerce/external-identifier',
            data: request,
            version: '1.0',
            sendRawError: true,
        });
    }
}
