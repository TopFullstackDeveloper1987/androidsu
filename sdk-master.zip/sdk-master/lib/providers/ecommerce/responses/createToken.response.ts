export interface EcommerceCreateTokenResponse {
    expiresAt: string;
    token: string;
    type: string;
}
