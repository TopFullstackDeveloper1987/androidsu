export interface EcommerceCreateTokenRequest {
    /** Only administrators can override the user account. Defaults to current user. */
    account?: string;
    /** Organization ID */
    organization?: string;
}
