export interface EcommerceCreateExternalIdentifierRequest {
    account?: string;
}
