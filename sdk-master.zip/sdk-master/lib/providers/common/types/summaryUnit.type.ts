export type SummaryUnit = 'day' | 'month';
