/**
 * Address Label
 */

export interface AddressLabel {
    id: string;
    name: string;
    description?: string;
}
