/**
 * Account
 */

export interface ReportAccount {
    id: string;
    firstName: string;
    lastName: string;
    startedAt?: {
        local: string;
        utc: string;
    };
}
