/**
 * Organization
 */

export interface ReportOrganization {
    id: string;
    name: string;
    hierarchyPath?: string[];
}
