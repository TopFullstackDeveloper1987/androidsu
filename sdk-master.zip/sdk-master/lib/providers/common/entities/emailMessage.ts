/**
 * Email Message
 */

export interface EmailMessage {
    from: string;
    to: string;
    subject: string;
    status: string;
    updatedAt: string;
    open: {
        count: number;
    };
}
