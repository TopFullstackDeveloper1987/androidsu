/**
 * ActiveStatus
 */

export type ActiveStatus = 'all' | 'active' | 'inactive';

export const activeStatuss: Array<ActiveStatus> = ['all', 'active', 'inactive'];
