export type SortDirection = 'asc' | 'desc';
