import { SortDirection } from './sortDirection';

export interface GenericSortProperty<T> {
    property: T;
    dir: SortDirection;
}
