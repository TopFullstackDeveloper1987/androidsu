// contact
export interface ContactItem {
    email: string;
    firstName: string;
    lastName: string;
    phone?: string;
}
