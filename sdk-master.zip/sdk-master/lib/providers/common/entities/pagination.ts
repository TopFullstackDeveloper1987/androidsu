import { ListResponse } from '.';

export type PageSize = 'all' | number;

export type PageOffset = number;

// pagination
export interface Pagination {
    next?: number;
    prev?: number;
    totalCount?: number;
}

export interface PagedResponse<T> extends ListResponse<T> {
    pagination: Pagination;
}
