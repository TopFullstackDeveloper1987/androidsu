// user account
export interface UserAccountItem {
    email: string;
    firstName: string;
    lastName: string;
    id: string;
}
