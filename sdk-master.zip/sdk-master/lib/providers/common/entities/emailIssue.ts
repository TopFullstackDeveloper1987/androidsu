/**
 * Email Issue
 */

export interface EmailIssue {
    type: string;
    reason: string;
    status: string;
    createdAt: string;
}
