import { NamedEntity } from './namedEntity';

export interface DescriptionEntity extends NamedEntity {
    description?: string;
}
