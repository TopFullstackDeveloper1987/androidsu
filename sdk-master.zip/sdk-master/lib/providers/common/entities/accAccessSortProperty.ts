/**
 * AccAccessSortProperty
 */

export type AccAccessSortProperty =
    | 'createdAt'
    | 'email'
    | 'firstName'
    | 'lastName'
    | 'associationDate';

export const accAccessSortPropertys: Array<AccAccessSortProperty> = [
    'createdAt',
    'email',
    'firstName',
    'lastName',
    'associationDate',
];
