/**
 * Interface for Notification Type
 */

export interface NotificationType {
    id: string;
    code: string;
}
