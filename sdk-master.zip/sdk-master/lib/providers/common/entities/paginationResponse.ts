export interface PaginationResponse {
    next?: number;
    prev?: number;
}
