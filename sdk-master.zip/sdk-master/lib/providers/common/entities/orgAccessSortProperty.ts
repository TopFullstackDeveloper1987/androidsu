/**
 * OrgAccessSortProperty
 */

export type OrgAccessSortProperty = 'name' | 'state';

export const orgAccessSortPropertys: Array<OrgAccessSortProperty> = [
    'name',
    'state',
];
