/**
 * EnabledType
 */

export type EnabledType = 'enabled' | 'disabled';
