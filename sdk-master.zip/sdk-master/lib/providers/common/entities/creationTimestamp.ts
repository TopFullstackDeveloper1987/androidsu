export interface CreationTimestamp {
    start?: string;
    end?: string;
}
