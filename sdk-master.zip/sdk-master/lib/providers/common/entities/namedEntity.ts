import { Entity } from './entity';

export interface NamedEntity extends Entity {
    name: string;
}
