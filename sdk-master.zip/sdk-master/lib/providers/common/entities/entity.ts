export interface Entity {
    id: string;
}
