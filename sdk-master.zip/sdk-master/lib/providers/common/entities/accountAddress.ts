import { AddressLabel } from './addressLabel';

export enum AddressTypeId {
    Firm = '1',
    GeneralDelivery = '2',
    HighRise = '3',
    POBox = '4',
    RuralRoute = '5',
    Street = '6',
}

export interface AccountAddress {
    id: string;
    name?: string;
    address1: string;
    address2?: string;
    city: string;
    postalCode?: string;
    stateProvince?: string;
    country: {
        id: string;
        name: string;
    };
    labels: Array<AddressLabel>;
    type?: {
        id: AddressTypeId;
        name: string;
    };
}
