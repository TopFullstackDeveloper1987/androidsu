/**
 * GET /content/preference
 */

export interface GetSingleContentPreferenceRequest {
    /** Organization to look hierarchy for. */
    organization: string;
}
