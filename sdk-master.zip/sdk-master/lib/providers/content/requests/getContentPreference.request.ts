/**
 * Interface for GET /content/preference
 */

export interface GetContentPreferenceRequest {
    /** Organization ID */
    organization: string;
}
