/**
 * Interface for DELETE /content/preference/:organization
 */

export interface DeleteContentPreferenceRequest {
    /** Organization ID */
    organization: string;
}
