/**
 * GET /content/:id/package
 */

import { Entity, ListResponse } from '../../common/entities';

export type GetAllContentPackageResponse = ListResponse<Entity>;
