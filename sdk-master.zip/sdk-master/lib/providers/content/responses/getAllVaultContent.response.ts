import { PagedResponse } from '../../common/entities';
import { VaultContentSingle } from './vaultContent.single';

export type GetAllVaultContentResponse = PagedResponse<VaultContentSingle>;
