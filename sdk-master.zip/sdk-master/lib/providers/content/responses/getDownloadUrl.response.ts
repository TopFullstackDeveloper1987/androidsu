export interface GetDownloadUrlResponse {
    url: string;
}
