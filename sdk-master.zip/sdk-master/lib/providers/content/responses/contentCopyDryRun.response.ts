/**
 * POST /content/copy/{id}/dry-run
 */

import { ContentCopyIssue } from '../entities';

export interface ContentCopyDryRunResponse {
    counter: {
        successful: number;
        warning: number;
    };
    issues: Array<ContentCopyIssue>;
}
