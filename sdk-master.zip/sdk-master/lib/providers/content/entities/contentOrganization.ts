/**
 * ContentOrganization
 */

export interface ContentOrganization {
    id: string;
    name?: string;
}
