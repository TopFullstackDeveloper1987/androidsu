export interface ContentSort {
    property: 'name' | 'createdAt';
    dir?: 'asc' | 'desc';
}
