import { NamedEntity } from '../../common/entities';

export interface ContentCopyIssue {
    item: NamedEntity;
    code: string;
    message: string;
}
