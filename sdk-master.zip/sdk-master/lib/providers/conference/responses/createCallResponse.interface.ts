/**
 * Interface for POST /conference/video/call (response)
 */

export interface CreateCallResponse {
    callId: string;
}
