/**
 * Interface for GET /conference/video/call/availability (response)
 */

export interface FetchCallAvailabilityResponse {
    isAvailable: boolean;
}
