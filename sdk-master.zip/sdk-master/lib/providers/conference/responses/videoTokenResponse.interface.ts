/**
 * Interface for POST /conference/video/token
 */

export interface VideoTokenResponse {
    jwt: string;
}
