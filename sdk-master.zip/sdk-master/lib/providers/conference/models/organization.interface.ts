export interface Organization {
    id: string;
}

export const initialOrganization: Organization = { id: '' };
