export interface Participant {
    id: string;
    lastName: string;
    firstName: string;
}

export const initialParticipant = { id: '', lastName: '', firstName: '' };
