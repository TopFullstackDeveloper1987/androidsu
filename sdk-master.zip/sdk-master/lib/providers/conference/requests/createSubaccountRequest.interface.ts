/**
 * Interface for POST /conference/subaccount
 */

export interface CreateSubaccountRequest {
    organization: string;
}
