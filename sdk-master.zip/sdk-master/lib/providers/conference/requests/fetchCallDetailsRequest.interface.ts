/**
 * Interface for GET /conference/subaccount
 */

export interface FetchCallDetailsRequest {
    callId: string;
}
