/**
 * Interface for GET /conference/video/token
 */

export interface VideoTokenRequest {
    callId: string;
}
