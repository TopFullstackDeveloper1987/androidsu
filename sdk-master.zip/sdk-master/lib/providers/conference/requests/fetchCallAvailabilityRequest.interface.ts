/**
 * Interface for GET /conference/video/call/availability
 */

export interface FetchCallAvailabilityRequest {
    account: string;
}
