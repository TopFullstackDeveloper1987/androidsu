/**
 * Interface for GET /conference/video/call/availability (request)
 *
 */

export interface FetchAvailabilityRequest {
    account: string;
}
