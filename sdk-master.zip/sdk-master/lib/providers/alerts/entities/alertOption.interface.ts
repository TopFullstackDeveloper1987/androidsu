/**
 * Alert Option
 */

export interface AlertOption {
    threshold: number;
}
