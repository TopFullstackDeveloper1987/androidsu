/**
 * Alert Type
 */

export enum AlertTypeId {
    WEIGHT_REGAINED = '1',
    INACTIVITY = '2',
    WEIGHT_THRESHOLD = '3',
    DATA_POINT_THRESHOLD = '4',
    DATA_POINT_MISSING = '5',
}

export interface AlertType {
    id: AlertTypeId;
    description: string;
    code: string;
}
