/**
 * Alert Account Preference
 */

import { AlertOrgPreference } from './preference.interface';

export interface AlertAccountPreference {
    preference: AlertOrgPreference;
}
