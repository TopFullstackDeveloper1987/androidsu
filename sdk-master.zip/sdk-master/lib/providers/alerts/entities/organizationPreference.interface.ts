/**
 * Organization Preference
 */

import { AlertOrgPreference } from './';

export interface AlertOrganizationPreference {
    id: string;
    preference: AlertOrgPreference;
}
