/**
 * Interface for Notifications
 */

import {
    Entity,
    NamedEntity,
    NotificationAccount,
    NotificationOrganization,
} from '../../common/entities';
import { NotificationTypeDetailed } from '../entities';
import { AlertsThresholdDirection } from './preference.interface';

export interface AlertsPayloadPreference {
    preference: {
        id: string;
        isOverridden: boolean;
    };
}

export interface AlertsPayloadAnalysis {
    period: string;
}

export interface AlertsWeightRegainedPayload {
    value: number;
    percentage: number;
}

export interface AlertsDataPointThresholdPayload {
    dataPoint: {
        group: Entity;
        type: NamedEntity;
        value: number;
    };

    options: {
        alert: AlertsPayloadPreference;

        threshold: {
            direction: AlertsThresholdDirection;
            value: number;
        };

        analysis: AlertsPayloadAnalysis;
    };
}

export interface AlertsAuditEntry {
    updatedAt: string;
    updatedBy: {
        id: string;
        firstName: string;
        lastName: string;
        email: string;
        type: Entity;
    };
}

export interface AlertsAudit {
    general?: AlertsAuditEntry;
    user?: AlertsAuditEntry;
}

export interface AlertsDataPointMissingPayload {
    dataPoint: {
        type: NamedEntity;
    };

    options: {
        alert: AlertsPayloadPreference;
        analysis: AlertsPayloadAnalysis;
    };
}

export type AlertsGenericPayload = Record<string, number | unknown>;

export type AlertNotificationPayload =
    | AlertsWeightRegainedPayload
    | AlertsDataPointThresholdPayload
    | AlertsDataPointMissingPayload
    | AlertsGenericPayload;

export interface AlertNotification {
    id: string;
    type: NotificationTypeDetailed;
    organization: NotificationOrganization;
    recipient: NotificationAccount;
    triggeredBy?: NotificationAccount;
    createdAt: string;
    viewed: boolean;
    payload?: AlertNotificationPayload;
    groupId?: string;
    audit?: AlertsAudit;
}
