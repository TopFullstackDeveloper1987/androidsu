/**
 * PATCH /warehouse/alert/notification/viewed/all and PATCH /warehouse/alert/notification/viewed/self
 */

export interface MarkNotificationsViewedRequest {
    /** Organization ID */
    organization: string;
}
