/**
 * Interface for /hwarehouse/alert/type
 */

export interface FetchAlertTypesRequest {
    limit?: 'all' | number;
    offset?: number;
}
