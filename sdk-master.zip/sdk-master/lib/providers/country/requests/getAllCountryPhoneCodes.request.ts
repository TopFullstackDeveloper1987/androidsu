export interface GetAllCountryPhoneCodesRequest {
    /** Country locale list of country phone codes that should be at the top of the list */
    firstCountries: string[];
}
