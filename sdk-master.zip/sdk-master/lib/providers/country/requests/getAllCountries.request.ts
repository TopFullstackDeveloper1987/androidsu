export interface GetAllCountriesRequest {
    offset?: number;
    query?: string;
    limit?: number | 'all';
}
