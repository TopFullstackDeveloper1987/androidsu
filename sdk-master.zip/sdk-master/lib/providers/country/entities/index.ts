export * from './countryCodes';
export * from './locales';

export interface Country {
    id: string;
    name: string;
}
