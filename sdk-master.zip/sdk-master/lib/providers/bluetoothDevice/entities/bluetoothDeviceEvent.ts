/**
 * Bluetooth Event
 */

import {
    DescriptionEntity,
    Entity,
    UserAccountItem,
} from '../../common/entities';

export interface BluetoothDeviceEvent {
    account: UserAccountItem;
    createdAt: string;
    device: Entity;
    id: string;
    note?: string;
    source?: DescriptionEntity;
    status?: DescriptionEntity;
}
