/**
 * Bluetooth Event Status
 */

export interface BluetoothDeviceStatus {
    id: string;
    name: string;
    description?: string;
    status: string;
    createdAt: string;
    updatedAt?: string;
}
