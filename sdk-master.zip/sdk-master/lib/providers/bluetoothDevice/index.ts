import {
    CreateBluetoothDeviceEventRequest,
    GetBluetootDeviceEventsStatusRequest,
    GetBluetoothDeviceEventsRequest,
} from './requests';

import { ApiService } from '../../services/api.service';
import { Entity } from '../common/entities';
import { GetBluetoothDeviceEventResponse } from './responses';
import { GetBluetoothDeviceStatusResponse } from './responses/getBluetoothDeviceStatusResponse.interface';

/**
 * Bluetooth Device provider service
 */
export class BluetoothDevice {
    public constructor(private readonly apiService: ApiService) {}

    /**
     * Retrieves the listing of all bluetooth events that are available for a user
     * @param request must implement GetBluetoothDeviceEventsRequest
     * @returns Promise<GetBluetoothDeviceEventResponse>
     */
    public getEvents(
        request: GetBluetoothDeviceEventsRequest,
    ): Promise<GetBluetoothDeviceEventResponse> {
        return this.apiService.request({
            data: request,
            endpoint: `/bluetooth-device/event`,
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Retrieves the listing of latest bluetooth events that are available for a user & measurement source
     * @param request must implement GetBluetoothDeviceEventsRequest
     * @returns Promise<GetBluetoothDeviceEventResponse>
     */
    public getLastestEvents(
        request: GetBluetoothDeviceEventsRequest,
    ): Promise<GetBluetoothDeviceEventResponse> {
        return this.apiService.request({
            data: request,
            endpoint: `/bluetooth-device/event/latest`,
            method: 'GET',
            version: '1.0',
        });
    }

    /**
     * Creates a bluetooth event for the calling user
     * @param request must implement CreateBluetoothDeviceEventRequest
     * @returns Promise<GetBluetoothDeviceEventResponse>
     */
    public createEvent(
        request: CreateBluetoothDeviceEventRequest,
    ): Promise<Entity> {
        return this.apiService.request({
            data: request,
            endpoint: `/bluetooth-device/event`,
            method: 'POST',
            version: '1.0',
        });
    }

    /**
     * Retrieves the listing of all statuses that are available for bluetooth events
     * @param request must implement GetBluetootDeviceEventsStatusRequest
     * @returns Promise<GetBluetoothDeviceStatusResponse>
     */
    public getEventStatus(
        request: GetBluetootDeviceEventsStatusRequest,
    ): Promise<GetBluetoothDeviceStatusResponse> {
        return this.apiService.request({
            data: request,
            endpoint: `/bluetooth-device/event/status`,
            method: 'GET',
            version: '1.0',
        });
    }
}
