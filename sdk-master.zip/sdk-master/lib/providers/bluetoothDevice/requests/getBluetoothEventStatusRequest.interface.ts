/**
 * Interface for /bluetooth-device/event/status
 */

export interface GetBluetootDeviceEventsStatusRequest {
    /** Status of event */
    status?: string;
    limit?: number | 'all';
    offset?: number;
}
