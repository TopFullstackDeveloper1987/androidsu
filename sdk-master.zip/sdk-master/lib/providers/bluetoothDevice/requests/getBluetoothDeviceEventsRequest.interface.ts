/**
 * Interface for /bluetooth-device/event
 */

import { CreationTimestamp } from '../../common/entities';

export interface GetBluetoothDeviceEventsRequest {
    /** Account filter of the recipient of the notification. Optional for Client requests, otherwise required. */
    account?: string;
    /** Data point source ID collection to filter by */
    source?: string[];
    /** Device identifier UUID. */
    identifier?: string;
    /** Status of event */
    status?: string;
    /** Creation timestamp filter. */
    createdAt?: CreationTimestamp;
    limit?: number | 'all';
    offset?: number;
}
