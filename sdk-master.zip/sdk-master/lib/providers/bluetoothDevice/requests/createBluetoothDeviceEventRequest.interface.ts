/**
 * Interface for /bluetooth-device/event
 */

export interface CreateBluetoothDeviceEventRequest {
    /** Account of the recipient of the notification. Optional for Client requests, otherwise required. */
    account?: string;
    /** Data point source ID collection */
    source?: string;
    /** Device identifier UUID. */
    device?: {
        id: string;
    };
    /** Status of event */
    status?: string;
    /** Optional note of the device synce */
    note?: string;
}
