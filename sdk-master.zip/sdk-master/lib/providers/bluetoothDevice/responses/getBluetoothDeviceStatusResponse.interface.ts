import { BluetoothDeviceStatus } from '../entities';
import { PaginationResponse } from '../../common/entities';

export interface GetBluetoothDeviceStatusResponse {
    data: Array<BluetoothDeviceStatus>;
    pagination: PaginationResponse;
}
