import { BluetoothDeviceEvent } from '../entities/bluetoothDeviceEvent';
import { PaginationResponse } from '../../common/entities';

export interface GetBluetoothDeviceEventResponse {
    data: Array<BluetoothDeviceEvent>;
    pagination: PaginationResponse;
}
