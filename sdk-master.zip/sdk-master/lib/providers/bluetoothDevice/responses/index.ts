export { GetBluetoothDeviceEventResponse } from './getBluetoothDeviceEventResponse.interface';
