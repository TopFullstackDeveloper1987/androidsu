/*
 * Export all interfaces
 */

export { FeedbackRequest } from './feedbackRequest.interface';
