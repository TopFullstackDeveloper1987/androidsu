/**
 * Interface for image type
 */

export interface ImageTypeInterface {
    name: string;
    base64: string;
}
