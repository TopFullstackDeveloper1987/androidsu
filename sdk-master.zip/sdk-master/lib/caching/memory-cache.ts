import { DeepPartial } from '../deep-partial';
import { merge } from 'lodash';

/**
 * Memory cache instance options
 */
export interface MemoryCacheOptions {
    /**
     * Time-to-live settings
     */
    readonly ttl: {
        /**
         * Number of milliseconds that any single entry will be kept in the cache
         */
        readonly milliseconds: number;
    };
}

type TimeoutHandle = ReturnType<typeof setTimeout>;

/**
 * Memory cache with a TTL expiration
 */
export class MemoryCache<T> {
    private readonly cache = new Map<string, [TimeoutHandle, T]>();
    private readonly options: MemoryCacheOptions;

    /**
     * Creates a new instance of the MemoryCache
     * @param options Memory cache options
     */
    public constructor(options?: DeepPartial<MemoryCacheOptions>) {
        this.options = merge(
            {},
            {
                ttl: {
                    milliseconds: 5000,
                },
            },
            options,
        );
    }

    /**
     * Sets the value under a given key.
     *
     * If a given key already exists in the cache, the cache entry is going to be overwritten.
     * @param key Cache key
     * @param value Value to cache
     */
    public set(key: string, value: T): void {
        this.remove(key);
        this.cache.set(key, [
            setTimeout(() => this.remove(key), this.options.ttl.milliseconds),
            value,
        ]);
    }

    /**
     * Gets a value from the cache.
     *
     * @param key Key to look up the value under
     * @returns The cached value, or `undefined` if the key is not in the cache.
     */
    public get(key: string): T | undefined {
        const entry = this.cache.get(key);
        if (entry === undefined) {
            return;
        }

        const [, value] = entry;

        return value;
    }

    /**
     * Removes a cache entry under a given key from the cache.
     *
     * @param key Key for which the entry should be removed from the cache
     */
    private remove(key: string): void {
        const entry = this.cache.get(key);
        if (entry === undefined) {
            return;
        }

        const [handle] = entry;

        clearTimeout(handle);
        this.cache.delete(key);
    }

    /**
     * Clears the cache.
     */
    public clear(): void {
        for (const [handle] of this.cache.values()) {
            clearTimeout(handle);
        }
        this.cache.clear();
    }
}
