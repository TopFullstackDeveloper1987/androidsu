import {
    AxiosAdapter,
    AxiosPromise,
    Method,
    CustomParamsSerializer,
} from 'axios';

import { MemoryCache } from './memory-cache';
import { chain } from 'lodash';

declare module 'axios' {
    interface AxiosRequestConfig {
        /**
         * Indicates if the cache should be skipped altogether for a specific request.
         *
         * Used exclusively by the cache adapter if the cache is globally enabled.
         *
         * @default false
         */
        skipCache?: boolean;
    }
}

/**
 * Caching adapter options
 */
export interface CachingAdapterOptions {
    /**
     * Headers to include in the cache key
     *
     * @default ['x-coachcare-organization', 'x-coachcare-organization-id']
     */
    readonly headers?: ReadonlyArray<string>;

    /**
     * Clears memory cache after a mutating request
     */
    clearCacheAfterMutation?: boolean;
}

/**
 * Creates a caching axios adapter
 * @param {AxiosAdapter} defaultAdapter Default adapter to delegate the requests to
 * @param {MemoryCache<AxiosPromise>} cache Cache instance
 * @param {CachingAdapterOptions} options Caching adapter
 * @returns An axios adapter
 */
export function createCachingAdapter(
    defaultAdapter: AxiosAdapter,
    cache: MemoryCache<AxiosPromise>,
    options?: CachingAdapterOptions,
): AxiosAdapter {
    const { headers } = options ?? {
        headers: ['x-coachcare-organization', 'x-coachcare-organization-id'],
    };

    const sortedHeaders = chain(headers)
        .sortBy()
        .map((h) => h.toLowerCase())
        .value();

    return function adapter(config) {
        const {
            method,
            baseURL,
            url,
            // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
            headers,
            // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
            params,
            paramsSerializer,
            skipCache,
        } = config;

        if (skipCache === true) {
            return defaultAdapter(config);
        }

        const normalizedMethod = method?.toUpperCase() as Method | undefined;

        if (
            !(
                normalizedMethod === 'OPTIONS' ||
                normalizedMethod === 'GET' ||
                normalizedMethod === 'HEAD'
            )
        ) {
            if (options?.clearCacheAfterMutation) {
                cache.clear();
            }
            return defaultAdapter(config);
        }

        const headerValues = chain(sortedHeaders)
            // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
            .map((h) => `${h}=${(headers?.[h] as string | undefined) ?? ''}`)
            .join('|')
            .value();

        const paramsString = chain(params)
            .toPairs()
            .sortBy(([k]) => k)
            .fromPairs()
            .value();

        let serializer: CustomParamsSerializer | undefined;

        if (paramsSerializer && 'serialize' in paramsSerializer) {
            serializer = paramsSerializer.serialize;
        } else {
            serializer = paramsSerializer as CustomParamsSerializer;
        }

        const key = `${normalizedMethod}::${baseURL ?? ''}::${url ?? ''}::${
            serializer?.(paramsString) ?? ''
        }::${headerValues}`;

        const cachedResponse = cache.get(key);
        if (cachedResponse !== undefined) {
            return cachedResponse;
        }

        const promise = defaultAdapter(config);
        cache.set(key, promise);
        return promise;
    };
}
