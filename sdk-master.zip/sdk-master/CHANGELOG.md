# [30.17.0](https://github.com/coachcare/sdk/compare/v30.16.2...v30.17.0) (2024-07-26)


### Bug Fixes

* **logging:** pass the originally provided axios adapter to child loggers ([2f542d1](https://github.com/coachcare/sdk/commit/2f542d199054b797c354fce5acc4f4847547d688))


### Features

* **logging:** add Sumologic async & background dispatch loggers ([5495f68](https://github.com/coachcare/sdk/commit/5495f683dc9b4d56568d7d4ead090941ef9b8861))

## [30.16.2](https://github.com/coachcare/sdk/compare/v30.16.1...v30.16.2) (2024-07-24)


### Bug Fixes

* adding production pain tracking form id - FRON-3538 ([e337232](https://github.com/coachcare/sdk/commit/e33723257aaa280128e3a84f3b3ff47f4f33e8e8))

## [30.16.1](https://github.com/coachcare/sdk/compare/v30.16.0...v30.16.1) (2024-07-17)


### Bug Fixes

* change datapoint group form type [FRON-3528] ([c29c93c](https://github.com/coachcare/sdk/commit/c29c93c7277bcede5fce1ad9f2efcafec8311d85))

# [30.16.0](https://github.com/coachcare/sdk/compare/v30.15.0...v30.16.0) (2024-07-17)


### Bug Fixes

* update to getLatestVersionResponse - MOB-4459 ([7922350](https://github.com/coachcare/sdk/commit/79223509516bb23839333cd44fd32d9e2b2125ab))


### Features

* add form submission metadata to data point [FRON-3528] ([21d573a](https://github.com/coachcare/sdk/commit/21d573a90014e9d4f7cffd84b28f645c8da09184))

# [30.15.0](https://github.com/coachcare/sdk/compare/v30.14.0...v30.15.0) (2024-07-11)


### Features

* add languages parameter to patient reports [FRON-3521] ([6695c27](https://github.com/coachcare/sdk/commit/6695c27f5f55bf4ce64e55150614f69e84649ded))

# [30.14.0](https://github.com/coachcare/sdk/compare/v30.13.0...v30.14.0) (2024-07-08)


### Bug Fixes

* change organization param to required ([13188fc](https://github.com/coachcare/sdk/commit/13188fc2ec8b3e4ed623c2d556a17563dad9049c))


### Features

* add mobile app latest version endpoint [MOB-4644] ([d645bdc](https://github.com/coachcare/sdk/commit/d645bdc9271c78b904ce8f07d108591d70f92863))

# [30.13.0](https://github.com/coachcare/sdk/compare/v30.12.1...v30.13.0) (2024-06-20)


### Features

* allow weight change percentage to be undefined[FRON-3517] ([47a051f](https://github.com/coachcare/sdk/commit/47a051f507a20aa0c9d3bd6b726808f21caf053d))

## [30.12.1](https://github.com/coachcare/sdk/compare/v30.12.0...v30.12.1) (2024-06-17)


### Bug Fixes

* update interaction single entity [FRON-3499] ([4142e85](https://github.com/coachcare/sdk/commit/4142e85a67899bc95b8f8904fe7ab6e75b71af61))

# [30.12.0](https://github.com/coachcare/sdk/compare/v30.11.0...v30.12.0) (2024-06-12)


### Features

* add patient activity report endpoint updates [FRON-3509] ([572a541](https://github.com/coachcare/sdk/commit/572a5418357e4a6d642de363c44adb46e14ddee2))

# [30.11.0](https://github.com/coachcare/sdk/compare/v30.10.0...v30.11.0) (2024-05-28)


### Features

* add billable service selection & interaction note [FRON-3489] ([ab1e6e0](https://github.com/coachcare/sdk/commit/ab1e6e000553dd12dcd17220548cc779cc484230))

# [30.10.0](https://github.com/coachcare/sdk/compare/v30.9.0...v30.10.0) (2024-05-23)


### Features

* include optional source and type collection for patient report generations [FRON-3494] ([3256ba3](https://github.com/coachcare/sdk/commit/3256ba3924fbafd25c135d745de981bf68dfe76e))

# [30.9.0](https://github.com/coachcare/sdk/compare/v30.8.0...v30.9.0) (2024-05-17)


### Features

* add audit information in alert notification [FRON-3481] ([e2656b1](https://github.com/coachcare/sdk/commit/e2656b102b3179f224ad987e1bdf922f195e9a62))

# [30.8.0](https://github.com/coachcare/sdk/compare/v30.7.0...v30.8.0) (2024-05-16)


### Features

* add plans payload to care management preference endpoints [FRON-3482] ([88e7796](https://github.com/coachcare/sdk/commit/88e7796f021f2a465112ae1088710513f2b9e824))

# [30.7.0](https://github.com/coachcare/sdk/compare/v30.6.0...v30.7.0) (2024-05-14)


### Features

* adding recipesOnly flag to meal plan interface - MOB-4602 ([76b851e](https://github.com/coachcare/sdk/commit/76b851e2541fdbea068673edf3a6f91e541dbb99))

# [30.6.0](https://github.com/coachcare/sdk/compare/v30.5.0...v30.6.0) (2024-05-13)


### Features

* add preference tab tracking locale methods [FRON-3436] ([ca45311](https://github.com/coachcare/sdk/commit/ca45311ca3dbe4eccedca49eff456efa9ad51a86))

# [30.5.0](https://github.com/coachcare/sdk/compare/v30.4.0...v30.5.0) (2024-05-13)


### Features

* update SDK with new food preference tab types methods[FRON-3436] ([b20d5c7](https://github.com/coachcare/sdk/commit/b20d5c7c24cf5e8c9de1848fc35d83b78923f37e))

# [30.4.0](https://github.com/coachcare/sdk/compare/v30.3.0...v30.4.0) (2024-05-13)


### Features

* add preference tab methods [FRON-3436] ([cf7c3db](https://github.com/coachcare/sdk/commit/cf7c3db00ef0078db31671c2695cae99d0e7bc14))

# [30.3.0](https://github.com/coachcare/sdk/compare/v30.2.0...v30.3.0) (2024-05-13)


### Features

* update SDK with new food preference tracking methods[FRON-3436] ([ec045ce](https://github.com/coachcare/sdk/commit/ec045ceb8921795b7058abaf4400efa48403c773))

# [30.2.0](https://github.com/coachcare/sdk/compare/v30.1.0...v30.2.0) (2024-05-08)


### Features

* add general inactivity alert option ([efea7d5](https://github.com/coachcare/sdk/commit/efea7d5b67322f468d998e1633e5d26b18ca2900))

# [30.1.0](https://github.com/coachcare/sdk/compare/v30.0.1...v30.1.0) (2024-05-07)


### Features

* add clinic code report endpoint [FRON-3458] ([88f0297](https://github.com/coachcare/sdk/commit/88f029766f304155e9f86513a2ff1c5071bc2ece))

## [30.0.1](https://github.com/coachcare/sdk/compare/v30.0.0...v30.0.1) (2024-04-26)


### Bug Fixes

* rxjs peerdependency [MOB-4586] ([5d69f16](https://github.com/coachcare/sdk/commit/5d69f164620e0e6174b914f27f6f88af2bab131d))

# [30.0.0](https://github.com/coachcare/sdk/compare/v29.3.0...v30.0.0) (2024-04-08)


### Code Refactoring

* remove food v1 interfaces [FRON-3403] ([46862f7](https://github.com/coachcare/sdk/commit/46862f7f4a96758cd3bed444730d9f85626ab893))


### BREAKING CHANGES

* Remove food v1 interfaces

# [29.3.0](https://github.com/coachcare/sdk/compare/v29.2.0...v29.3.0) (2024-04-01)


### Features

* add fetch consumed meals v3 [MOB-4537] ([457dc4c](https://github.com/coachcare/sdk/commit/457dc4c1420afcbca17bd411beece12b98288790))

# [29.2.0](https://github.com/coachcare/sdk/compare/v29.1.1...v29.2.0) (2024-03-28)


### Features

* add new create sequence transition endpoint [FRON-3415] ([d057e6c](https://github.com/coachcare/sdk/commit/d057e6ccd4e876decd6a81c817f33e00c6775aeb))

## [29.1.1](https://github.com/coachcare/sdk/compare/v29.1.0...v29.1.1) (2024-03-28)


### Reverts

* Revert "refactor: remove food v1 interfaces [FRON-3403]" ([bb0ef2d](https://github.com/coachcare/sdk/commit/bb0ef2d6bf9e22718a4344b405d6c4cca52b884c))

# [29.1.0](https://github.com/coachcare/sdk/compare/v29.0.0...v29.1.0) (2024-03-27)


### Features

* adding favorite record to meal response - MOB-4535 ([936a581](https://github.com/coachcare/sdk/commit/936a5817b1f5d0319e7d3b7ef446ae81c7a3049a))

# [29.0.0](https://github.com/coachcare/sdk/compare/v28.1.0...v29.0.0) (2024-03-27)


### Code Refactoring

* remove food v1 interfaces [FRON-3403] ([0e08d65](https://github.com/coachcare/sdk/commit/0e08d654eb23c96c4ef79780fc04092593c9d7b6))


### BREAKING CHANGES

* Remove food v1 interfaces

# [28.1.0](https://github.com/coachcare/sdk/compare/v28.0.2...v28.1.0) (2024-03-25)


### Features

* add insurance to patient [FRON-3439] ([7b0e117](https://github.com/coachcare/sdk/commit/7b0e117ba2a07e5fc98026c26d4a7441ab3dafe4))

## [28.0.2](https://github.com/coachcare/sdk/compare/v28.0.1...v28.0.2) (2024-03-20)


### Bug Fixes

* add fcmToken property to header options [MOB-4527] ([2a3c88c](https://github.com/coachcare/sdk/commit/2a3c88c6439990dd0cb7c6c3460c88022cab0659))

## [28.0.1](https://github.com/coachcare/sdk/compare/v28.0.0...v28.0.1) (2024-03-18)


### Bug Fixes

* add send raw error parameter to the request ([a6ebfb3](https://github.com/coachcare/sdk/commit/a6ebfb3bbb875406b86333243032b428fad2896d))

# [28.0.0](https://github.com/coachcare/sdk/compare/v27.3.0...v28.0.0) (2024-03-08)


### Features

* add device-agnostic cellular syncing endpoint [FRON-3409] ([f530ed5](https://github.com/coachcare/sdk/commit/f530ed59202558fb61aabd42c59e817bf863701c))


### BREAKING CHANGES

* remove per-device cellular syncing endpoint

# [27.3.0](https://github.com/coachcare/sdk/compare/v27.2.0...v27.3.0) (2024-03-05)


### Features

* add providerStore url property to org preferences [FRON-3417] ([4af1b15](https://github.com/coachcare/sdk/commit/4af1b15bef39ee7ad55e21dcf5d71ceb44ea2afe))

# [27.2.0](https://github.com/coachcare/sdk/compare/v27.1.0...v27.2.0) (2024-02-20)


### Features

* add referral to org preferences [FRON-3414] ([11bce80](https://github.com/coachcare/sdk/commit/11bce80ffebf25f2b1283799b0db5c002706ba7b))

# [27.1.0](https://github.com/coachcare/sdk/compare/v27.0.1...v27.1.0) (2024-02-06)


### Features

* add an optional id filter to organization access request [FRON-2891] ([7bba94d](https://github.com/coachcare/sdk/commit/7bba94d1dfae861ee012c2a5cd94559a28776c3a))

## [27.0.1](https://github.com/coachcare/sdk/compare/v27.0.0...v27.0.1) (2024-01-17)


### Bug Fixes

* axios defaults adapter issue [FRON-3404] ([ecd3701](https://github.com/coachcare/sdk/commit/ecd3701d014914fdb0e6c1c03e9284209875c417))

# [27.0.0](https://github.com/coachcare/sdk/compare/v26.13.0...v27.0.0) (2024-01-17)


### Features

* put back v1 food interfaces [FRON-3402] ([e6b9ea0](https://github.com/coachcare/sdk/commit/e6b9ea082658d2249ab98955f2a58473c1e119ef))


### BREAKING CHANGES

* put back v1 food interfaces

# [26.13.0](https://github.com/coachcare/sdk/compare/v26.12.1...v26.13.0) (2024-01-12)


### Features

* adding yarn.lock ([50910e5](https://github.com/coachcare/sdk/commit/50910e5b724953a2b8c95f2152095285eadd5e62))

## [26.12.1](https://github.com/coachcare/sdk/compare/v26.12.0...v26.12.1) (2024-01-09)


### Bug Fixes

* update params to optional - MOB-4442 ([fcdee43](https://github.com/coachcare/sdk/commit/fcdee4364b712509548a52125664ea5810f5f1f2))

# [26.12.0](https://github.com/coachcare/sdk/compare/v26.11.1...v26.12.0) (2024-01-08)


### Features

* add meal/account endpoint with revised data structure - MOB-4435 ([029ee5d](https://github.com/coachcare/sdk/commit/029ee5df870818554d7342772c9cbfad9130fb40))

## [26.11.1](https://github.com/coachcare/sdk/compare/v26.11.0...v26.11.1) (2024-01-03)


### Bug Fixes

* add fetch cellular endpoint exports ([b85daeb](https://github.com/coachcare/sdk/commit/b85daeb0af6f7a94e4c3805fdc0bac90f5a79e13))

# [26.11.0](https://github.com/coachcare/sdk/compare/v26.10.0...v26.11.0) (2023-12-27)


### Features

* add cellular device association collection endpoint [FRON-3394] ([195b227](https://github.com/coachcare/sdk/commit/195b227883487915dcc4bf7e2379d26a6b593d3e))

# [26.10.0](https://github.com/coachcare/sdk/compare/v26.9.1...v26.10.0) (2023-12-19)


### Features

* add notification parameter to association for creating a new account [FRON-3393] ([f6ea261](https://github.com/coachcare/sdk/commit/f6ea2610a0ba4f21f74c562a9c09e8e22e9b8bb0))

## [26.9.1](https://github.com/coachcare/sdk/compare/v26.9.0...v26.9.1) (2023-12-19)


### Bug Fixes

* add missing export for security provider ([26a7108](https://github.com/coachcare/sdk/commit/26a7108a6e3a24e8c61890c2fb875dec5102a312))

# [26.9.0](https://github.com/coachcare/sdk/compare/v26.8.0...v26.9.0) (2023-12-18)


### Features

* add exposed ip address whitelist endpoint [FRON-3390] ([5942e7c](https://github.com/coachcare/sdk/commit/5942e7c0208bf64969d0956dd5f2dcad77b285a3))

# [26.8.0](https://github.com/coachcare/sdk/compare/v26.7.0...v26.8.0) (2023-12-12)


### Features

* add endpoint for care management plan list [FRON-3377] ([6176bc2](https://github.com/coachcare/sdk/commit/6176bc2a5a21b689b8bb3de617ecd06284dc4eab))

# [26.7.0](https://github.com/coachcare/sdk/compare/v26.6.0...v26.7.0) (2023-12-04)


### Features

* add category to get data point label request [FRON-3380] ([f0f8dd4](https://github.com/coachcare/sdk/commit/f0f8dd4291e5afc686d73fb7b61df5c405a9c741))

# [26.6.0](https://github.com/coachcare/sdk/compare/v26.5.1...v26.6.0) (2023-12-01)


### Features

* add new coverages in billing code [FRON-3382] ([2f75f68](https://github.com/coachcare/sdk/commit/2f75f6857960e5cc20e50d05917aed8801a4048c))

## [26.5.1](https://github.com/coachcare/sdk/compare/v26.5.0...v26.5.1) (2023-11-29)


### Bug Fixes

* add conditional flag to dataTransmissionTypes request param ([e1d82fd](https://github.com/coachcare/sdk/commit/e1d82fd92638016493dc9aadf1891ea03e210443))

# [26.5.0](https://github.com/coachcare/sdk/compare/v26.4.1...v26.5.0) (2023-11-29)


### Features

* include data notification preference types on org care management preference ([70f44c9](https://github.com/coachcare/sdk/commit/70f44c92d6f9f0cdbfc1e4721fce98075f55c780))

## [26.4.1](https://github.com/coachcare/sdk/compare/v26.4.0...v26.4.1) (2023-11-13)


### Bug Fixes

* correct verb for mark notifications as read methods [FRON-3374] ([ea394c2](https://github.com/coachcare/sdk/commit/ea394c2591398d8df387c5de964b4170fefd9509))

# [26.4.0](https://github.com/coachcare/sdk/compare/v26.3.0...v26.4.0) (2023-11-01)


### Features

* add removeLastThreadParticipant property to messaging preference provider [FRON-3351] ([14b0026](https://github.com/coachcare/sdk/commit/14b0026493d1f8b4449ff9b566253fdc722daf85))

# [26.3.0](https://github.com/coachcare/sdk/compare/v26.2.0...v26.3.0) (2023-10-31)


### Features

* add mobile application metadata endpoint [FRON-3360] ([59bedd9](https://github.com/coachcare/sdk/commit/59bedd99b538aa12584ab8f61758a0147e4a9277))

# [26.2.0](https://github.com/coachcare/sdk/compare/v26.1.0...v26.2.0) (2023-10-27)


### Features

* adding optional param for sendRawError on client register - MOB-4378 ([6e9e948](https://github.com/coachcare/sdk/commit/6e9e948fb6a867934dd6839fa571051d44f02e11))

# [26.1.0](https://github.com/coachcare/sdk/compare/v26.0.0...v26.1.0) (2023-10-25)


### Features

* add emailVerification to ClientRegisterRequest - MOB-4376 ([a0f53cb](https://github.com/coachcare/sdk/commit/a0f53cb6722bf3fb69968e85b686c6969a2da8a1))

# [26.0.0](https://github.com/coachcare/sdk/compare/v25.5.2...v26.0.0) (2023-10-24)


### Features

* add service types to create bulk active seq enrollments [FRON-3297] ([bbd0531](https://github.com/coachcare/sdk/commit/bbd05317adfdf5518d42db11cd3610c4c0dd1a57))


### BREAKING CHANGES

* rename create seq enrollments requests interfaces

## [25.5.2](https://github.com/coachcare/sdk/compare/v25.5.1...v25.5.2) (2023-10-17)


### Bug Fixes

* add cellular device type [FRON-3318] ([adabf33](https://github.com/coachcare/sdk/commit/adabf332353cd5e2ff0cb0e0c3f09790d73bf435))

## [25.5.1](https://github.com/coachcare/sdk/compare/v25.5.0...v25.5.1) (2023-10-16)


### Bug Fixes

* add data-point summary missing properties ([ff3f956](https://github.com/coachcare/sdk/commit/ff3f9562836f3dab9e0e0df1fc7cd2037fbd3c9f))

# [25.5.0](https://github.com/coachcare/sdk/compare/v25.4.0...v25.5.0) (2023-10-09)


### Features

* add bodytrace history endpoint [FRON-3318] ([d5d333f](https://github.com/coachcare/sdk/commit/d5d333ffc43a507357437d42bc32b94088aa1a1f))

# [25.4.0](https://github.com/coachcare/sdk/compare/v25.3.0...v25.4.0) (2023-09-28)


### Features

* add billing and monitoring properties to care preference [FRON-3313] ([2b1f3f6](https://github.com/coachcare/sdk/commit/2b1f3f6aeb75aa6b2bb133bd6a5485e6c59eb642))

# [25.3.0](https://github.com/coachcare/sdk/compare/v25.2.0...v25.3.0) (2023-09-15)


### Features

* add bulk clear notifications endpoints [FRON-3320] ([1de0e60](https://github.com/coachcare/sdk/commit/1de0e6068478549f3cf4940771ec4c232a8050a6))

# [25.2.0](https://github.com/coachcare/sdk/compare/v25.1.0...v25.2.0) (2023-09-05)


### Features

* add timezone management on organization [FRON-3229] ([91f018a](https://github.com/coachcare/sdk/commit/91f018ab1720938ce45bc2cd0bef3314f282545c))

# [25.1.0](https://github.com/coachcare/sdk/compare/v25.0.0...v25.1.0) (2023-08-24)


### Features

* adding No pain UUID to SDK - MOB-4322 ([ca400f8](https://github.com/coachcare/sdk/commit/ca400f8ebf036e313cd2ae87258cfcd20d2ac9a3))

# [25.0.0](https://github.com/coachcare/sdk/compare/v24.13.0...v25.0.0) (2023-07-19)


### Features

* remove Levl integration [FRON-3243] ([6818e9d](https://github.com/coachcare/sdk/commit/6818e9d27aff97933b8b75c8f007785694136a9b))


### BREAKING CHANGES

* remove levl references

# [24.13.0](https://github.com/coachcare/sdk/compare/v24.12.2...v24.13.0) (2023-07-19)


### Features

* add automatic time tracking property for care management ([2c4c613](https://github.com/coachcare/sdk/commit/2c4c613b0e7f02fd26abca4fbb4a0818b2abe902))

## [24.12.2](https://github.com/coachcare/sdk/compare/v24.12.1...v24.12.2) (2023-07-18)


### Bug Fixes

* fixing createEvent interface - MOB-4284 ([4b19b06](https://github.com/coachcare/sdk/commit/4b19b0602483a9eb947927a9cfdf6c576f5b6060))

## [24.12.1](https://github.com/coachcare/sdk/compare/v24.12.0...v24.12.1) (2023-07-10)


### Bug Fixes

* added recordedAt property to measurement data point single [FRON-3183] ([8f6dfa3](https://github.com/coachcare/sdk/commit/8f6dfa375cc76a66d235a1a3b2874391f103222a))

# [24.12.0](https://github.com/coachcare/sdk/compare/v24.11.1...v24.12.0) (2023-07-06)


### Features

* adding bluetooth device provider - MOB-4272 ([19c5983](https://github.com/coachcare/sdk/commit/19c59835b0f9c180d14f5b66af5be2f8f5125ee0))

## [24.11.1](https://github.com/coachcare/sdk/compare/v24.11.0...v24.11.1) (2023-07-05)


### Bug Fixes

* add missing state property to billing monthly item [FRON-3209] ([942fae9](https://github.com/coachcare/sdk/commit/942fae9722bc942310dae6e74fc2b38cfa49fa42))

# [24.11.0](https://github.com/coachcare/sdk/compare/v24.10.0...v24.11.0) (2023-07-05)


### Features

* add triggers property to projectedTransition ([3c4cea4](https://github.com/coachcare/sdk/commit/3c4cea461cd9b7c4c37d1dc41f1bd8435eaffc4f))

# [24.10.0](https://github.com/coachcare/sdk/compare/v24.9.0...v24.10.0) (2023-06-28)


### Features

* add packages param to BulkOrganizationSeqEnrollmentsRequest ([360b5f9](https://github.com/coachcare/sdk/commit/360b5f99dfd241554febcca9152cc3f05970e0df))

# [24.9.0](https://github.com/coachcare/sdk/compare/v24.8.0...v24.9.0) (2023-06-20)


### Features

* add bodytrace sync endpoint ([84f9ae6](https://github.com/coachcare/sdk/commit/84f9ae60a19a42887630adcfd895e8c38c18dfed))
* add bodytrace sync endpoint ([fb2140f](https://github.com/coachcare/sdk/commit/fb2140f25cd9aa5dfdd46a790141d1c9b7f89957))

# [24.8.0](https://github.com/coachcare/sdk/compare/v24.7.0...v24.8.0) (2023-05-24)


### Features

* add billing code requirements to sdk ([af3ac2c](https://github.com/coachcare/sdk/commit/af3ac2c3a25a648cd04dcad88b3bc68aea363e6d))

# [24.7.0](https://github.com/coachcare/sdk/compare/v24.6.0...v24.7.0) (2023-05-19)


### Features

* add sharp custom report endpoint ([e3d7077](https://github.com/coachcare/sdk/commit/e3d7077e046e333d8fbaeb451c8c789f05f7a781))

# [24.6.0](https://github.com/coachcare/sdk/compare/v24.5.0...v24.6.0) (2023-05-18)


### Features

* adding new cellular device sdk implementation ([498ef79](https://github.com/coachcare/sdk/commit/498ef798a2dd0db06d8f38cf7e357c1fa46b0cc9))

# [24.5.0](https://github.com/coachcare/sdk/compare/v24.4.0...v24.5.0) (2023-05-10)


### Features

* adding awaken180 headers - MOB-4210 ([444279e](https://github.com/coachcare/sdk/commit/444279e8a51ac2495ef037db72b921326bd26e55))

# [24.4.0](https://github.com/coachcare/sdk/compare/v24.3.0...v24.4.0) (2023-05-09)


### Features

* add care-management billing codes endpoint ([d002880](https://github.com/coachcare/sdk/commit/d0028803bdcb1013920c047b0a71e6faf4a20cdf))

# [24.3.0](https://github.com/coachcare/sdk/compare/v24.2.0...v24.3.0) (2023-05-02)


### Features

* add care-management reporting endpoints ([cceb219](https://github.com/coachcare/sdk/commit/cceb219f8382c7af5e6d58c0556ee1299175c635))

# [24.2.0](https://github.com/coachcare/sdk/compare/v24.1.3...v24.2.0) (2023-04-29)


### Bug Fixes

* add missing properties ([111ea89](https://github.com/coachcare/sdk/commit/111ea898d945798128cc78b2aff7d59b1bb467df))
* made receivedDevice optional ([3709868](https://github.com/coachcare/sdk/commit/3709868b5239bf0b49d8a67e6c5758a2e9e07097))
* two small type corrections ([0fb1c4f](https://github.com/coachcare/sdk/commit/0fb1c4f87aa8d8a52a48073a05dd3d39b30035ea))


### Features

* add care management state provider [FRON-3089] ([b7e88cc](https://github.com/coachcare/sdk/commit/b7e88cc68e3825e5311437c54b3c1d586fda87b4))

## [24.1.3](https://github.com/coachcare/sdk/compare/v24.1.2...v24.1.3) (2023-04-26)


### Bug Fixes

* remove org header from fetch addresses GET request ([3de8c78](https://github.com/coachcare/sdk/commit/3de8c7899db0d16abd52414babd11cdb03bf0600))

## [24.1.2](https://github.com/coachcare/sdk/compare/v24.1.1...v24.1.2) (2023-04-26)


### Bug Fixes

* omit organization header from call to set preferred organization ([99f5011](https://github.com/coachcare/sdk/commit/99f5011402e29729632cda591ccddb88ef2ba3eb))

## [24.1.1](https://github.com/coachcare/sdk/compare/v24.1.0...v24.1.1) (2023-04-25)


### Bug Fixes

* remove required organization param from ecommerce createToken endpoint ([f26bd58](https://github.com/coachcare/sdk/commit/f26bd58e8a59fd85368bb6c6baa4749a5018203e))

# [24.1.0](https://github.com/coachcare/sdk/compare/v24.0.0...v24.1.0) (2023-04-25)


### Bug Fixes

* add status property ([8e99f85](https://github.com/coachcare/sdk/commit/8e99f85eb29ebf027acec4768c33d55aaf5f3bc4))
* add updateAt property ([d537c14](https://github.com/coachcare/sdk/commit/d537c14c0a30283457b68c138641f3d68c046437))


### Features

* add account care management service type endpoints [FRON-3091] ([eab8238](https://github.com/coachcare/sdk/commit/eab8238257e255783d1e8ec91f3f6355896f9037))

# [24.0.0](https://github.com/coachcare/sdk/compare/v23.8.0...v24.0.0) (2023-04-18)


### Features

* add care management endpoints [FRON-3066] ([0a52f7a](https://github.com/coachcare/sdk/commit/0a52f7aa77b3c22305a5b5d503b9ceb0008873d9))


### BREAKING CHANGES

* remove rpm preference endpoints

chore: rename provider for care management preference

chore: change directory

chore: fixing import/export

fix: missing import and make option for isSubscriptionTarget

fix: change type to serviceType for create care prefs

chore: add care management service type id

fix: type

feat: add care management provider

chore: rename more clearly

fix: type of care management preference

# [23.8.0](https://github.com/coachcare/sdk/compare/v23.7.0...v23.8.0) (2023-04-17)


### Features

* add endpoint for ecommerce createExternalIdentifier api ([f3c37e9](https://github.com/coachcare/sdk/commit/f3c37e9b25ca80484656f41b73819389d04a4b81))

# [23.7.0](https://github.com/coachcare/sdk/compare/v23.6.0...v23.7.0) (2023-04-05)


### Features

* add billing filter property [FRON-3014] ([34553dc](https://github.com/coachcare/sdk/commit/34553dcb479d4cf086898d2f0b3efc2c2a604f60))

# [23.6.0](https://github.com/coachcare/sdk/compare/v23.5.1...v23.6.0) (2023-03-15)


### Features

* adding PSI to sdk - MOB-4155 ([e938436](https://github.com/coachcare/sdk/commit/e938436541506ea148013a1af21b8e7cfb7cb59c))

## [23.5.1](https://github.com/coachcare/sdk/compare/v23.5.0...v23.5.1) (2023-03-14)


### Bug Fixes

* updating wrong uuid values in pain enum ([33e3209](https://github.com/coachcare/sdk/commit/33e3209acb12d9379c90d3e8ec5f2dbc836e65ac))

# [23.5.0](https://github.com/coachcare/sdk/compare/v23.4.0...v23.5.0) (2023-03-14)


### Features

* add endpoints for spree subscriptions ([82ed04d](https://github.com/coachcare/sdk/commit/82ed04d80de85508b6f0e3814141757b76eca7d4))

# [23.4.0](https://github.com/coachcare/sdk/compare/v23.3.0...v23.4.0) (2023-03-14)


### Features

* add functionalities for account email [FRON-3016] ([920c943](https://github.com/coachcare/sdk/commit/920c943c7ee0a7d6bb7785fede4d6650a0cbe878))

# [23.3.0](https://github.com/coachcare/sdk/compare/v23.2.2...v23.3.0) (2023-03-14)


### Features

* add endpoints for spree subscriptions ([fba052e](https://github.com/coachcare/sdk/commit/fba052e7d94263c9ca7b0d0512e2c260491e0894))

## [23.2.2](https://github.com/coachcare/sdk/compare/v23.2.1...v23.2.2) (2023-03-08)


### Bug Fixes

* exporting MeasurementDataPointGroupLabelProvider from root - MOB-4150 ([329e88c](https://github.com/coachcare/sdk/commit/329e88cfcbec330bb453de5f80602c914252605d))

## [23.2.1](https://github.com/coachcare/sdk/compare/v23.2.0...v23.2.1) (2023-03-08)


### Bug Fixes

* add external identifiers property to rpm monthly summary item [FRON-3033] ([ed2ed35](https://github.com/coachcare/sdk/commit/ed2ed35658ded9e4d4ada53253ecbc6b4e74b5b1))

# [23.2.0](https://github.com/coachcare/sdk/compare/v23.1.2...v23.2.0) (2023-03-07)


### Features

* adding pain metadata measurement group interface - MOB-4147 ([f5ecd37](https://github.com/coachcare/sdk/commit/f5ecd374b0a494d5a823a752c8eaf634edfaaf25))

## [23.1.2](https://github.com/coachcare/sdk/compare/v23.1.1...v23.1.2) (2023-03-06)


### Bug Fixes

* adding export to pain types - MOB-4144 ([3dbf87d](https://github.com/coachcare/sdk/commit/3dbf87d04b57060f709da4979addb0816ca5779f))

## [23.1.1](https://github.com/coachcare/sdk/compare/v23.1.0...v23.1.1) (2023-03-03)


### Bug Fixes

* add external identifiers to rpm state summary item [FRON-3033] ([6486b79](https://github.com/coachcare/sdk/commit/6486b7959115fb45e2523fc6f4d15009d90dea88))

# [23.1.0](https://github.com/coachcare/sdk/compare/v23.0.1...v23.1.0) (2023-02-27)


### Features

* adding exports and data group label enum ([6886854](https://github.com/coachcare/sdk/commit/688685493e517d375574c307b672fda9bb247d68))

## [23.0.1](https://github.com/coachcare/sdk/compare/v23.0.0...v23.0.1) (2023-02-16)


### Bug Fixes

* type of fetch rpm monthly billing summary response ([6740f11](https://github.com/coachcare/sdk/commit/6740f11c060ba2527cfaea5665a1e9596e077691))

# [23.0.0](https://github.com/coachcare/sdk/compare/v22.13.0...v23.0.0) (2023-02-14)


### Features

* remove deprecated avatar v2 endpoints [FRON-3051] ([69b5c6d](https://github.com/coachcare/sdk/commit/69b5c6d83d809b1021266f185d8832f4875369e7))


### BREAKING CHANGES

* Remove deprecated functionalities for avatar v2 endpoints

# [22.13.0](https://github.com/coachcare/sdk/compare/v22.12.1...v22.13.0) (2023-02-10)


### Features

* add function for get latest enrollments [FRON-3035] ([ce54ae4](https://github.com/coachcare/sdk/commit/ce54ae4acf4cd9285db002d2997ec61e275d1615))

## [22.12.1](https://github.com/coachcare/sdk/compare/v22.12.0...v22.12.1) (2023-02-10)


### Bug Fixes

* use correct type of status in updating supervising provider [FRON-3041] ([044e539](https://github.com/coachcare/sdk/commit/044e539a1eee1c7f7264f888078dd7f3356ccfdd))

# [22.12.0](https://github.com/coachcare/sdk/compare/v22.11.0...v22.12.0) (2023-02-09)


### Features

* adding pain tracking endpoints - MOB-4127 ([c046548](https://github.com/coachcare/sdk/commit/c046548db1a3a8bab12c3c6cdd27bbfbbc3ce131))

# [22.11.0](https://github.com/coachcare/sdk/compare/v22.10.0...v22.11.0) (2023-02-07)


### Features

* add pain management data point types - MOB-4124 ([9f61640](https://github.com/coachcare/sdk/commit/9f616406e1a1822fe19ef60233b65f7b80b87801))

# [22.10.0](https://github.com/coachcare/sdk/compare/v22.9.0...v22.10.0) (2023-02-07)


### Features

* add updating supervising provider on state [FRON-3041] ([13591a3](https://github.com/coachcare/sdk/commit/13591a3876d2e8188f8feba3846c87d9f1f68689))

# [22.9.0](https://github.com/coachcare/sdk/compare/v22.8.0...v22.9.0) (2023-01-27)


### Features

* added RPM monthly billing summary ([6da24e0](https://github.com/coachcare/sdk/commit/6da24e04bb332ae26a3e475726d29d0226908bc9))

# [22.8.0](https://github.com/coachcare/sdk/compare/v22.7.1...v22.8.0) (2023-01-23)


### Features

* add auto address suggestion [FRON-2971] ([904699b](https://github.com/coachcare/sdk/commit/904699b90ecae1127d574e7ff6230b808984b66e))

## [22.7.1](https://github.com/coachcare/sdk/compare/v22.7.0...v22.7.1) (2023-01-20)


### Bug Fixes

* add active status to bulk export parameters [FRON-3017] ([d91fe22](https://github.com/coachcare/sdk/commit/d91fe22e541c50e4cdf39fc753de486a44b7a6d7))

# [22.7.0](https://github.com/coachcare/sdk/compare/v22.6.0...v22.7.0) (2022-12-20)


### Features

* add endpoint for clone measurement template [FRON-2873] ([8faab23](https://github.com/coachcare/sdk/commit/8faab230e4dcf9a7669df184677846a5c3efaa36))

# [22.6.0](https://github.com/coachcare/sdk/compare/v22.5.0...v22.6.0) (2022-11-25)


### Features

* add smarty type to account address ([226143a](https://github.com/coachcare/sdk/commit/226143a51e57f14ae0420299589f8d43c0808a49))

# [22.5.0](https://github.com/coachcare/sdk/compare/v22.4.1...v22.5.0) (2022-11-23)


### Features

* add send raw error option to request options [FRON-2827] ([d81e3dd](https://github.com/coachcare/sdk/commit/d81e3ddc3f266f5408bab35b946cf78b9c023b76))

## [22.4.1](https://github.com/coachcare/sdk/compare/v22.4.0...v22.4.1) (2022-11-22)


### Bug Fixes

* add timezone property to account type [FRON-2955] ([dd828e0](https://github.com/coachcare/sdk/commit/dd828e099dfb36615e00fba45393a66288f3b195))

# [22.4.0](https://github.com/coachcare/sdk/compare/v22.3.0...v22.4.0) (2022-11-21)


### Features

* add method to get address suggestions from spree ([baa9f4e](https://github.com/coachcare/sdk/commit/baa9f4ecdbb96c9a9bec5998bbfc9c35aa69a50a))
* add verification field to the create/update address requests ([de8c833](https://github.com/coachcare/sdk/commit/de8c8337a04f78884152782a5f919e2bd8a9e332))

# [22.3.0](https://github.com/coachcare/sdk/compare/v22.2.0...v22.3.0) (2022-11-17)


### Features

* add method for get deep link types [FRON-2979] ([d31662a](https://github.com/coachcare/sdk/commit/d31662a6925e3f04c787f4ae398f4ebedcfaaa8d))

# [22.2.0](https://github.com/coachcare/sdk/compare/v22.1.0...v22.2.0) (2022-11-14)


### Features

* add endpoint for test password reset [FRON-2827] ([ad34ae8](https://github.com/coachcare/sdk/commit/ad34ae851d51f054bc81875b56fa5b176d5c11d7))

# [22.1.0](https://github.com/coachcare/sdk/compare/v22.0.0...v22.1.0) (2022-10-27)


### Features

* adding resting heart rate to DataPointTypes enum - MOB-3997 ([a2435a9](https://github.com/coachcare/sdk/commit/a2435a93fdccc301a67a52736198955487676dcd))

# [22.0.0](https://github.com/coachcare/sdk/compare/v21.7.3...v22.0.0) (2022-10-27)


### Features

* use goal v2 endpoints [FRON-2949] ([18a7d1f](https://github.com/coachcare/sdk/commit/18a7d1fe70797158777297c77aa574306832e88c))


### BREAKING CHANGES

* remove deprecated goal v1 endpoints

## [21.7.3](https://github.com/coachcare/sdk/compare/v21.7.2...v21.7.3) (2022-10-26)


### Bug Fixes

* filter null value in request headers [FRON-2928] ([d57643d](https://github.com/coachcare/sdk/commit/d57643d2ef39ff9e6830ba56df64f32ea9413298))

## [21.7.2](https://github.com/coachcare/sdk/compare/v21.7.1...v21.7.2) (2022-10-24)


### Bug Fixes

* update property types for task entry [FRON-2924] ([36e1e7f](https://github.com/coachcare/sdk/commit/36e1e7fe7a7ad3b191fa837abf9139da2480c1f4))

## [21.7.1](https://github.com/coachcare/sdk/compare/v21.7.0...v21.7.1) (2022-10-20)


### Bug Fixes

* add missing properties for filter rpm report by supervisor [FRON-2959] ([2635835](https://github.com/coachcare/sdk/commit/2635835835dbbf27f4f5fd471a617194cf1dbe6b))

# [21.7.0](https://github.com/coachcare/sdk/compare/v21.6.0...v21.7.0) (2022-10-18)


### Features

* add params to spree getOrders endpoint ([9bc17f8](https://github.com/coachcare/sdk/commit/9bc17f85f10526d9bc0cc648f067196719694a3d))

# [21.6.0](https://github.com/coachcare/sdk/compare/v21.5.0...v21.6.0) (2022-10-11)


### Features

* add current store to SDK ([77841f4](https://github.com/coachcare/sdk/commit/77841f4139d4fd488c665c96003cbbd50b735d2d))

# [21.5.0](https://github.com/coachcare/sdk/compare/v21.4.1...v21.5.0) (2022-10-07)


### Bug Fixes

* add package property to rpm billing request [FRON-2921] ([2367cce](https://github.com/coachcare/sdk/commit/2367cce10c1d828d1800bc1a78106ba676ef17d6))


### Features

* add faviconFilename to UpdateOrganizationPreferenceRequest [FRON-2895] ([1d986a1](https://github.com/coachcare/sdk/commit/1d986a167480273e8eafeb3574bc1b2f79631060))

## [21.4.1](https://github.com/coachcare/sdk/compare/v21.4.0...v21.4.1) (2022-09-29)


### Bug Fixes

* response of get NXTSTIM summary [FRON-2956] ([1ede5ff](https://github.com/coachcare/sdk/commit/1ede5ff7579aa0d4021af0eb62e5a85ec84441e9))

# [21.4.0](https://github.com/coachcare/sdk/compare/v21.3.0...v21.4.0) (2022-09-29)


### Features

* add endpoint for fetch NXTSTIM data point summary [FRON-2956] ([6c0656d](https://github.com/coachcare/sdk/commit/6c0656dcf1e7f15ef5ede675b83c0a57ba207e4f))

# [21.3.0](https://github.com/coachcare/sdk/compare/v21.2.0...v21.3.0) (2022-09-28)


### Bug Fixes

* typo, use correct type ([8706471](https://github.com/coachcare/sdk/commit/870647187de2bda8e829bcb29a30e6624b7b9213))


### Features

* add endpoints for task [FRON-2924] ([670e58b](https://github.com/coachcare/sdk/commit/670e58b4ae9fc8a8297483570bb2b85a20cf9ae6))

# [21.2.0](https://github.com/coachcare/sdk/compare/v21.1.1...v21.2.0) (2022-09-16)


### Features

* add diagnosis property to rpm item [FRON-2914] ([3020c48](https://github.com/coachcare/sdk/commit/3020c48d8f7c80452ee5d8640cefc9cf24190544))
* add Stripe intent confirmation to the SDK [FRON-2931] ([38b035b](https://github.com/coachcare/sdk/commit/38b035b8c3025d4755ecf8b96b890ae9374e52a7))

## [21.1.1](https://github.com/coachcare/sdk/compare/v21.1.0...v21.1.1) (2022-09-13)


### Bug Fixes

* adding file vault types to provider - MOB-3941 ([99ad17b](https://github.com/coachcare/sdk/commit/99ad17b0789958970837dbf638d778601cd83bae))

# [21.1.0](https://github.com/coachcare/sdk/compare/v21.0.2...v21.1.0) (2022-08-23)


### Features

* add supervisingProvider field to RPM item [FRON-2916] ([b70c6dd](https://github.com/coachcare/sdk/commit/b70c6dd38e5e7e9a6a64e326e5a93572e0f16537))

## [21.0.2](https://github.com/coachcare/sdk/compare/v21.0.1...v21.0.2) (2022-08-22)


### Bug Fixes

* updating meal records to include notice - MOB-3920 ([a7e31b9](https://github.com/coachcare/sdk/commit/a7e31b9de41318d19da6f5809961f28e1c397411))

## [21.0.1](https://github.com/coachcare/sdk/compare/v21.0.0...v21.0.1) (2022-08-09)


### Bug Fixes

* add package param to notification request [FRON-2855] ([bdaf2a8](https://github.com/coachcare/sdk/commit/bdaf2a89408e8c57a511de613972910b4599afbb))

# [21.0.0](https://github.com/coachcare/sdk/compare/v20.0.2...v21.0.0) (2022-07-21)


### Bug Fixes

* remove blueinfy env ([3b38bcf](https://github.com/coachcare/sdk/commit/3b38bcfa95e15170c925306b02841fe900c8cfb4))


### BREAKING CHANGES

* This removes the existing blueinfy environment

## [20.0.2](https://github.com/coachcare/sdk/compare/v20.0.1...v20.0.2) (2022-07-11)


### Bug Fixes

* add rpm field to notification request [FRON-2867] ([c6ff6d7](https://github.com/coachcare/sdk/commit/c6ff6d70b9ae52fcb51efa699422e711d6ed7546))

## [20.0.1](https://github.com/coachcare/sdk/compare/v20.0.0...v20.0.1) (2022-06-30)


### Bug Fixes

* added alertSelection property [FRON-2852] ([4900737](https://github.com/coachcare/sdk/commit/49007370711dab6f7aaaecd919c908fbfbce53bf))

# [20.0.0](https://github.com/coachcare/sdk/compare/v19.3.1...v20.0.0) (2022-06-30)


### Features

* added support for the new alert types [FRON-2852] ([0b5d253](https://github.com/coachcare/sdk/commit/0b5d253f6962332f72edb9dc5b4ddee2f9d1759d))


### BREAKING CHANGES

* some alert type definitions became stricter

## [19.3.1](https://github.com/coachcare/sdk/compare/v19.3.0...v19.3.1) (2022-06-24)


### Bug Fixes

* dont pass org context on marking messages as read ([f5437f9](https://github.com/coachcare/sdk/commit/f5437f9c5934b40ad0e9e047d8e6d84b635a9dc9))
* formatting correction ([7c5b8ca](https://github.com/coachcare/sdk/commit/7c5b8caa919221b697dcac12e3d570eed22222f2))

# [19.3.0](https://github.com/coachcare/sdk/compare/v19.2.0...v19.3.0) (2022-06-22)


### Features

* adding more optional HeaderOptions to sdk - MOB-3834 ([b84967d](https://github.com/coachcare/sdk/commit/b84967d6bc8406042a5905b5da81d553d62a7dd4))

# [19.2.0](https://github.com/coachcare/sdk/compare/v19.1.0...v19.2.0) (2022-06-08)


### Bug Fixes

* updating GetMeasurementDataPointSnapshotResponse interface - MOB-3814 ([4f15b29](https://github.com/coachcare/sdk/commit/4f15b29bbe05369c1b7f09b1920254cbf429688c))


### Features

* added new spree endpoints [FRON-2731] ([32ac6e2](https://github.com/coachcare/sdk/commit/32ac6e2e2a7977e480ae1bc2612723138ab6b1b3))

# [19.1.0](https://github.com/coachcare/sdk/compare/v19.0.2...v19.1.0) (2022-06-02)


### Features

* added missing property in credit card entry [FRON-2729] ([bf92d81](https://github.com/coachcare/sdk/commit/bf92d81bb2a5185736e7bb1b9bd7424ce0f7408f))

## [19.0.2](https://github.com/coachcare/sdk/compare/v19.0.1...v19.0.2) (2022-05-27)


### Bug Fixes

* added sort property to aggregates request [FRON-2733] ([bca587a](https://github.com/coachcare/sdk/commit/bca587aee193b0af55f6086776dbc90b4144a1e6))

## [19.0.1](https://github.com/coachcare/sdk/compare/v19.0.0...v19.0.1) (2022-05-27)


### Bug Fixes

* adjusted thorax type [FRON-2813] ([4d3e351](https://github.com/coachcare/sdk/commit/4d3e351a2e3802b02cf2d64cd83d67a42685515d))

# [19.0.0](https://github.com/coachcare/sdk/compare/v18.0.1...v19.0.0) (2022-05-24)


### Bug Fixes

* added glucose, and two more data types [FRON-2807] ([aa98e77](https://github.com/coachcare/sdk/commit/aa98e77601b1ef762e18973e690f6480dc989d86))


### BREAKING CHANGES

* FASTING_GLOCOSE has been renamed to FASTING_GLUCOSE.

## [18.0.1](https://github.com/coachcare/sdk/compare/v18.0.0...v18.0.1) (2022-05-19)


### Bug Fixes

* optional cache-control - MOB-3771 ([340be4c](https://github.com/coachcare/sdk/commit/340be4cf73cf3aa2ec1bb95be55a76d4a32bc1ed))

# [18.0.0](https://github.com/coachcare/sdk/compare/v17.3.6...v18.0.0) (2022-05-18)


### Features

* removed measurement, ActiveCampaign and pain tracking providers & types [FRON-2733] ([5273824](https://github.com/coachcare/sdk/commit/527382458babd714d94e0bd770a36a0b22cc3132))


### BREAKING CHANGES

* 'Body', 'Activity' and 'Sleep' data providers and types
were removed. Data point providers & types should be used instead.
Functionalities that used interdependent types,
like the dieter dashboard summary, were transitioned to use
the data point provider.
ActiveCampaign & pain tracking types and data providers have been removed as well
since they're no longer present in the API

## [17.3.6](https://github.com/coachcare/sdk/compare/v17.3.5...v17.3.6) (2022-05-18)


### Bug Fixes

* add address field to ClientRegisterRequest [FRON-2742] ([1b46d8c](https://github.com/coachcare/sdk/commit/1b46d8c60fcf0addab7b4233b38979cf2a50e228))

## [17.3.5](https://github.com/coachcare/sdk/compare/v17.3.4...v17.3.5) (2022-05-09)


### Bug Fixes

* make caching adapter options header value optional - MOB-3755 ([04e5f30](https://github.com/coachcare/sdk/commit/04e5f305ac3dfa308ac27990d71a676c8de0be5f))

## [17.3.4](https://github.com/coachcare/sdk/compare/v17.3.3...v17.3.4) (2022-05-06)


### Bug Fixes

* adding no cache control to sdk headers - MOB-3746 ([2655f60](https://github.com/coachcare/sdk/commit/2655f60aaab9eac62e35a6579a9f8cab23d85857))

## [17.3.3](https://github.com/coachcare/sdk/compare/v17.3.2...v17.3.3) (2022-05-06)


### Bug Fixes

* adding config value to clear memory cache on mutating request - MOB-3747 ([1c37efb](https://github.com/coachcare/sdk/commit/1c37efb5ba6032d37865afe8c05ee5e75973bce8))

## [17.3.2](https://github.com/coachcare/sdk/compare/v17.3.1...v17.3.2) (2022-05-06)


### Bug Fixes

* creates new instance on raw request [FRON-2737] ([610a8a5](https://github.com/coachcare/sdk/commit/610a8a52bfc2b66c38690717fc6d779f9d9bb117))

## [17.3.1](https://github.com/coachcare/sdk/compare/v17.3.0...v17.3.1) (2022-05-04)


### Bug Fixes

* added storeUrl to the asset prefs [FRON-2737] ([fffd96e](https://github.com/coachcare/sdk/commit/fffd96e4a589db61707227e1ac13f00d8ef431a4))

# [17.3.0](https://github.com/coachcare/sdk/compare/v17.2.0...v17.3.0) (2022-04-26)


### Features

* added support for metadata [FRON-2726] ([d861290](https://github.com/coachcare/sdk/commit/d86129003a0997b1a03f1d3535048f2c013b0656))

# [17.2.0](https://github.com/coachcare/sdk/compare/v17.1.0...v17.2.0) (2022-04-22)


### Bug Fixes

* removed oauth request ([9e6a632](https://github.com/coachcare/sdk/commit/9e6a6324938475c5866b28ca2b0df0b2857adcfa))


### Features

* added documentation to the new ecommerce endpoints [FRON-2689] ([d3efcae](https://github.com/coachcare/sdk/commit/d3efcae4aebced7c7adf4381f55e0574720383dc))

# [17.1.0](https://github.com/coachcare/sdk/compare/v17.0.0...v17.1.0) (2022-04-20)


### Features

* added support for spree endpoints [FRON-2746] ([c27608b](https://github.com/coachcare/sdk/commit/c27608ba4232d292eff504657af8082512749434))

# [17.0.0](https://github.com/coachcare/sdk/compare/v16.12.0...v17.0.0) (2022-04-13)


### Bug Fixes

* added seconds to minute conversion [FRON-2726] ([efc1a1f](https://github.com/coachcare/sdk/commit/efc1a1f5d6847016d245c52bdf6011b6780f3790))


### BREAKING CHANGES

* we now automatically convert seconds to minutes and vice-versa

# [16.12.0](https://github.com/coachcare/sdk/compare/v16.11.1...v16.12.0) (2022-04-13)


### Features

* added support for nxtstim data point types [FRON-2726] ([dce56ed](https://github.com/coachcare/sdk/commit/dce56ed86f18b1d41b3a42fd4ba9bf4002f57d19))

## [16.11.1](https://github.com/coachcare/sdk/compare/v16.11.0...v16.11.1) (2022-04-06)


### Bug Fixes

* added valid properties to rpm billing summary [FRON-2073] ([8671002](https://github.com/coachcare/sdk/commit/8671002d9800e2b3192811f8c5afd0d627736ca8))

# [16.11.0](https://github.com/coachcare/sdk/compare/v16.10.1...v16.11.0) (2022-03-25)


### Features

* added call recording creation endpoint [FRON-2699] ([a7d3b18](https://github.com/coachcare/sdk/commit/a7d3b18b8d7d65739737b5ca553312fdcdbf2830))

## [16.10.1](https://github.com/coachcare/sdk/compare/v16.10.0...v16.10.1) (2022-03-22)


### Bug Fixes

* add additional micronutrients fields [FRON-2694] ([f4057ae](https://github.com/coachcare/sdk/commit/f4057ae02e91941eec1534fac9624c4ec794ceeb))

# [16.10.0](https://github.com/coachcare/sdk/compare/v16.9.1...v16.10.0) (2022-03-21)


### Features

* added ecommerce provider [FRON-2689] ([a1dfa91](https://github.com/coachcare/sdk/commit/a1dfa914e0b69af7f954e57537aa1d5498686d58))

## [16.9.1](https://github.com/coachcare/sdk/compare/v16.9.0...v16.9.1) (2022-03-17)


### Bug Fixes

* adjusted conversion factor for ml to oz [MOB-3655] ([f570a31](https://github.com/coachcare/sdk/commit/f570a31e2561a523c8746d56ebc5c2d819e38c2f))

# [16.9.0](https://github.com/coachcare/sdk/compare/v16.8.1...v16.9.0) (2022-03-07)


### Features

* added blueinfy env support [FRON-2658] ([8cb09eb](https://github.com/coachcare/sdk/commit/8cb09eb4fa6822f6f4f28e08ec40b89a9ac5b9a4))

## [16.8.1](https://github.com/coachcare/sdk/compare/v16.8.0...v16.8.1) (2022-03-04)


### Bug Fixes

* added type to messaging account entry [FRON-2629] ([f50c5a7](https://github.com/coachcare/sdk/commit/f50c5a7f6b128271c5404654e12e0fbaaa9ad7db))

# [16.8.0](https://github.com/coachcare/sdk/compare/v16.7.1...v16.8.0) (2022-03-04)


### Features

* added percentage data for summary [FRON-2646] ([5df53b8](https://github.com/coachcare/sdk/commit/5df53b8f84c375def6ebd48d62b70e6c2054d671))

## [16.7.1](https://github.com/coachcare/sdk/compare/v16.7.0...v16.7.1) (2022-02-23)


### Bug Fixes

* added accountsInclusive prop [FRON-2635] ([edc2d0c](https://github.com/coachcare/sdk/commit/edc2d0cf0b2c8cd1aab550e6e2c361bedc8b7948))

# [16.7.0](https://github.com/coachcare/sdk/compare/v16.6.0...v16.7.0) (2022-02-11)


### Features

* added support for exportTags array [FRON-2616] ([bd25ef0](https://github.com/coachcare/sdk/commit/bd25ef04693284ba746227280a0794cd878ae142))

# [16.6.0](https://github.com/coachcare/sdk/compare/v16.5.1...v16.6.0) (2022-02-09)


### Features

* added package prop to cohort fetch [FRON-2601] ([8bfc4f7](https://github.com/coachcare/sdk/commit/8bfc4f7a27321c18eb0aeceafbdfd157a484d434))

## [16.5.1](https://github.com/coachcare/sdk/compare/v16.5.0...v16.5.1) (2022-01-25)


### Bug Fixes

* add count to MeasurementDataPointAggregate [FRON-2440] ([146dec5](https://github.com/coachcare/sdk/commit/146dec5013550bb632ab91d8d056d1936818b9bf))

# [16.5.0](https://github.com/coachcare/sdk/compare/v16.4.5...v16.5.0) (2022-01-13)


### Features

* added handler for 403 error codes [FRON-2045] ([42465db](https://github.com/coachcare/sdk/commit/42465dbff9d6d45497b4d1f110ff9263175696a7))

## [16.4.5](https://github.com/coachcare/sdk/compare/v16.4.4...v16.4.5) (2022-01-07)


### Bug Fixes

* added sort by name on package fetch [FRON-1567] ([37454fe](https://github.com/coachcare/sdk/commit/37454fe9a78f250e2d21115ed6f3f603731c0505))

## [16.4.4](https://github.com/coachcare/sdk/compare/v16.4.3...v16.4.4) (2022-01-03)


### Bug Fixes

* add sort property to get measurement group request [FRON-2533] ([c0b00e2](https://github.com/coachcare/sdk/commit/c0b00e26756c40ae117d34ccc9131b131d717a6b))

## [16.4.3](https://github.com/coachcare/sdk/compare/v16.4.2...v16.4.3) (2022-01-03)


### Bug Fixes

* added missing sort property to enrollment fetch [FRON-2528] ([76e487d](https://github.com/coachcare/sdk/commit/76e487d05d5a889e937d466b84f5dd62ae359422))

## [16.4.2](https://github.com/coachcare/sdk/compare/v16.4.1...v16.4.2) (2021-12-21)


### Bug Fixes

* convert unit to preference format [FRON-2527] ([47894fa](https://github.com/coachcare/sdk/commit/47894fa44a44fa15d45adc44d75cc4519fc5ea1f))

## [16.4.1](https://github.com/coachcare/sdk/compare/v16.4.0...v16.4.1) (2021-12-21)


### Bug Fixes

* made deprecated for unused measurement endpoints [FRON-2428] ([12c226c](https://github.com/coachcare/sdk/commit/12c226c4cd3e122b89afbd16611b794ae3eeadba))

# [16.4.0](https://github.com/coachcare/sdk/compare/v16.3.2...v16.4.0) (2021-12-21)


### Features

* added call recording fetching [FRON-2299] ([f180d29](https://github.com/coachcare/sdk/commit/f180d29a46aa3b367e6e922e10d1d02178d65511))

## [16.3.2](https://github.com/coachcare/sdk/compare/v16.3.1...v16.3.2) (2021-12-15)


### Bug Fixes

* updating BMI data type id ([7c7cdcb](https://github.com/coachcare/sdk/commit/7c7cdcb29f0b4902b5c205e06f24bf28d9a6a6e5))

## [16.3.1](https://github.com/coachcare/sdk/compare/v16.3.0...v16.3.1) (2021-12-09)


### Bug Fixes

* package enrollment segment now has clnic name [FRON-2470] ([cd95a82](https://github.com/coachcare/sdk/commit/cd95a820109d70366c2409a1b4ed1b4f571092d8))

# [16.3.0](https://github.com/coachcare/sdk/compare/v16.2.0...v16.3.0) (2021-12-02)


### Features

* added videoconference recording flags [FRON-2300] ([8df79b0](https://github.com/coachcare/sdk/commit/8df79b08c1c9d45992b2e4fbf00a4f9b2724d101))

# [16.2.0](https://github.com/coachcare/sdk/compare/v16.1.0...v16.2.0) (2021-11-29)


### Features

* add check package enrollment endpoint [FRON-2483] ([c081da8](https://github.com/coachcare/sdk/commit/c081da88d03fdb6e4443276fdb62a1e731e0f47d))

# [16.1.0](https://github.com/coachcare/sdk/compare/v16.0.2...v16.1.0) (2021-11-23)


### Features

* marking old conference video endpoints as deprecated ([dd40f63](https://github.com/coachcare/sdk/commit/dd40f636e2b12e2f413e841a693db8cd6f6d4930))

## [16.0.2](https://github.com/coachcare/sdk/compare/v16.0.1...v16.0.2) (2021-11-19)


### Bug Fixes

* temperature calculation inaccurate ([04c7b5a](https://github.com/coachcare/sdk/commit/04c7b5a8dfd02699ee25c4832e1d073f82f9e057))

## [16.0.1](https://github.com/coachcare/sdk/compare/v16.0.0...v16.0.1) (2021-11-12)


### Bug Fixes

* revert FRON-2164] ([157f2ff](https://github.com/coachcare/sdk/commit/157f2ff345409dde5a299b0dbedceb713a897ee1))

# [16.0.0](https://github.com/coachcare/sdk/compare/v15.7.1...v16.0.0) (2021-11-12)


### Features

* add schedule address display option to schedule pref [FRON-2427] ([8e8a51c](https://github.com/coachcare/sdk/commit/8e8a51c5a4b6146dddabadf78d64c568b7ef6ebc))


### BREAKING CHANGES

* add schedule address display option to schedule pref

## [15.7.1](https://github.com/coachcare/sdk/compare/v15.7.0...v15.7.1) (2021-11-08)


### Bug Fixes

* adding address scheduling preference to preference response ([457d303](https://github.com/coachcare/sdk/commit/457d303821b7a7bda9965150f44ad1284bb94e9a))

# [15.7.0](https://github.com/coachcare/sdk/compare/v15.6.3...v15.7.0) (2021-11-03)


### Features

* adding perfusion index to DataPointTypes ([ba21b99](https://github.com/coachcare/sdk/commit/ba21b99483484c6d105fc3594bc5280e439fe147))

## [15.6.3](https://github.com/coachcare/sdk/compare/v15.6.2...v15.6.3) (2021-10-30)


### Bug Fixes

* adjusted weight summary box calculation [FRON-2164] ([d25a76a](https://github.com/coachcare/sdk/commit/d25a76a738d3720b18efcca82c6b70e34df118e6))

## [15.6.2](https://github.com/coachcare/sdk/compare/v15.6.1...v15.6.2) (2021-10-22)


### Bug Fixes

* increased version of activity summary to 2.0 [FRON-2385] ([4fdcef5](https://github.com/coachcare/sdk/commit/4fdcef5aeacd4013c451c8a50ca5506f8c6559bc))

## [15.6.1](https://github.com/coachcare/sdk/compare/v15.6.0...v15.6.1) (2021-10-21)


### Bug Fixes

* updated formQuestionData interface [FRON-2377] ([220c04a](https://github.com/coachcare/sdk/commit/220c04a2ddcc56d8a851d5c327b2792a316a96c4))

# [15.6.0](https://github.com/coachcare/sdk/compare/v15.5.2...v15.6.0) (2021-10-19)


### Features

* added unit translation support [IDEA-271] ([4c36720](https://github.com/coachcare/sdk/commit/4c36720a2d70b186e963cfa09ba0effbc9c5d757))

## [15.5.2](https://github.com/coachcare/sdk/compare/v15.5.1...v15.5.2) (2021-10-13)


### Bug Fixes

* case insenstive locale comparison ([55d7c6a](https://github.com/coachcare/sdk/commit/55d7c6aca4b5427dc1697c585b656edb57e7cd17))

## [15.5.1](https://github.com/coachcare/sdk/compare/v15.5.0...v15.5.1) (2021-10-06)


### Bug Fixes

* allowing instance of localstorage get passed instead of defaulting to window.localstorage ([c0f9d0e](https://github.com/coachcare/sdk/commit/c0f9d0eb346e04e298de6ba76b3324502563c2dd))

# [15.5.0](https://github.com/coachcare/sdk/compare/v15.4.1...v15.5.0) (2021-10-04)


### Features

* add function for content copy dry run [FRON-2336] ([48bf7ea](https://github.com/coachcare/sdk/commit/48bf7ead060a1a15a06b3624f1db2ddef7a6a999))

## [15.4.1](https://github.com/coachcare/sdk/compare/v15.4.0...v15.4.1) (2021-09-30)


### Bug Fixes

* adding heart rate variability to sdk enum ([e17f5fb](https://github.com/coachcare/sdk/commit/e17f5fb8ad4223c67329a8be0236213e1d4b7290))

# [15.4.0](https://github.com/coachcare/sdk/compare/v15.3.0...v15.4.0) (2021-09-29)


### Features

* added shopify login url generation endpoint [FRON-2361] ([2179346](https://github.com/coachcare/sdk/commit/21793465513b492d02058978a74f66f960d411bb))

# [15.3.0](https://github.com/coachcare/sdk/compare/v15.2.0...v15.3.0) (2021-09-28)


### Features

* adding toggle camera data message to sdk ([a6582f7](https://github.com/coachcare/sdk/commit/a6582f7d79198f0965bf0c0aecfcd15702a5acdb))

# [15.2.0](https://github.com/coachcare/sdk/compare/v15.1.3...v15.2.0) (2021-09-24)


### Bug Fixes

* added header omission for session check [FRON-2330] ([8b246c4](https://github.com/coachcare/sdk/commit/8b246c4a9ef8ea095e1a7ba7efbb306e5ca3db95))


### Features

* added removeEnrollmentsOnAssociation property [FRON-2360] ([a584cd3](https://github.com/coachcare/sdk/commit/a584cd34590be2bccbfad1e56682467ef7e6294a))
* added support for the profile property [FRON-2353] ([886cef2](https://github.com/coachcare/sdk/commit/886cef23da6fd36a8e0c50f9f38f7bb024652392))

## [15.1.3](https://github.com/coachcare/sdk/compare/v15.1.2...v15.1.3) (2021-09-23)


### Bug Fixes

* omit org headers on certain requests [FRON-2330] ([8449303](https://github.com/coachcare/sdk/commit/84493037042c80f63e23c02bd57af4c8f0acbfd0))

## [15.1.2](https://github.com/coachcare/sdk/compare/v15.1.1...v15.1.2) (2021-09-22)


### Bug Fixes

* added organization to header options ([4ad8fa6](https://github.com/coachcare/sdk/commit/4ad8fa6d65e35c470a5f17cacc77ec7ca12b6d69))
* revert - omitted headers on some requests [FRON-2330] ([985d29c](https://github.com/coachcare/sdk/commit/985d29c631af51a26bee31de92f4ec70d34dfa57))

## [15.1.1](https://github.com/coachcare/sdk/compare/v15.1.0...v15.1.1) (2021-09-22)


### Bug Fixes

* omitted headers on some requests [FRON-2330] ([6ea83fb](https://github.com/coachcare/sdk/commit/6ea83fb113c24854eff7543c90a01a550523791f))

# [15.1.0](https://github.com/coachcare/sdk/compare/v15.0.3...v15.1.0) (2021-09-21)


### Features

* add user address provider [FRON-2349] ([2968c04](https://github.com/coachcare/sdk/commit/2968c0471d1f4e1f78d818d63ab55d3707665d34))

## [15.0.3](https://github.com/coachcare/sdk/compare/v15.0.2...v15.0.3) (2021-09-15)


### Bug Fixes

* package.json & yarn.lock to reduce vulnerabilities ([93a6f6b](https://github.com/coachcare/sdk/commit/93a6f6b6e1c9d09c23cd2afedfb7cf898b06afe9))

## [15.0.2](https://github.com/coachcare/sdk/compare/v15.0.1...v15.0.2) (2021-09-15)


### Bug Fixes

* updating DataPointTypes enum ([072cfa5](https://github.com/coachcare/sdk/commit/072cfa5654042ac53da70ab60674a7524934b00c))

## [15.0.1](https://github.com/coachcare/sdk/compare/v15.0.0...v15.0.1) (2021-09-09)


### Bug Fixes

* adjusted unit conversion for m ([c0a39be](https://github.com/coachcare/sdk/commit/c0a39beeb2384ec13fbf421a7e89b7f5605a7a0c))

# [15.0.0](https://github.com/coachcare/sdk/compare/v14.5.2...v15.0.0) (2021-09-09)


### Bug Fixes

* update interfaces for food [MOB-3295] ([fd12bb9](https://github.com/coachcare/sdk/commit/fd12bb9572f67f856628c0cf75755507671f48e4))


### BREAKING CHANGES

* Update food 2.0 SDK interfaces

fix: fix misspelling

fix: add missed fields for meal summary

refactor: update CreateFoodServingRequest

## [14.5.2](https://github.com/coachcare/sdk/compare/v14.5.1...v14.5.2) (2021-09-09)


### Bug Fixes

* convertToReadableFormat for weight [MOB-3276] ([7f3ea5c](https://github.com/coachcare/sdk/commit/7f3ea5c99c2730fc8ecb04b6806f8df75469ce9a))

## [14.5.1](https://github.com/coachcare/sdk/compare/v14.5.0...v14.5.1) (2021-09-08)


### Bug Fixes

* added startedAt property to rpm item [FRON-2344] ([0cac9ac](https://github.com/coachcare/sdk/commit/0cac9ac5bbc23740172c1e5b3a5f1a0caa92e8c8))

# [14.5.0](https://github.com/coachcare/sdk/compare/v14.4.1...v14.5.0) (2021-09-03)


### Features

* add isVisibleToPatient field to vault content [FRON-2324] ([606c106](https://github.com/coachcare/sdk/commit/606c106600c45cb4684b7efa06f103d47d22eacf))

## [14.4.1](https://github.com/coachcare/sdk/compare/v14.4.0...v14.4.1) (2021-08-26)


### Bug Fixes

* added type string array to patient list fetch [FRON-2293] ([1975dcf](https://github.com/coachcare/sdk/commit/1975dcfaf20e902f7954b64a5cce413adacdc633))

# [14.4.0](https://github.com/coachcare/sdk/compare/v14.3.1...v14.4.0) (2021-08-23)


### Features

* adding remote ingredient fetch and updating fetch single ([f104ab4](https://github.com/coachcare/sdk/commit/f104ab4ee575b701527b4399645f5c4718c74bc8))

## [14.3.1](https://github.com/coachcare/sdk/compare/v14.3.0...v14.3.1) (2021-08-20)


### Bug Fixes

* updating naming convention from SKELETAL_MUSCLE_MASS to MUSCLE_MASS ([c3c6d94](https://github.com/coachcare/sdk/commit/c3c6d947aadc236534dbd690473a486697e558b0))

# [14.3.0](https://github.com/coachcare/sdk/compare/v14.2.1...v14.3.0) (2021-08-20)


### Features

* adding SKELETAL_MUSCLE_MASS_RATIO to data point enum ([6612baf](https://github.com/coachcare/sdk/commit/6612baf1c9cedd1c85e9bc3101a941f65fb9ff30))

## [14.2.1](https://github.com/coachcare/sdk/compare/v14.2.0...v14.2.1) (2021-08-18)


### Bug Fixes

* added circumference unit conversion exceptions [FRON-2276] ([f4acda0](https://github.com/coachcare/sdk/commit/f4acda086ddd0079649a2e06dfe3ec2dbb3aac85))
* adjusted mm conversions for uk ([efb2f06](https://github.com/coachcare/sdk/commit/efb2f06910754d1dcb69485f17f52a8a77ce7f6e))

# [14.2.0](https://github.com/coachcare/sdk/compare/v14.1.6...v14.2.0) (2021-08-17)


### Bug Fixes

* updated updateAssociation interface ([ee22c6e](https://github.com/coachcare/sdk/commit/ee22c6e32c6542fb409a5da13ccc105a32f15d59))


### Features

* added data types map and unit conversion exception [FRON-2269] ([193851b](https://github.com/coachcare/sdk/commit/193851b631d945261c4eb7a4c1e69b3e314fdb93))

## [14.1.6](https://github.com/coachcare/sdk/compare/v14.1.5...v14.1.6) (2021-08-16)


### Bug Fixes

* issue with on-request headers [FRON-2271] ([dd27972](https://github.com/coachcare/sdk/commit/dd27972039938287111eadd449e08d6012d6341f))
* reverted rxjs version upgrade ([4b9752e](https://github.com/coachcare/sdk/commit/4b9752e05b44fa63100c1bae623e391d58f46af0))

## [14.1.5](https://github.com/coachcare/sdk/compare/v14.1.4...v14.1.5) (2021-08-12)


### Bug Fixes

* added missing property to data point type association [FRON-2265] ([ceffcc2](https://github.com/coachcare/sdk/commit/ceffcc21af3b246b2e9b2bbba29b2ebb28a3d474))

## [14.1.4](https://github.com/coachcare/sdk/compare/v14.1.3...v14.1.4) (2021-08-12)


### Bug Fixes

* reverting filter import destination ([2e67ff7](https://github.com/coachcare/sdk/commit/2e67ff7a3ae9c8dc582b0c0e837844f1fe32fb25))

## [14.1.3](https://github.com/coachcare/sdk/compare/v14.1.2...v14.1.3) (2021-08-11)


### Bug Fixes

* overwritting Auth header in throttling adapter ([afacd9e](https://github.com/coachcare/sdk/commit/afacd9e890b7c6f05524561d81f9623d92341418))

## [14.1.2](https://github.com/coachcare/sdk/compare/v14.1.1...v14.1.2) (2021-08-09)


### Bug Fixes

* added span to minimal type ([fad32e3](https://github.com/coachcare/sdk/commit/fad32e354d8edfff3936ba33d738cbaa330cb6f2))

## [14.1.1](https://github.com/coachcare/sdk/compare/v14.1.0...v14.1.1) (2021-08-06)


### Bug Fixes

* update recordedAt as optional [FRON-2258] ([8bae8d0](https://github.com/coachcare/sdk/commit/8bae8d0453a66662002945ad84afb76635c8722c))

# [14.1.0](https://github.com/coachcare/sdk/compare/v14.0.0...v14.1.0) (2021-08-04)


### Features

* add new org scheduling preference endpoints [MOB-3190] ([9dcf1a0](https://github.com/coachcare/sdk/commit/9dcf1a0135c879e66df04ea1567fb2acde5bc156))

# [14.0.0](https://github.com/coachcare/sdk/compare/v13.12.0...v14.0.0) (2021-08-03)


### Features

* remove functionalities for get avatar 2.0 [MOB-3096] ([6a66a0d](https://github.com/coachcare/sdk/commit/6a66a0ddef2e3ec8d2da7787371b9d5d8ae90724))


### BREAKING CHANGES

* Remove deprecated functionalities for get avatar version 2.0

# [13.12.0](https://github.com/coachcare/sdk/compare/v13.11.5...v13.12.0) (2021-08-03)


### Features

* adding include-in-partition into aggregation request ([3decca9](https://github.com/coachcare/sdk/commit/3decca9f60553d804726692584aaee4aae6a58c4))

## [13.11.5](https://github.com/coachcare/sdk/compare/v13.11.4...v13.11.5) (2021-07-15)


### Bug Fixes

* moving header logic into singleton ([239c468](https://github.com/coachcare/sdk/commit/239c468f3b3330286fdc85bdc2ade5ec94affafc))

## [13.11.4](https://github.com/coachcare/sdk/compare/v13.11.3...v13.11.4) (2021-07-15)


### Bug Fixes

* add span field to data point type ([92516de](https://github.com/coachcare/sdk/commit/92516de752d475141fab594cfaa1d3182ecd00b5))

## [13.11.3](https://github.com/coachcare/sdk/compare/v13.11.2...v13.11.3) (2021-07-02)


### Bug Fixes

* adding mood rating to consumed endpoints ([ca04b47](https://github.com/coachcare/sdk/commit/ca04b4721ea582f46300c433d95383926a01f252))

## [13.11.2](https://github.com/coachcare/sdk/compare/v13.11.1...v13.11.2) (2021-07-01)


### Bug Fixes

* use Goals interface in FetchGoalResponse [IDEA-941] ([1b7918c](https://github.com/coachcare/sdk/commit/1b7918c99148b6bd70ecabbddb42c4fe3794eeac))

## [13.11.1](https://github.com/coachcare/sdk/compare/v13.11.0...v13.11.1) (2021-06-29)


### Bug Fixes

* update type of FetchGoalResponse [IDEA-941] ([42a032c](https://github.com/coachcare/sdk/commit/42a032c13c89e054534a8a0647a0e192f45bd7be))

# [13.11.0](https://github.com/coachcare/sdk/compare/v13.10.3...v13.11.0) (2021-06-29)


### Features

* adding upsert endpoint for measurements ([1aece7f](https://github.com/coachcare/sdk/commit/1aece7fd7ec9cf8749baacdef5c4ca172e2209ce))

## [13.10.3](https://github.com/coachcare/sdk/compare/v13.10.2...v13.10.3) (2021-06-17)


### Bug Fixes

* german native name in language list ([01d4ca1](https://github.com/coachcare/sdk/commit/01d4ca1f44c96dd65ed94f6259da0405edf05b83))

## [13.10.2](https://github.com/coachcare/sdk/compare/v13.10.1...v13.10.2) (2021-06-16)


### Bug Fixes

* removed a dot to trigger deployment ([c171146](https://github.com/coachcare/sdk/commit/c171146527cf2b0130602e105d4dcae907c7579e))

## [13.10.1](https://github.com/coachcare/sdk/compare/v13.10.0...v13.10.1) (2021-06-15)


### Bug Fixes

* playing with more thorough typing of synthetic data point creation ([a9ada9f](https://github.com/coachcare/sdk/commit/a9ada9fdfd2c58a43220c9f5dc6239dad4125787))

# [13.10.0](https://github.com/coachcare/sdk/compare/v13.9.0...v13.10.0) (2021-06-11)


### Features

* upgrade version of get avatar to 3.0 [FRON-2199] ([d3ddfc3](https://github.com/coachcare/sdk/commit/d3ddfc392b9b46b224e3b01c5ccf50be22d9bb67))

# [13.9.0](https://github.com/coachcare/sdk/compare/v13.8.3...v13.9.0) (2021-06-11)


### Bug Fixes

* adjusted favorite add request ([9d0ec50](https://github.com/coachcare/sdk/commit/9d0ec50605ef0f84a1cb52b2ac13c5dc3f86b368))
* adjusted types ([478e54f](https://github.com/coachcare/sdk/commit/478e54f146c10a9c59608169ef5cbcd1d795150c))
* removed nested definition ([5fa8cd9](https://github.com/coachcare/sdk/commit/5fa8cd93a76fa2f0a28a1e43880e04c98d6dc4ff))


### Features

* added synthetic type support [FRON-2183] ([ce0ebba](https://github.com/coachcare/sdk/commit/ce0ebba51b226f7f9d428385cfcd41b28666b091))
* adjusted types/added synt type enum ([98bd453](https://github.com/coachcare/sdk/commit/98bd453846662faf948a6986d4f99b0104671215))

## [13.8.3](https://github.com/coachcare/sdk/compare/v13.8.2...v13.8.3) (2021-06-09)


### Bug Fixes

* adjusted DataPointSummaryType interface [FRON-2150] ([746dcde](https://github.com/coachcare/sdk/commit/746dcde4a3533d4823dd423162e78da7c908cb8b))

## [13.8.2](https://github.com/coachcare/sdk/compare/v13.8.1...v13.8.2) (2021-06-08)


### Bug Fixes

* add unit tests for accept language header filtering [MOB-3097] ([45e4074](https://github.com/coachcare/sdk/commit/45e4074f8c3218ed34b9d94155826aac7956ef08))

## [13.8.1](https://github.com/coachcare/sdk/compare/v13.8.0...v13.8.1) (2021-06-04)


### Bug Fixes

* adjusted unit conversion for g [FRON-2183] ([c2d5834](https://github.com/coachcare/sdk/commit/c2d5834a4d1c15de56f254fe30d4647b70044ebb))

# [13.8.0](https://github.com/coachcare/sdk/compare/v13.7.2...v13.8.0) (2021-06-03)


### Features

* added unit conversion logic [FRON-2183] ([2112cdd](https://github.com/coachcare/sdk/commit/2112cdd76154f2bf4457959912cca37389bbc68b))

## [13.7.2](https://github.com/coachcare/sdk/compare/v13.7.1...v13.7.2) (2021-05-28)


### Bug Fixes

* added targetOrganization prop [FRON-2181] ([75db470](https://github.com/coachcare/sdk/commit/75db47056ee7eeaa693936e39eee085f5262451c))

## [13.7.1](https://github.com/coachcare/sdk/compare/v13.7.0...v13.7.1) (2021-05-28)


### Bug Fixes

* adjusted entries to use group.recordedAt [FRON-2177] ([dd026fd](https://github.com/coachcare/sdk/commit/dd026fdaf0159d118102cbbddc0f13ddf23cac28))

# [13.7.0](https://github.com/coachcare/sdk/compare/v13.6.0...v13.7.0) (2021-05-26)


### Features

* making account fields optional ([1f5ed58](https://github.com/coachcare/sdk/commit/1f5ed5879b6e21094b25d019842383d20c274dc2))

# [13.6.0](https://github.com/coachcare/sdk/compare/v13.5.0...v13.6.0) (2021-05-26)


### Features

* adding measurement favorite endpoints to sdk ([7d84406](https://github.com/coachcare/sdk/commit/7d84406bfae6e551fb4eba0a0ebf5ad147863387))

# [13.5.0](https://github.com/coachcare/sdk/compare/v13.4.0...v13.5.0) (2021-05-19)


### Features

* added data point type delete endpoint [IDEA-271] ([622c608](https://github.com/coachcare/sdk/commit/622c6083d5490f3f333da4926ed1ab7f0e0a50d0))

# [13.4.0](https://github.com/coachcare/sdk/compare/v13.3.1...v13.4.0) (2021-05-18)


### Features

* **throttling:** introduced a toggle to enable or disable response rate limit header inspection ([fcd37ca](https://github.com/coachcare/sdk/commit/fcd37ca5120e081f3e1ac5f690d0aaccf71f186f))

## [13.3.1](https://github.com/coachcare/sdk/compare/v13.3.0...v13.3.1) (2021-05-17)

# [13.3.0](https://github.com/coachcare/sdk/compare/v13.2.2...v13.3.0) (2021-05-13)


### Features

* **caching:** added header support in cache key creation ([4519fb9](https://github.com/coachcare/sdk/commit/4519fb9df587be3e79f581708e8d4a174151911f))

## [13.2.2](https://github.com/coachcare/sdk/compare/v13.2.1...v13.2.2) (2021-05-11)


### Bug Fixes

* enabled header omission on billing-summary [FRON-2138] ([c82205a](https://github.com/coachcare/sdk/commit/c82205a63e752c12671928da264321276f9443cf))
* headers are now properly filtered [FRON-2166] ([6adf938](https://github.com/coachcare/sdk/commit/6adf938c42155eb0194281516b6b48b8b21fb823))

## [13.2.1](https://github.com/coachcare/sdk/compare/v13.2.0...v13.2.1) (2021-05-10)


### Bug Fixes

* **caching:** made the type of the options 'partial' ([d62587b](https://github.com/coachcare/sdk/commit/d62587b2ee0d561b1a00b37e4874c2e6e9d2945d))
* **throttling:** made the type of the options 'partial' ([44a0b39](https://github.com/coachcare/sdk/commit/44a0b392e2548920f14e9153e59f858efa75885f))

# [13.2.0](https://github.com/coachcare/sdk/compare/v13.1.0...v13.2.0) (2021-05-07)


### Features

* **caching:** skipped cache response status code check, normalized method casing [API-4777] ([17b3502](https://github.com/coachcare/sdk/commit/17b350242a3d5383c2338ceb5e45a465dec03b38))
* **throttling:** fixed the initial request burst spreading, exposed adapter options [API-4777] ([f25d3b7](https://github.com/coachcare/sdk/commit/f25d3b79e85173045ef7f67fbd2d17a2ba5df8b9))
* exposed throttling diagnostics in the service, exported AuthenticationToken [API-4777] ([ccf2063](https://github.com/coachcare/sdk/commit/ccf2063babfc50ffcd8f2d84779aff3b03ade3b9))

# [13.1.0](https://github.com/coachcare/sdk/compare/v13.0.3...v13.1.0) (2021-05-07)


### Features

* implemented measurement cohort endpoints [IDEA-844] ([ece6d21](https://github.com/coachcare/sdk/commit/ece6d212e38bd4a60867c5852d6611aee1766170))

## [13.0.3](https://github.com/coachcare/sdk/compare/v13.0.2...v13.0.3) (2021-05-05)


### Bug Fixes

* additional sdk integration updates [FRON-2133] ([188d9ab](https://github.com/coachcare/sdk/commit/188d9ab837359e3f8fe472475f84aa38f0f301c1))

## [13.0.2](https://github.com/coachcare/sdk/compare/v13.0.1...v13.0.2) (2021-05-05)


### Bug Fixes

* adjusted meeting type request ([3b8944f](https://github.com/coachcare/sdk/commit/3b8944f779144e414b2f280da885a50c581b8bef))

## [13.0.1](https://github.com/coachcare/sdk/compare/v13.0.0...v13.0.1) (2021-05-04)

# [13.0.0](https://github.com/coachcare/sdk/compare/v12.4.0...v13.0.0) (2021-05-04)


### Features

* migrated changes from dasboard project [FRON-2133] ([228df86](https://github.com/coachcare/sdk/commit/228df8698213f2985a76ffa75a9a64419163a8ee))


### BREAKING CHANGES

* changed some provider names and interface names

# [12.4.0](https://github.com/coachcare/sdk/compare/v12.3.0...v12.4.0) (2021-05-03)


### Bug Fixes

* adjusted data point aggregate interface ([8897781](https://github.com/coachcare/sdk/commit/88977814409aada28a15e242cd82cd123f4246a7))
* adjusted interface name ([11e0bdd](https://github.com/coachcare/sdk/commit/11e0bdd80c28ae14de8ce5087907fbda5e91a3b5))
* adjusted interfaces to make account optional ([3c44a7c](https://github.com/coachcare/sdk/commit/3c44a7c1080bcb603bb7eb7b45714be78696e126))
* linted files ([4c6ee01](https://github.com/coachcare/sdk/commit/4c6ee01d377a0c6e372844d90e4584af7d0396dd))
* linted files ([152395c](https://github.com/coachcare/sdk/commit/152395cae8b8c3fe980532a692607e4bca40adb8))
* linted files ([dee0b69](https://github.com/coachcare/sdk/commit/dee0b69705e957d3ac4439ff00ac1676d9a3a87b))
* typed status as 'active' or 'inactive' ([ae87a4d](https://github.com/coachcare/sdk/commit/ae87a4d038ff2d9f849f3e5de981532af1794cca))


### Features

* created measurement data point endpoint templates ([95fe40d](https://github.com/coachcare/sdk/commit/95fe40ded0eafededb2ca0d98885c4b8885c8d48))
* exposed interfaces ([aebe2ad](https://github.com/coachcare/sdk/commit/aebe2adcfa7c5e6c4ea789c0d84c0689a1143ae1))
* implemented data point group endpoints ([2517723](https://github.com/coachcare/sdk/commit/2517723f3d01590775bf49cf3d775862a8cf5f2b))
* implemented data point interfaces ([049e1fb](https://github.com/coachcare/sdk/commit/049e1fb75da582a8e540500d871b2db57dcd019a))
* implemented data point type association endpoints ([c1f5ed4](https://github.com/coachcare/sdk/commit/c1f5ed4c2c618a8ced79ed8e63fca5ba87fdf212))
* implemented data point type endpoints ([10e8638](https://github.com/coachcare/sdk/commit/10e86389f1e05c4f1d8999617f920dfe787a2b9a))
* implemented locale data point type endpoints ([a9e66b9](https://github.com/coachcare/sdk/commit/a9e66b98979bed72e3b9b57401f6965a483daf1a))
* implemented measurement label endpoints ([6c72aa7](https://github.com/coachcare/sdk/commit/6c72aa769c248cb6da756cbb7be80c4e8f8d133d))
* implemented measurement preference endpoints ([d667fcb](https://github.com/coachcare/sdk/commit/d667fcbfedcdb26a245eb179a4dbf891e458b983))

# [12.3.0](https://github.com/coachcare/sdk/compare/v12.2.0...v12.3.0) (2021-04-15)


### Features

* creating goalv2 provider ([47555c4](https://github.com/coachcare/sdk/commit/47555c4f959c49952d1164e6ab0fce9081cc8fa2))

# [12.2.0](https://github.com/coachcare/sdk/compare/v12.1.0...v12.2.0) (2021-04-15)


### Features

* **auth:** added auth token sharing between API service instances [API-4684] ([f459063](https://github.com/coachcare/sdk/commit/f45906379098df75a6b8095fbbb727aff51de8de))
* **throttling:** added throttling adapter which delays the calls when rate limit is hit [API-4684] ([2d753c6](https://github.com/coachcare/sdk/commit/2d753c6572fb909bb0eb73171f88178706ed2f24))

# [12.1.0](https://github.com/coachcare/sdk/compare/v12.0.1...v12.1.0) (2021-04-14)


### Features

* **cache:** added short-lived request/response cache ([fe17a0e](https://github.com/coachcare/sdk/commit/fe17a0e58e603c4d8fc4628fb7948d6ce5074e4f))

## [12.0.1](https://github.com/coachcare/sdk/compare/v12.0.0...v12.0.1) (2021-04-08)


### Bug Fixes

* setting with credentials for socket client ([f297cc2](https://github.com/coachcare/sdk/commit/f297cc2326ac38f0835240e86916a1917ae1dd2d))

# [12.0.0](https://github.com/coachcare/sdk/compare/v11.20.5...v12.0.0) (2021-03-30)


### Build System

* fixed compilation & linting phase ([054a3ea](https://github.com/coachcare/sdk/commit/054a3eaba908c1fa9cd4645e82dc03e5d838cb4e))


### chore

* **deps:** updated dependencies ([26434df](https://github.com/coachcare/sdk/commit/26434df8220b63486de4197ae7da8ec77d8fc388))
* **deps-dev:** removed tslint, added eslint [MOB-2929] ([54484c2](https://github.com/coachcare/sdk/commit/54484c2c3e140dfef3dabcdd7c9f9a7bfacd72b7))


### Code Refactoring

* flattened the library structure by removing 'selvera-api' layer ([e12bb47](https://github.com/coachcare/sdk/commit/e12bb4708603bc83c99c6e72518efdd3a0885544))


### BREAKING CHANGES

* **deps-dev:** Removed Consultation & Note providers,
since they were calling endpoints that are no longer available
and hasn't been in some time. Typing changes might also
break the external usage.
* It's safe to assume that removing 'selvera-api' and
moving all modules inside to root library level is going to break
at least one call site.
* Some of the type errors that were fixed
are going to cause call-site backwards incompatibility.
* **deps:** A lot of the dependencies were updated in one go,
a lot of them by moving more than 1 major version up. It's expected
that these changes will not be backwards-compatible.

## [11.20.5](https://github.com/coachcare/sdk/compare/v11.20.4...v11.20.5) (2021-03-11)


### Bug Fixes

* fixing js doc spacing ([9562f33](https://github.com/coachcare/sdk/commit/9562f33))
* updating sample endpoint ([d0995b6](https://github.com/coachcare/sdk/commit/d0995b6))

## [11.20.4](https://github.com/coachcare/sdk/compare/v11.20.3...v11.20.4) (2021-02-18)


### Bug Fixes

* adding homepageLayout to enrollment response ([d4445dd](https://github.com/coachcare/sdk/commit/d4445dd))

## [11.20.3](https://github.com/coachcare/sdk/compare/v11.20.2...v11.20.3) (2021-01-12)


### Bug Fixes

* add getSingleViewItem for clients to fetch content items ([9406e5a](https://github.com/coachcare/sdk/commit/9406e5a))
* disable auto import for alphabetical imports ([d01a81d](https://github.com/coachcare/sdk/commit/d01a81d))

## [11.20.2](https://github.com/coachcare/sdk/compare/v11.20.1...v11.20.2) (2021-01-05)


### Bug Fixes

* updating single meal response ([0745a6f](https://github.com/coachcare/sdk/commit/0745a6f))

## [11.20.1](https://github.com/coachcare/sdk/compare/v11.20.0...v11.20.1) (2020-10-22)


### Bug Fixes

* adjusted update preference interface ([ce90be1](https://github.com/coachcare/sdk/commit/ce90be1))

# [11.20.0](https://github.com/coachcare/sdk/compare/v11.19.1...v11.20.0) (2020-10-22)


### Features

* added useAutoThreadParticipation flag ([9623e58](https://github.com/coachcare/sdk/commit/9623e58))

## [11.19.1](https://github.com/coachcare/sdk/compare/v11.19.0...v11.19.1) (2020-10-20)


### Bug Fixes

* mobile camera messages are now stat-based ([524f80e](https://github.com/coachcare/sdk/commit/524f80e))

# [11.19.0](https://github.com/coachcare/sdk/compare/v11.18.0...v11.19.0) (2020-10-20)


### Bug Fixes

* added new billableService flag for interaction posting ([1f73b7f](https://github.com/coachcare/sdk/commit/1f73b7f))
* removed unnecessary f ([5e9b444](https://github.com/coachcare/sdk/commit/5e9b444))
* switched to billableServices ([7fb57b1](https://github.com/coachcare/sdk/commit/7fb57b1))


### Features

* added billable services endpoint ([4f67911](https://github.com/coachcare/sdk/commit/4f67911))

# [11.18.0](https://github.com/coachcare/sdk/compare/v11.17.0...v11.18.0) (2020-10-15)


### Bug Fixes

* timestamp is now always in local time ([08ab848](https://github.com/coachcare/sdk/commit/08ab848))


### Features

* included getAllSelf method ([ee06930](https://github.com/coachcare/sdk/commit/ee06930))

# [11.17.0](https://github.com/coachcare/sdk/compare/v11.16.0...v11.17.0) (2020-10-02)


### Bug Fixes

* adjusted patient id on test ([1058910](https://github.com/coachcare/sdk/commit/1058910))
* adjusted the automated tests ([23b6310](https://github.com/coachcare/sdk/commit/23b6310))


### Features

* added tests for the interaction provider ([11ef7fd](https://github.com/coachcare/sdk/commit/11ef7fd))
* implemented the interaction provider ([615e2c4](https://github.com/coachcare/sdk/commit/615e2c4))

# [11.16.0](https://github.com/coachcare/sdk/compare/v11.15.3...v11.16.0) (2020-08-26)


### Features

* implemented zendesk provider and tests ([96edb38](https://github.com/coachcare/sdk/commit/96edb38))

## [11.15.3](https://github.com/coachcare/sdk/compare/v11.15.2...v11.15.3) (2020-08-25)


### Bug Fixes

* added optional parameter to rpm billing request ([17878e2](https://github.com/coachcare/sdk/commit/17878e2))

## [11.15.2](https://github.com/coachcare/sdk/compare/v11.15.1...v11.15.2) (2020-08-18)


### Bug Fixes

* added hierarchypath to reportorg interface ([f526891](https://github.com/coachcare/sdk/commit/f526891))

## [11.15.1](https://github.com/coachcare/sdk/compare/v11.15.0...v11.15.1) (2020-08-14)


### Bug Fixes

* adding syncHealthKit function ([f99d3d0](https://github.com/coachcare/sdk/commit/f99d3d0))
* adding syncHealthKit function ([8d11460](https://github.com/coachcare/sdk/commit/8d11460))
* adding syncHealthKit function ([71f99e9](https://github.com/coachcare/sdk/commit/71f99e9))
* adding syncHealthKit function ([fdc627d](https://github.com/coachcare/sdk/commit/fdc627d))
* adding syncHealthKit function ([22c4a6a](https://github.com/coachcare/sdk/commit/22c4a6a))

# [11.15.0](https://github.com/coachcare/sdk/compare/v11.14.1...v11.15.0) (2020-08-12)


### Bug Fixes

* properly supported video enabled message ([893c1b2](https://github.com/coachcare/sdk/commit/893c1b2))


### Features

* implemented mob cam off and on messages ([9c668d3](https://github.com/coachcare/sdk/commit/9c668d3))

## [11.14.1](https://github.com/coachcare/sdk/compare/v11.14.0...v11.14.1) (2020-08-11)


### Bug Fixes

* adding ClinicCodeHelp response to preferences ([5dfe505](https://github.com/coachcare/sdk/commit/5dfe505))
* updating ClinicCodeHelp description ([c472634](https://github.com/coachcare/sdk/commit/c472634))

# [11.14.0](https://github.com/coachcare/sdk/compare/v11.13.1...v11.14.0) (2020-08-05)


### Bug Fixes

* adjusted organization property ([f405303](https://github.com/coachcare/sdk/commit/f405303))
* adjusted property name ([910b571](https://github.com/coachcare/sdk/commit/910b571))


### Features

* implemented active campaign endpoints ([7cd3575](https://github.com/coachcare/sdk/commit/7cd3575))

## [11.13.1](https://github.com/coachcare/sdk/compare/v11.13.0...v11.13.1) (2020-07-28)


### Bug Fixes

* added support for new execute at in classic bulk enroll ([de351e2](https://github.com/coachcare/sdk/commit/de351e2))
* adjusted bulk org seq enrollment request structure ([a8dcfeb](https://github.com/coachcare/sdk/commit/a8dcfeb))

# [11.13.0](https://github.com/coachcare/sdk/compare/v11.12.1...v11.13.0) (2020-07-21)


### Features

* added form cloning endpoint ([a71c3d3](https://github.com/coachcare/sdk/commit/a71c3d3))

## [11.12.1](https://github.com/coachcare/sdk/compare/v11.12.0...v11.12.1) (2020-07-14)


### Bug Fixes

* added code requirement support and opt props ([35cb878](https://github.com/coachcare/sdk/commit/35cb878))

# [11.12.0](https://github.com/coachcare/sdk/compare/v11.11.0...v11.12.0) (2020-07-10)


### Bug Fixes

* adjusted raw rpm report data ([cff29f7](https://github.com/coachcare/sdk/commit/cff29f7))


### Features

* added support for response type in api service ([76ccb5d](https://github.com/coachcare/sdk/commit/76ccb5d))
* implemented rpm excel and pdf patient report ([d90af52](https://github.com/coachcare/sdk/commit/d90af52))
* set node version to 12.15 ([1d6a20e](https://github.com/coachcare/sdk/commit/1d6a20e))

# [11.11.0](https://github.com/coachcare/sdk/compare/v11.10.1...v11.11.0) (2020-06-29)


### Features

* added content copy endpoint ([55b8c00](https://github.com/coachcare/sdk/commit/55b8c00))

## [11.10.1](https://github.com/coachcare/sdk/compare/v11.10.0...v11.10.1) (2020-06-17)


### Bug Fixes

* typo ([1ce4a78](https://github.com/coachcare/sdk/commit/1ce4a78))

# [11.10.0](https://github.com/coachcare/sdk/compare/v11.9.1...v11.10.0) (2020-06-16)


### Bug Fixes

* added status and deviceProvidedAt ([f0d79ae](https://github.com/coachcare/sdk/commit/f0d79ae))
* adjusted tests ([05b9e79](https://github.com/coachcare/sdk/commit/05b9e79))
* next is now optional ([8718bbe](https://github.com/coachcare/sdk/commit/8718bbe))


### Features

* upgraded rpm billing report endpoint version ([83db987](https://github.com/coachcare/sdk/commit/83db987))
* upgraded rpm state to v2 and added deact reason ([405ad10](https://github.com/coachcare/sdk/commit/405ad10))

## [11.9.1](https://github.com/coachcare/sdk/compare/v11.9.0...v11.9.1) (2020-06-11)


### Bug Fixes

* adjusted acc event interface ([8b3d7a8](https://github.com/coachcare/sdk/commit/8b3d7a8))

# [11.9.0](https://github.com/coachcare/sdk/compare/v11.8.0...v11.9.0) (2020-06-09)


### Features

* implemented activity event endpoint ([c6f0562](https://github.com/coachcare/sdk/commit/c6f0562))

# [11.8.0](https://github.com/coachcare/sdk/compare/v11.7.2...v11.8.0) (2020-06-09)


### Features

* implemented login history endpoints ([d46856d](https://github.com/coachcare/sdk/commit/d46856d))

## [11.7.2](https://github.com/coachcare/sdk/compare/v11.7.1...v11.7.2) (2020-05-21)


### Bug Fixes

* added 'creator' property ([d729bd8](https://github.com/coachcare/sdk/commit/d729bd8))

## [11.7.1](https://github.com/coachcare/sdk/compare/v11.7.0...v11.7.1) (2020-05-20)


### Bug Fixes

* adjusted form submission draft endpoints ([e6df707](https://github.com/coachcare/sdk/commit/e6df707))

# [11.7.0](https://github.com/coachcare/sdk/compare/v11.6.1...v11.7.0) (2020-05-19)


### Features

* added visceral adipose tissue ([2dbac06](https://github.com/coachcare/sdk/commit/2dbac06))

## [11.6.1](https://github.com/coachcare/sdk/compare/v11.6.0...v11.6.1) (2020-05-19)


### Bug Fixes

* allowing null for token ([6b85f01](https://github.com/coachcare/sdk/commit/6b85f01))
* upgrading circle CI node version ([9b1a141](https://github.com/coachcare/sdk/commit/9b1a141))

# [11.6.0](https://github.com/coachcare/sdk/compare/v11.5.0...v11.6.0) (2020-05-19)


### Features

* added logging to room monitor ([d69b6c1](https://github.com/coachcare/sdk/commit/d69b6c1))

# [11.5.0](https://github.com/coachcare/sdk/compare/v11.4.3...v11.5.0) (2020-05-15)


### Bug Fixes

* added init method to monitor ([2115297](https://github.com/coachcare/sdk/commit/2115297))
* added monitor start and end methods and room ref ([027647d](https://github.com/coachcare/sdk/commit/027647d))
* adjusted breaking point ([b4fe43f](https://github.com/coachcare/sdk/commit/b4fe43f))
* adjusted monitor room handler ([ce1d020](https://github.com/coachcare/sdk/commit/ce1d020))
* adjusted tslint rules ([79bc54c](https://github.com/coachcare/sdk/commit/79bc54c))
* id is now public ([30e7368](https://github.com/coachcare/sdk/commit/30e7368))
* implemented minor code style changes ([137c28d](https://github.com/coachcare/sdk/commit/137c28d))
* shifted approach ([c1d602c](https://github.com/coachcare/sdk/commit/c1d602c))
* small code adjustments ([afbaaa1](https://github.com/coachcare/sdk/commit/afbaaa1))


### Features

* added support for command messages ([5b49e1e](https://github.com/coachcare/sdk/commit/5b49e1e))
* added twilio types ([860611c](https://github.com/coachcare/sdk/commit/860611c))
* implemented twilio room monitor ([c365e4f](https://github.com/coachcare/sdk/commit/c365e4f))

## [11.4.3](https://github.com/coachcare/sdk/compare/v11.4.2...v11.4.3) (2020-05-11)


### Bug Fixes

* adjusted package organization request ([43e9bb8](https://github.com/coachcare/sdk/commit/43e9bb8))

## [11.4.2](https://github.com/coachcare/sdk/compare/v11.4.1...v11.4.2) (2020-05-08)


### Bug Fixes

* added organization property to fss ([5f29495](https://github.com/coachcare/sdk/commit/5f29495))

## [11.4.1](https://github.com/coachcare/sdk/compare/v11.4.0...v11.4.1) (2020-04-30)


### Bug Fixes

* its actually version 1 not version 2 ([a2ee387](https://github.com/coachcare/sdk/commit/a2ee387))

# [11.4.0](https://github.com/coachcare/sdk/compare/v11.3.0...v11.4.0) (2020-04-30)


### Features

* added APN device token endpoint ([607f589](https://github.com/coachcare/sdk/commit/607f589))

# [11.3.0](https://github.com/coachcare/sdk/compare/v11.2.1...v11.3.0) (2020-04-22)


### Features

* implemented form submission draft endpoints ([94a9537](https://github.com/coachcare/sdk/commit/94a9537))
* implemented message draft endpoints ([19d1b4e](https://github.com/coachcare/sdk/commit/19d1b4e))

## [11.2.1](https://github.com/coachcare/sdk/compare/v11.2.0...v11.2.1) (2020-04-22)


### Bug Fixes

* added optional contact info to org with address ([b220de2](https://github.com/coachcare/sdk/commit/b220de2))

# [11.2.0](https://github.com/coachcare/sdk/compare/v11.1.1...v11.2.0) (2020-03-31)


### Features

* added macao and hong kong to country codes ([ff2b8d9](https://github.com/coachcare/sdk/commit/ff2b8d9))

## [11.1.1](https://github.com/coachcare/sdk/compare/v11.1.0...v11.1.1) (2020-03-30)


### Bug Fixes

* adding RPM status to request ([085c599](https://github.com/coachcare/sdk/commit/085c599))

# [11.1.0](https://github.com/coachcare/sdk/compare/v11.0.2...v11.1.0) (2020-03-19)


### Features

* updated form submission endpoints ([a3480b3](https://github.com/coachcare/sdk/commit/a3480b3))

## [11.0.2](https://github.com/coachcare/sdk/compare/v11.0.1...v11.0.2) (2020-03-19)


### Bug Fixes

* added 'after' param encoding ([9748cc3](https://github.com/coachcare/sdk/commit/9748cc3))

## [11.0.1](https://github.com/coachcare/sdk/compare/v11.0.0...v11.0.1) (2020-03-19)


### Bug Fixes

* adjusted querystring parameter for recurring ([72744c5](https://github.com/coachcare/sdk/commit/72744c5))

# [11.0.0](https://github.com/coachcare/sdk/compare/v10.3.0...v11.0.0) (2020-03-18)


### Bug Fixes

* adjusted interface for food meal ([767e33a](https://github.com/coachcare/sdk/commit/767e33a))


### Features

* adjusted delete recurring meeting endpoint ([688b045](https://github.com/coachcare/sdk/commit/688b045))


### BREAKING CHANGES

* changed the structure of the endpoint request

# [10.3.0](https://github.com/coachcare/sdk/compare/v10.2.0...v10.3.0) (2020-03-13)


### Features

* added trigger meta update endpoint ([f425864](https://github.com/coachcare/sdk/commit/f425864))

# [10.2.0](https://github.com/coachcare/sdk/compare/v10.1.0...v10.2.0) (2020-03-11)


### Features

* image segment - wrong entity ([10a2c58](https://github.com/coachcare/sdk/commit/10a2c58))

# [10.1.0](https://github.com/coachcare/sdk/compare/v10.0.0...v10.1.0) (2020-03-11)


### Features

* added alert preference package endpoints ([d3ed1fb](https://github.com/coachcare/sdk/commit/d3ed1fb))

# [10.0.0](https://github.com/coachcare/sdk/compare/v9.5.1...v10.0.0) (2020-03-04)


### Features

* updated food endpoints ([338ce35](https://github.com/coachcare/sdk/commit/338ce35))


### BREAKING CHANGES

* removed unused properties and versioned to 3.0

## [9.5.1](https://github.com/coachcare/sdk/compare/v9.5.0...v9.5.1) (2020-03-04)


### Bug Fixes

* adding ketones to summary property ([efd84c4](https://github.com/coachcare/sdk/commit/efd84c4))

# [9.5.0](https://github.com/coachcare/sdk/compare/v9.4.0...v9.5.0) (2020-02-25)


### Bug Fixes

* added missing route ([fc42dac](https://github.com/coachcare/sdk/commit/fc42dac))


### Features

* implemented content vault preference endpoint ([e1eeaaa](https://github.com/coachcare/sdk/commit/e1eeaaa))

# [9.4.0](https://github.com/coachcare/sdk/compare/v9.3.0...v9.4.0) (2020-02-20)


### Bug Fixes

* added ketones to add body measurement ([a1a56c3](https://github.com/coachcare/sdk/commit/a1a56c3))
* added ketones to summary ([fe8d827](https://github.com/coachcare/sdk/commit/fe8d827))


### Features

* added ketones measurement property ([6ae6f66](https://github.com/coachcare/sdk/commit/6ae6f66))

# [9.3.0](https://github.com/coachcare/sdk/compare/v9.2.1...v9.3.0) (2020-02-12)


### Features

* added submission deletion endpoint ([b637b92](https://github.com/coachcare/sdk/commit/b637b92))
* added support for removable submissions ([772bbb3](https://github.com/coachcare/sdk/commit/772bbb3))

## [9.2.1](https://github.com/coachcare/sdk/compare/v9.2.0...v9.2.1) (2020-02-11)


### Bug Fixes

* updated content response to include childCount ([05819e1](https://github.com/coachcare/sdk/commit/05819e1))

# [9.2.0](https://github.com/coachcare/sdk/compare/v9.1.0...v9.2.0) (2020-02-05)


### Features

* implemented download url method for vault ([9069fbb](https://github.com/coachcare/sdk/commit/9069fbb))

# [9.1.0](https://github.com/coachcare/sdk/compare/v9.0.3...v9.1.0) (2020-01-30)


### Bug Fixes

* adjusted documentation ([27e4d77](https://github.com/coachcare/sdk/commit/27e4d77))


### Features

* implemented file vault provider ([151b171](https://github.com/coachcare/sdk/commit/151b171))

## [9.0.3](https://github.com/coachcare/sdk/compare/v9.0.2...v9.0.3) (2020-01-27)


### Bug Fixes

* adjusted rpm billing summary to support pages ([ddf423b](https://github.com/coachcare/sdk/commit/ddf423b))

## [9.0.2](https://github.com/coachcare/sdk/compare/v9.0.1...v9.0.2) (2020-01-24)


### Bug Fixes

* adjusted account interface ([dd9b3d9](https://github.com/coachcare/sdk/commit/dd9b3d9))

## [9.0.1](https://github.com/coachcare/sdk/compare/v9.0.0...v9.0.1) (2020-01-24)


### Bug Fixes

* adjusted endpoint and type ([a0654aa](https://github.com/coachcare/sdk/commit/a0654aa))
* properly deprecated the attended property ([75035ad](https://github.com/coachcare/sdk/commit/75035ad))
* switched attendance put to attendance patch method ([4d387f2](https://github.com/coachcare/sdk/commit/4d387f2))

# [9.0.0](https://github.com/coachcare/sdk/compare/v8.31.2...v9.0.0) (2020-01-23)


### Bug Fixes

* adjusted an endpoint and an interface ([e78d7c5](https://github.com/coachcare/sdk/commit/e78d7c5))
* adjusted tests and interfaces ([9d184bc](https://github.com/coachcare/sdk/commit/9d184bc))
* adjusted update attendance enpoints ([4515717](https://github.com/coachcare/sdk/commit/4515717))
* removed test lock ([1477791](https://github.com/coachcare/sdk/commit/1477791))


### Features

* implemented attendance status entry endpoints ([727234f](https://github.com/coachcare/sdk/commit/727234f))
* implemented missing status association fetch ([92db911](https://github.com/coachcare/sdk/commit/92db911))
* upgraded meeting fetching endpoints to v3.0 ([68062da](https://github.com/coachcare/sdk/commit/68062da))


### BREAKING CHANGES

* major changes in scheduling provider

## [8.31.2](https://github.com/coachcare/sdk/compare/v8.31.1...v8.31.2) (2020-01-16)


### Bug Fixes

* updated patientlistingitem interface ([e13d242](https://github.com/coachcare/sdk/commit/e13d242))

## [8.31.1](https://github.com/coachcare/sdk/compare/v8.31.0...v8.31.1) (2020-01-06)


### Bug Fixes

* updating fetch all meeting request to accomodate end param ([8fa327e](https://github.com/coachcare/sdk/commit/8fa327e))

# [8.31.0](https://github.com/coachcare/sdk/compare/v8.30.0...v8.31.0) (2019-12-19)


### Features

* added enroll and unenroll handling for bulk org sequence enroll ([e0a18b2](https://github.com/coachcare/sdk/commit/e0a18b2))

# [8.30.0](https://github.com/coachcare/sdk/compare/v8.29.1...v8.30.0) (2019-12-19)


### Bug Fixes

* adjusted counted paginated response interface ([c9d305c](https://github.com/coachcare/sdk/commit/c9d305c))


### Features

* implemented patient listing as report ([b2a03cb](https://github.com/coachcare/sdk/commit/b2a03cb))

## [8.29.1](https://github.com/coachcare/sdk/compare/v8.29.0...v8.29.1) (2019-12-17)


### Bug Fixes

* adjusted call interface ([f5a4805](https://github.com/coachcare/sdk/commit/f5a4805))
* callEnded is now optional ([a5e7218](https://github.com/coachcare/sdk/commit/a5e7218))
* updated fetchcallsresponse ([412e7c4](https://github.com/coachcare/sdk/commit/412e7c4))

# [8.29.0](https://github.com/coachcare/sdk/compare/v8.28.2...v8.29.0) (2019-12-12)


### Features

* implemented email template endpoints ([566ac50](https://github.com/coachcare/sdk/commit/566ac50))

## [8.28.2](https://github.com/coachcare/sdk/compare/v8.28.1...v8.28.2) (2019-12-12)


### Bug Fixes

* inprogress has returned but deprecated ([1b2c751](https://github.com/coachcare/sdk/commit/1b2c751))

## [8.28.1](https://github.com/coachcare/sdk/compare/v8.28.0...v8.28.1) (2019-12-12)


### Bug Fixes

* removed portugal as separate country ([ed9f126](https://github.com/coachcare/sdk/commit/ed9f126))

# [8.28.0](https://github.com/coachcare/sdk/compare/v8.27.0...v8.28.0) (2019-12-12)


### Bug Fixes

* corrected native name for Portuguese ([da2af0c](https://github.com/coachcare/sdk/commit/da2af0c))


### Features

* added BR and PT for portuguese ([8653d11](https://github.com/coachcare/sdk/commit/8653d11))

# [8.27.0](https://github.com/coachcare/sdk/compare/v8.26.0...v8.27.0) (2019-12-11)


### Bug Fixes

* removed trailing ; from interface ([decc10d](https://github.com/coachcare/sdk/commit/decc10d))


### Features

* added and updated country name translations ([61cf8e4](https://github.com/coachcare/sdk/commit/61cf8e4))
* added and updated timezone name translations ([2f0fe2d](https://github.com/coachcare/sdk/commit/2f0fe2d))

# [8.26.0](https://github.com/coachcare/sdk/compare/v8.25.0...v8.26.0) (2019-12-11)


### Bug Fixes

* slightly adjusted france native country name ([7297c87](https://github.com/coachcare/sdk/commit/7297c87))


### Features

* added new locales for DE, FR, IT, and PT ([f8592bf](https://github.com/coachcare/sdk/commit/f8592bf))
* update i18n.config.ts ([0879710](https://github.com/coachcare/sdk/commit/0879710))

# [8.25.0](https://github.com/coachcare/sdk/compare/v8.24.3...v8.25.0) (2019-12-09)


### Bug Fixes

* adjusted status parameter for call fetching ([4f01bed](https://github.com/coachcare/sdk/commit/4f01bed))


### Features

* upgraded call fetching endpoint to v3.0 ([69835e0](https://github.com/coachcare/sdk/commit/69835e0))

## [8.24.3](https://github.com/coachcare/sdk/compare/v8.24.2...v8.24.3) (2019-12-05)


### Bug Fixes

* adjusted calculations for activity level ([9a093c1](https://github.com/coachcare/sdk/commit/9a093c1))

## [8.24.2](https://github.com/coachcare/sdk/compare/v8.24.1...v8.24.2) (2019-12-04)


### Bug Fixes

* adjusted default value for activitylevel ([b87dc2d](https://github.com/coachcare/sdk/commit/b87dc2d))
* implemented activity level api ([a0463a0](https://github.com/coachcare/sdk/commit/a0463a0))
* perfected defaulting of activitylevel ([c2b8f2c](https://github.com/coachcare/sdk/commit/c2b8f2c))

## [8.24.1](https://github.com/coachcare/sdk/compare/v8.24.0...v8.24.1) (2019-12-03)


### Bug Fixes

* adjusted bmr defaulting logic ([9059b7e](https://github.com/coachcare/sdk/commit/9059b7e))

# [8.24.0](https://github.com/coachcare/sdk/compare/v8.23.2...v8.24.0) (2019-11-15)


### Features

* added 'startedAt' optional property to the client data ([b44f72d](https://github.com/coachcare/sdk/commit/b44f72d))

## [8.23.2](https://github.com/coachcare/sdk/compare/v8.23.1...v8.23.2) (2019-11-04)


### Bug Fixes

* fixing timeslot response ([b876293](https://github.com/coachcare/sdk/commit/b876293))

## [8.23.1](https://github.com/coachcare/sdk/compare/v8.23.0...v8.23.1) (2019-10-31)


### Bug Fixes

* adding 3.0 meeting/scheduler ([79146eb](https://github.com/coachcare/sdk/commit/79146eb))

# [8.23.0](https://github.com/coachcare/sdk/compare/v8.22.1...v8.23.0) (2019-10-23)


### Features

* added support for sorOrder in content endpoints ([40f1de0](https://github.com/coachcare/sdk/commit/40f1de0))

## [8.22.1](https://github.com/coachcare/sdk/compare/v8.22.0...v8.22.1) (2019-10-14)


### Bug Fixes

* adjusted organization single response ([09692e0](https://github.com/coachcare/sdk/commit/09692e0))

# [8.22.0](https://github.com/coachcare/sdk/compare/v8.21.1...v8.22.0) (2019-10-03)


### Features

* fetch mala build status ([a457612](https://github.com/coachcare/sdk/commit/a457612))

## [8.21.1](https://github.com/coachcare/sdk/compare/v8.21.0...v8.21.1) (2019-10-01)


### Bug Fixes

* adding sort param and timezone to meetings ([3fedf26](https://github.com/coachcare/sdk/commit/3fedf26))
* adding timezone to FetchMeetingResponse ([7316852](https://github.com/coachcare/sdk/commit/7316852))
* updating property values ([d2826cb](https://github.com/coachcare/sdk/commit/d2826cb))
* wrong assumption about startTime and endTime ([0203b6b](https://github.com/coachcare/sdk/commit/0203b6b))

# [8.21.0](https://github.com/coachcare/sdk/compare/v8.20.1...v8.21.0) (2019-10-01)


### Features

* added nativecountrynames ([3bbd1f9](https://github.com/coachcare/sdk/commit/3bbd1f9))

## [8.20.1](https://github.com/coachcare/sdk/compare/v8.20.0...v8.20.1) (2019-09-30)


### Bug Fixes

* adjusted native country names ([55b0a75](https://github.com/coachcare/sdk/commit/55b0a75))

# [8.20.0](https://github.com/coachcare/sdk/compare/v8.19.0...v8.20.0) (2019-09-19)


### Bug Fixes

* adjusted association property to be optional ([cae2557](https://github.com/coachcare/sdk/commit/cae2557))


### Features

* added immediate association support for acc creation ([1dac08a](https://github.com/coachcare/sdk/commit/1dac08a))

# [8.19.0](https://github.com/coachcare/sdk/compare/v8.18.0...v8.19.0) (2019-09-17)


### Features

* added messaging preference endpoints ([0c25ef0](https://github.com/coachcare/sdk/commit/0c25ef0))
* implemented communication provider ([455f337](https://github.com/coachcare/sdk/commit/455f337))
* implemented content preference provider ([1585654](https://github.com/coachcare/sdk/commit/1585654))

# [8.18.0](https://github.com/coachcare/sdk/compare/v8.17.0...v8.18.0) (2019-09-13)


### Features

* added 2.0 version number to delete measurement endpoint ([c40c8b3](https://github.com/coachcare/sdk/commit/c40c8b3))

# [8.17.0](https://github.com/coachcare/sdk/compare/v8.16.0...v8.17.0) (2019-09-11)


### Features

* added support for activity level bypassing ([77361a4](https://github.com/coachcare/sdk/commit/77361a4))

# [8.16.0](https://github.com/coachcare/sdk/compare/v8.15.1...v8.16.0) (2019-09-05)


### Bug Fixes

* added newsletter property to the clinic registration endpoint ([5803eb6](https://github.com/coachcare/sdk/commit/5803eb6))


### Features

* added newsletter property to org creation endpoint ([b68262e](https://github.com/coachcare/sdk/commit/b68262e))

## [8.15.1](https://github.com/coachcare/sdk/compare/v8.15.0...v8.15.1) (2019-09-04)


### Bug Fixes

* adjusted enrollment response interface ([848cf72](https://github.com/coachcare/sdk/commit/848cf72))

# [8.15.0](https://github.com/coachcare/sdk/compare/v8.14.5...v8.15.0) (2019-09-04)


### Features

* implemented rpm preference endpoints ([ce87606](https://github.com/coachcare/sdk/commit/ce87606))

## [8.14.5](https://github.com/coachcare/sdk/compare/v8.14.4...v8.14.5) (2019-08-30)


### Bug Fixes

* small deprecation to the GetUserMFARequest ([efac8a1](https://github.com/coachcare/sdk/commit/efac8a1))

## [8.14.4](https://github.com/coachcare/sdk/compare/v8.14.3...v8.14.4) (2019-08-26)


### Bug Fixes

* password reset for mfa ([7458290](https://github.com/coachcare/sdk/commit/7458290))

## [8.14.3](https://github.com/coachcare/sdk/compare/v8.14.2...v8.14.3) (2019-08-26)


### Bug Fixes

* passing request to delete user mfa request ([d2d78e7](https://github.com/coachcare/sdk/commit/d2d78e7))

## [8.14.2](https://github.com/coachcare/sdk/compare/v8.14.1...v8.14.2) (2019-08-23)


### Bug Fixes

* updating preference aggregate ([6eb1fd2](https://github.com/coachcare/sdk/commit/6eb1fd2))

## [8.14.1](https://github.com/coachcare/sdk/compare/v8.14.0...v8.14.1) (2019-08-23)


### Bug Fixes

* including delete interface ([0c71238](https://github.com/coachcare/sdk/commit/0c71238))

# [8.14.0](https://github.com/coachcare/sdk/compare/v8.13.0...v8.14.0) (2019-08-23)


### Features

* fron-1208 without the problems ([dcec56b](https://github.com/coachcare/sdk/commit/dcec56b))

# [8.13.0](https://github.com/coachcare/sdk/compare/v8.12.0...v8.13.0) (2019-08-23)


### Bug Fixes

* added newline ([4ec476d](https://github.com/coachcare/sdk/commit/4ec476d))
* shift request required/optional structure ([30b5606](https://github.com/coachcare/sdk/commit/30b5606))


### Features

* added get MFA preference aggregate endpoint ([1cb8e95](https://github.com/coachcare/sdk/commit/1cb8e95))

# [8.12.0](https://github.com/coachcare/sdk/compare/v8.11.2...v8.12.0) (2019-08-22)


### Bug Fixes

* added documentation comments to seqorgassociation endpoints ([c3c23e3](https://github.com/coachcare/sdk/commit/c3c23e3))
* added enrolllment documentation comments ([71c711e](https://github.com/coachcare/sdk/commit/71c711e))
* adjusted inactive enrollment creation endpoint ([52af92e](https://github.com/coachcare/sdk/commit/52af92e))
* minor adjustments to the seq-state endpoints ([eaff7f9](https://github.com/coachcare/sdk/commit/eaff7f9))
* partial documentation commit ([61d5a4e](https://github.com/coachcare/sdk/commit/61d5a4e))


### Features

* added core seq-trigger endpoints ([8895ca4](https://github.com/coachcare/sdk/commit/8895ca4))
* added pending transition endpoints ([8d4691c](https://github.com/coachcare/sdk/commit/8d4691c))
* added seq-enrollment endpoints ([2a6e7fb](https://github.com/coachcare/sdk/commit/2a6e7fb))
* added seq-org asociation endpoints ([2ae61aa](https://github.com/coachcare/sdk/commit/2ae61aa))
* added seq-state endpoints ([c8619c7](https://github.com/coachcare/sdk/commit/c8619c7))
* added seq-transition endpoints ([890582a](https://github.com/coachcare/sdk/commit/890582a))
* added seq-transition history endpoints ([d71ff73](https://github.com/coachcare/sdk/commit/d71ff73))
* added sequence trigger history endpoints ([c9f0f7d](https://github.com/coachcare/sdk/commit/c9f0f7d))
* added sequence trigger locale endpoints ([84d4b2e](https://github.com/coachcare/sdk/commit/84d4b2e))
* implemented core sequence endpoints ([9e8f7ff](https://github.com/coachcare/sdk/commit/9e8f7ff))
* minor api adjustments and added documentation comments ([78fde3a](https://github.com/coachcare/sdk/commit/78fde3a))

## [8.11.2](https://github.com/coachcare/sdk/compare/v8.11.1...v8.11.2) (2019-08-22)


### Bug Fixes

* updating AccUpdatePasswordRequest too ([3b3a53f](https://github.com/coachcare/sdk/commit/3b3a53f))
* updating verification response for backup codes ([b86e869](https://github.com/coachcare/sdk/commit/b86e869))

## [8.11.1](https://github.com/coachcare/sdk/compare/v8.11.0...v8.11.1) (2019-08-22)


### Bug Fixes

* didn't save file ([f61b4c0](https://github.com/coachcare/sdk/commit/f61b4c0))
* optional organiation on login ([12e7442](https://github.com/coachcare/sdk/commit/12e7442))

# [8.11.0](https://github.com/coachcare/sdk/compare/v8.10.0...v8.11.0) (2019-08-15)


### Features

* impl enhanced country code listing provider ([da7571e](https://github.com/coachcare/sdk/commit/da7571e))

# [8.10.0](https://github.com/coachcare/sdk/compare/v8.9.0...v8.10.0) (2019-08-14)


### Features

* added custom error handling on the apiservice ([1cdcfd9](https://github.com/coachcare/sdk/commit/1cdcfd9))

# [8.9.0](https://github.com/coachcare/sdk/compare/v8.8.0...v8.9.0) (2019-08-14)


### Features

* added support for country codes in account endpoints ([d2f3a8c](https://github.com/coachcare/sdk/commit/d2f3a8c))

# [8.8.0](https://github.com/coachcare/sdk/compare/v8.7.0...v8.8.0) (2019-08-13)


### Bug Fixes

* adjusted interfaces and exports ([76e51b7](https://github.com/coachcare/sdk/commit/76e51b7))


### Features

* implemented MFA channel deletion verification ([a6b39fd](https://github.com/coachcare/sdk/commit/a6b39fd))

# [8.7.0](https://github.com/coachcare/sdk/compare/v8.6.0...v8.7.0) (2019-08-07)


### Features

* adding optional param for organization in feedback ([27dbd50](https://github.com/coachcare/sdk/commit/27dbd50))

# [8.6.0](https://github.com/coachcare/sdk/compare/v8.5.1...v8.6.0) (2019-08-02)


### Features

* added mfa instance fetching endpoints ([59f06bf](https://github.com/coachcare/sdk/commit/59f06bf))

## [8.5.1](https://github.com/coachcare/sdk/compare/v8.5.0...v8.5.1) (2019-08-02)


### Bug Fixes

* adjusted organization single response interface ([3d230de](https://github.com/coachcare/sdk/commit/3d230de))

# [8.5.0](https://github.com/coachcare/sdk/compare/v8.4.0...v8.5.0) (2019-07-31)


### Bug Fixes

* added missing documentation commentaries ([7b6263b](https://github.com/coachcare/sdk/commit/7b6263b))
* adjusted login and updatePassword MFA response ([e659ea9](https://github.com/coachcare/sdk/commit/e659ea9))
* adjusted tests for MFA channel instances ([853c926](https://github.com/coachcare/sdk/commit/853c926))


### Features

* added support for mfa password update requests ([d8f569b](https://github.com/coachcare/sdk/commit/d8f569b))
* added tests and adjustments to mfa self-management ([a8009a3](https://github.com/coachcare/sdk/commit/a8009a3))
* implemented mfa self management endpoints ([3de18a2](https://github.com/coachcare/sdk/commit/3de18a2))

# [8.4.0](https://github.com/coachcare/sdk/compare/v8.3.0...v8.4.0) (2019-07-26)


### Features

* added mfa section management and tests ([076179c](https://github.com/coachcare/sdk/commit/076179c))

# [8.3.0](https://github.com/coachcare/sdk/compare/v8.2.0...v8.3.0) (2019-07-25)


### Features

* implemented mfa login method and adjusted regular login ([11a9333](https://github.com/coachcare/sdk/commit/11a9333))

# [8.2.0](https://github.com/coachcare/sdk/compare/v8.1.1...v8.2.0) (2019-07-25)


### Bug Fixes

* added mfa tests and fixed requests ([895a8fb](https://github.com/coachcare/sdk/commit/895a8fb))
* added provider mfa tests ([83b7be3](https://github.com/coachcare/sdk/commit/83b7be3))
* added unauthenticated and client tests ([e0c105b](https://github.com/coachcare/sdk/commit/e0c105b))


### Features

* implemented basic MFA management provider ([a93232e](https://github.com/coachcare/sdk/commit/a93232e))

## [8.1.1](https://github.com/coachcare/sdk/compare/v8.1.0...v8.1.1) (2019-07-23)


### Bug Fixes

* exported restored interface ([29f9076](https://github.com/coachcare/sdk/commit/29f9076))
* restored required account interface ([d9f3868](https://github.com/coachcare/sdk/commit/d9f3868))

# [8.1.0](https://github.com/coachcare/sdk/compare/v8.0.0...v8.1.0) (2019-07-23)


### Features

* added pagination support to GetAllPackageOrganizationRequest ([b7627dc](https://github.com/coachcare/sdk/commit/b7627dc))

# [8.0.0](https://github.com/coachcare/sdk/compare/v7.14.0...v8.0.0) (2019-07-10)


### Bug Fixes

* exposed foodmealorganization again ([ddb36fe](https://github.com/coachcare/sdk/commit/ddb36fe))
* removed clinic provider and tests ([9d8791f](https://github.com/coachcare/sdk/commit/9d8791f))
* removed search method from accountv2 provider ([495393f](https://github.com/coachcare/sdk/commit/495393f))
* reorganized 'account' into 'accountv2' ([3b75522](https://github.com/coachcare/sdk/commit/3b75522))
* reverted food2 endpoint removal ([7711a7a](https://github.com/coachcare/sdk/commit/7711a7a))
* reverted healthkit authentication for the mobile app ([5c6a769](https://github.com/coachcare/sdk/commit/5c6a769))


### Features

* deleted php endpoints and services ([e47540e](https://github.com/coachcare/sdk/commit/e47540e))
* renamed accountv2 to account ([3752646](https://github.com/coachcare/sdk/commit/3752646))


### BREAKING CHANGES

* accountv2 provider is no longer available
* many provider methods have been removed.

# [7.14.0](https://github.com/coachcare/sdk/compare/v7.13.0...v7.14.0) (2019-06-13)


### Bug Fixes

* removed foodmealorganization provider ([b811084](https://github.com/coachcare/sdk/commit/b811084))
* updated packages wording ([f202c59](https://github.com/coachcare/sdk/commit/f202c59))


### Features

* implemented rpm billing summary report ([5667418](https://github.com/coachcare/sdk/commit/5667418))
* updating response and removing request param ([41937e9](https://github.com/coachcare/sdk/commit/41937e9))

# [7.13.0](https://github.com/coachcare/sdk/compare/v7.12.0...v7.13.0) (2019-06-13)


### Features

* updating request ([f596308](https://github.com/coachcare/sdk/commit/f596308))

# [7.12.0](https://github.com/coachcare/sdk/compare/v7.11.0...v7.12.0) (2019-06-11)


### Bug Fixes

* adjusted response to exclude shortcode ([539676e](https://github.com/coachcare/sdk/commit/539676e))
* set status as optional ([78bc563](https://github.com/coachcare/sdk/commit/78bc563))


### Features

* implemented fetch identifier whitelist ([f09778a](https://github.com/coachcare/sdk/commit/f09778a))

# [7.11.0](https://github.com/coachcare/sdk/compare/v7.10.0...v7.11.0) (2019-06-10)


### Features

* implemented a new organization property for thread creation ([a3f45db](https://github.com/coachcare/sdk/commit/a3f45db))

# [7.10.0](https://github.com/coachcare/sdk/compare/v7.9.0...v7.10.0) (2019-06-05)


### Bug Fixes

* removed unnecessary fdescribes ([709246b](https://github.com/coachcare/sdk/commit/709246b))


### Features

* implemented missing property for rpm conditions ([0c99c67](https://github.com/coachcare/sdk/commit/0c99c67))

# [7.9.0](https://github.com/coachcare/sdk/compare/v7.8.0...v7.9.0) (2019-05-29)


### Bug Fixes

* adjusted creation interface and reformatted tests ([894ac17](https://github.com/coachcare/sdk/commit/894ac17))


### Features

* implemented RPM endpoints and tests ([d54a3df](https://github.com/coachcare/sdk/commit/d54a3df))

# [7.8.0](https://github.com/coachcare/sdk/compare/v7.7.1...v7.8.0) (2019-05-03)


### Features

* add platformVersion to header options interface ([3226f0f](https://github.com/coachcare/sdk/commit/3226f0f))

## [7.7.1](https://github.com/coachcare/sdk/compare/v7.7.0...v7.7.1) (2019-05-03)


### Bug Fixes

* refactor api service ([d2bb735](https://github.com/coachcare/sdk/commit/d2bb735))

# [7.7.0](https://github.com/coachcare/sdk/compare/v7.6.1...v7.7.0) (2019-05-02)


### Bug Fixes

* update yarn.lock with .npmrc ([bc8e1fe](https://github.com/coachcare/sdk/commit/bc8e1fe))


### Features

* add version 2.0 to /conference/video/call/availability endpoint ([1aa99c9](https://github.com/coachcare/sdk/commit/1aa99c9))

## [7.6.1](https://github.com/coachcare/sdk/compare/v7.6.0...v7.6.1) (2019-05-01)


### Bug Fixes

* upgrade socket.io with engine.io-client v3.32 ([d61ea1f](https://github.com/coachcare/sdk/commit/d61ea1f))

# [7.6.0](https://github.com/coachcare/sdk/compare/v7.5.0...v7.6.0) (2019-04-30)


### Features

* update inteface for getListContent request ([3c7535e](https://github.com/coachcare/sdk/commit/3c7535e))
* update interface for getAllContent request ([4e4d5f2](https://github.com/coachcare/sdk/commit/4e4d5f2))

# [7.5.0](https://github.com/coachcare/sdk/compare/v7.4.0...v7.5.0) (2019-04-30)


### Features

* update interface for get all content request ([480d556](https://github.com/coachcare/sdk/commit/480d556))

# [7.4.0](https://github.com/coachcare/sdk/compare/v7.3.1...v7.4.0) (2019-04-30)


### Features

* added associatedAt to organization access entity ([5bb9b8e](https://github.com/coachcare/sdk/commit/5bb9b8e))

## [7.3.1](https://github.com/coachcare/sdk/compare/v7.3.0...v7.3.1) (2019-04-24)


### Bug Fixes

* reverted fetchbodymeasurement request method ([6a93e46](https://github.com/coachcare/sdk/commit/6a93e46))

# [7.3.0](https://github.com/coachcare/sdk/compare/v7.2.0...v7.3.0) (2019-04-24)


### Features

* updatedAt and recordedAt date and optional includeRecord ([fa43ee6](https://github.com/coachcare/sdk/commit/fa43ee6))

# [7.2.0](https://github.com/coachcare/sdk/compare/v7.1.1...v7.2.0) (2019-04-24)


### Features

* fixing array request for includesProperty ([c379fb0](https://github.com/coachcare/sdk/commit/c379fb0))

## [7.1.1](https://github.com/coachcare/sdk/compare/v7.1.0...v7.1.1) (2019-04-24)


### Bug Fixes

* adjusted sort property to be an array ([fbb4995](https://github.com/coachcare/sdk/commit/fbb4995))
* adjusted type naming on certain interfaces ([5de15fe](https://github.com/coachcare/sdk/commit/5de15fe))
* didn't incldue test direcotry ([59e2302](https://github.com/coachcare/sdk/commit/59e2302))
* missing limit on request ([a170ea9](https://github.com/coachcare/sdk/commit/a170ea9))
* missing limit on request ([2a2c056](https://github.com/coachcare/sdk/commit/2a2c056))
* missing limit on request ([54164cf](https://github.com/coachcare/sdk/commit/54164cf))

# [7.1.0](https://github.com/coachcare/sdk/compare/v7.0.2...v7.1.0) (2019-04-23)


### Bug Fixes

* added max to fetch measurements request ([873efee](https://github.com/coachcare/sdk/commit/873efee))


### Features

* update api service header options ([046cdb6](https://github.com/coachcare/sdk/commit/046cdb6))

## [7.0.2](https://github.com/coachcare/sdk/compare/v7.0.1...v7.0.2) (2019-04-23)


### Bug Fixes

* add aggregation field to fetch measurements request ([1668d91](https://github.com/coachcare/sdk/commit/1668d91))

## [7.0.1](https://github.com/coachcare/sdk/compare/v7.0.0...v7.0.1) (2019-04-23)


### Bug Fixes

* add aggregation field to fetch measurements request ([8253c2c](https://github.com/coachcare/sdk/commit/8253c2c))

# [7.0.0](https://github.com/coachcare/sdk/compare/v6.4.2...v7.0.0) (2019-04-22)


### Features

* upgraded measurement body endpoint version ([ab4607b](https://github.com/coachcare/sdk/commit/ab4607b))


### BREAKING CHANGES

* removed summarydata provider

## [6.4.2](https://github.com/coachcare/sdk/compare/v6.4.1...v6.4.2) (2019-04-18)


### Bug Fixes

* get account preference and get single account preference ([31047b7](https://github.com/coachcare/sdk/commit/31047b7))

## [6.4.1](https://github.com/coachcare/sdk/compare/v6.4.0...v6.4.1) (2019-04-17)


### Bug Fixes

* add MessagingPreference in selvera-api ([ec13820](https://github.com/coachcare/sdk/commit/ec13820))

# [6.4.0](https://github.com/coachcare/sdk/compare/v6.3.1...v6.4.0) (2019-04-17)


### Features

* delete messaging preference ([b2424a4](https://github.com/coachcare/sdk/commit/b2424a4))
* message create preference ([1cf55de](https://github.com/coachcare/sdk/commit/1cf55de))
* messaging get preference provider ([ca0c6ac](https://github.com/coachcare/sdk/commit/ca0c6ac))
* update messaging preference ([a891367](https://github.com/coachcare/sdk/commit/a891367))

## [6.3.1](https://github.com/coachcare/sdk/compare/v6.3.0...v6.3.1) (2019-04-12)


### Bug Fixes

* remove extra spacing ([8064d4d](https://github.com/coachcare/sdk/commit/8064d4d))

# [6.3.0](https://github.com/coachcare/sdk/compare/v6.2.0...v6.3.0) (2019-04-01)


### Features

* add tanita visceral fat for all requests and responses ([d4c2d8e](https://github.com/coachcare/sdk/commit/d4c2d8e))

# [6.2.0](https://github.com/coachcare/sdk/compare/v6.1.1...v6.2.0) (2019-03-27)


### Features

* increase version for upload avatar ([de07c4a](https://github.com/coachcare/sdk/commit/de07c4a))

## [6.1.1](https://github.com/coachcare/sdk/compare/v6.1.0...v6.1.1) (2019-03-22)


### Bug Fixes

* added native spelling for locales in native property ([d11b716](https://github.com/coachcare/sdk/commit/d11b716))

# [6.1.0](https://github.com/coachcare/sdk/compare/v6.0.0...v6.1.0) (2019-03-22)


### Features

* update the simple enrollment report response ([d783c67](https://github.com/coachcare/sdk/commit/d783c67))

# [6.0.0](https://github.com/coachcare/sdk/compare/v5.2.0...v6.0.0) (2019-03-22)


### Bug Fixes

* remove deprecated 1.1 update profile method ([ae0aa84](https://github.com/coachcare/sdk/commit/ae0aa84))
* remove unit tests for the deprecated update profile method ([adc0a8e](https://github.com/coachcare/sdk/commit/adc0a8e))


### Performance Improvements

* removed deprecated v1.1 update user method ([f9c8af8](https://github.com/coachcare/sdk/commit/f9c8af8))


### BREAKING CHANGES

* removed the deprecated method from the API

# [5.2.0](https://github.com/coachcare/sdk/compare/v5.1.6...v5.2.0) (2019-03-21)


### Features

* added new zealand, english to config locales ([ba27b26](https://github.com/coachcare/sdk/commit/ba27b26))

## [5.1.6](https://github.com/coachcare/sdk/compare/v5.1.5...v5.1.6) (2019-03-20)


### Bug Fixes

* add name field to ReportPackage ([844cc64](https://github.com/coachcare/sdk/commit/844cc64))

## [5.1.5](https://github.com/coachcare/sdk/compare/v5.1.4...v5.1.5) (2019-03-18)


### Bug Fixes

* response of fetching the simple enrollment report ([5f720ce](https://github.com/coachcare/sdk/commit/5f720ce))

## [5.1.4](https://github.com/coachcare/sdk/compare/v5.1.3...v5.1.4) (2019-03-15)


### Bug Fixes

* **ci:** fixing the artifact bundle ([b3379a5](https://github.com/coachcare/sdk/commit/b3379a5)), closes [/github.com/Microsoft/types-publisher/issues/81#issuecomment-234051338](https://github.com//github.com/Microsoft/types-publisher/issues/81/issues/issuecomment-234051338)

## [5.1.3](https://github.com/coachcare/sdk/compare/v5.1.2...v5.1.3) (2019-03-15)


### Bug Fixes

* added missing types dependency ([517e4a0](https://github.com/coachcare/sdk/commit/517e4a0))
* bumped up typescript version ([ed3a7b8](https://github.com/coachcare/sdk/commit/ed3a7b8))
* removed colliding deps ([10245fc](https://github.com/coachcare/sdk/commit/10245fc))
* removed unnecessary [@types](https://github.com/types) dependency ([03cd97a](https://github.com/coachcare/sdk/commit/03cd97a))
* solved dependencies/devdependencies ([49b69a4](https://github.com/coachcare/sdk/commit/49b69a4))

## [5.1.2](https://github.com/coachcare/sdk/compare/v5.1.1...v5.1.2) (2019-03-14)


### Bug Fixes

* removed unnecessary dependencies ([ab7eaac](https://github.com/coachcare/sdk/commit/ab7eaac))
* switched hooks to yarn and node_modules ([c4bbbf3](https://github.com/coachcare/sdk/commit/c4bbbf3))

## [5.1.1](https://github.com/coachcare/sdk/compare/v5.1.0...v5.1.1) (2019-03-14)


### Bug Fixes

* added the missing postinstall hook ([af07748](https://github.com/coachcare/sdk/commit/af07748))

# [5.1.0](https://github.com/coachcare/sdk/compare/v5.0.0...v5.1.0) (2019-03-14)


### Features

* add new simple enrollment report to sdk [FRON-954] ([#304](https://github.com/coachcare/sdk/issues/304)) ([a5d2f73](https://github.com/coachcare/sdk/commit/a5d2f73))
* Add new simple enrollment report to sdk [FRON-954] ([#304](https://github.com/coachcare/sdk/issues/304)) ([9cb9c0b](https://github.com/coachcare/sdk/commit/9cb9c0b))

# [5.0.0](https://github.com/coachcare/sdk/compare/v4.6.1...v5.0.0) (2019-03-14)


### Features

* update for new 4.0 org pref endpoints ([#303](https://github.com/coachcare/sdk/issues/303)) ([3ad64a8](https://github.com/coachcare/sdk/commit/3ad64a8))


### BREAKING CHANGES

* removed duplicated organizationPreference

# [4.6.0](https://github.com/coachcare/sdk/compare/v4.5.3...v4.6.0) (2019-03-14)


### Bug Fixes

* catch socket error so it won't propagate to app ([#293](https://github.com/coachcare/sdk/issues/293)) ([f7929fd](https://github.com/coachcare/sdk/commit/f7929fd))


### Features

* add function for update password using v2.0 endpoint ([#301](https://github.com/coachcare/sdk/issues/301)) ([0d2babe](https://github.com/coachcare/sdk/commit/0d2babe))
* added support for new UpdateFormQuestionRequest properties ([#290](https://github.com/coachcare/sdk/issues/290)) ([676d369](https://github.com/coachcare/sdk/commit/676d369))

# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="4.5.1"></a>
## [4.5.1](https://github.com/coachcare/sdk/compare/v4.5.0...v4.5.1) (2019-01-08)


### Bug Fixes

* **food:** added FoodMealServing provider ([aac5a06](https://github.com/coachcare/sdk/commit/aac5a06))



<a name="4.5.0"></a>
# [4.5.0](https://github.com/coachcare/sdk/compare/v2.4.11...v4.5.0) (2019-01-08)


### Features

* **food:** synced FoodV2 with the latest gateway ([fe0a5d3](https://github.com/coachcare/sdk/commit/fe0a5d3))



<a name="2.4.11"></a>
## [2.4.11](https://github.com/coachcare/sdk/compare/v2.4.10...v2.4.11) (2019-01-07)


### Bug Fixes

* ApiService.request now returns the backend message transparently ([7c21c8f](https://github.com/coachcare/sdk/commit/7c21c8f))



<a name="2.4.8"></a>
## [2.4.8](https://github.com/coachcare/sdk/compare/v2.4.7...v2.4.8) (2018-12-13)


### Features

* **MOB-771:** fetch all measurement devices ([#283](https://github.com/coachcare/sdk/issues/283)) ([0e1f445](https://github.com/coachcare/sdk/commit/0e1f445))
* updated OrgDescendantsRequest ([#282](https://github.com/coachcare/sdk/issues/282)) ([c6ebd9b](https://github.com/coachcare/sdk/commit/c6ebd9b)), closes [/github.com/selvera/web-gateway/blob/9322147ed950519f0963f108a9f0c11a5a48da2d/app/organization/route.ts#L340](https://github.com//github.com/selvera/web-gateway/blob/9322147ed950519f0963f108a9f0c11a5a48da2d/app/organization/route.ts/issues/L340)



<a name="2.4.7"></a>
## [2.4.7](https://github.com/coachcare/sdk/compare/v2.4.6...v2.4.7) (2018-12-13)


### Bug Fixes

* update FoodMeal.update response ([#281](https://github.com/coachcare/sdk/issues/281)) ([b8515d0](https://github.com/coachcare/sdk/commit/b8515d0))
* update GetAllMessagingRequest ([#280](https://github.com/coachcare/sdk/issues/280)) ([8508b64](https://github.com/coachcare/sdk/commit/8508b64))



<a name="2.4.6"></a>
## [2.4.6](https://github.com/coachcare/sdk/compare/v2.4.5...v2.4.6) (2018-12-06)


### Bug Fixes

* **food:** updated FoodIngredient.createLocal response ([5104f20](https://github.com/coachcare/sdk/commit/5104f20))



<a name="2.4.5"></a>
## [2.4.5](https://github.com/coachcare/sdk/compare/v2.4.4...v2.4.5) (2018-12-06)


### Bug Fixes

* **MOB-862:** removing id from create local ([#279](https://github.com/coachcare/sdk/issues/279)) ([3427334](https://github.com/coachcare/sdk/commit/3427334))



<a name="2.4.4"></a>
## [2.4.4](https://github.com/coachcare/sdk/compare/v2.4.3...v2.4.4) (2018-12-03)


### Bug Fixes

* phase out v1 messaging endpoints ([19dcc8a](https://github.com/coachcare/sdk/commit/19dcc8a))



<a name="2.4.3"></a>
## [2.4.3](https://github.com/coachcare/sdk/compare/v2.4.2...v2.4.3) (2018-12-01)



<a name="2.4.2"></a>
## [2.4.2](https://github.com/coachcare/sdk/compare/v2.4.1...v2.4.2) (2018-11-30)



<a name="2.4.1"></a>
## [2.4.1](https://github.com/coachcare/sdk/compare/v2.4.0...v2.4.1) (2018-11-27)


### Bug Fixes

* extended 'mimeType' property to allow multiple values ([#278](https://github.com/coachcare/sdk/issues/278)) ([9dee765](https://github.com/coachcare/sdk/commit/9dee765))



<a name="2.4.1"></a>
## [2.4.1](https://github.com/coachcare/sdk/compare/v2.4.0...v2.4.1) (2018-11-27)


### Bug Fixes

* extended 'mimeType' property to allow multiple values ([#278](https://github.com/coachcare/sdk/issues/278)) ([9dee765](https://github.com/coachcare/sdk/commit/9dee765))



<a name="2.4.0"></a>
# [2.4.0](https://github.com/coachcare/sdk/compare/v2.3.8...v2.4.0) (2018-11-26)


### Features

* **food:** FoodV2 and additional Food* providers ([6163f4b](https://github.com/coachcare/sdk/commit/6163f4b))



<a name="2.3.8"></a>
## [2.3.8](https://github.com/coachcare/sdk/compare/v2.3.7...v2.3.8) (2018-11-08)


### Bug Fixes

* **FRON-633:** adjusted sent answer structure to match what the server expects in FormSubmission provider ([#276](https://github.com/coachcare/sdk/issues/276)) ([a847332](https://github.com/coachcare/sdk/commit/a847332))
* **FRON-633:** FormAnswer interface adjustment ([#277](https://github.com/coachcare/sdk/issues/277)) ([84eb342](https://github.com/coachcare/sdk/commit/84eb342))


### Reverts

* commit a847332d761678f2784504e071d6d8f7a3d918df. ([bf1f5b9](https://github.com/coachcare/sdk/commit/bf1f5b9))



<a name="2.3.7"></a>
## [2.3.7](https://github.com/coachcare/sdk/compare/v2.3.6...v2.3.7) (2018-11-05)


### Bug Fixes

* **summary:** fixed calculation of BMR ([daf64d2](https://github.com/coachcare/sdk/commit/daf64d2))



<a name="2.3.6"></a>
## [2.3.6](https://github.com/coachcare/sdk/compare/v2.3.5...v2.3.6) (2018-11-05)


### Bug Fixes

* **summary:** do not convert units for dieter summary dashboard ([941fc93](https://github.com/coachcare/sdk/commit/941fc93))



<a name="2.3.5"></a>
## [2.3.5](https://github.com/coachcare/sdk/compare/v2.3.4...v2.3.5) (2018-11-05)


### Features

* **organization:** association and assignment providers ([c2b6251](https://github.com/coachcare/sdk/commit/c2b6251))



<a name="2.3.4"></a>
## [2.3.4](https://github.com/coachcare/sdk/compare/v2.3.3...v2.3.4) (2018-11-05)


### Features

* adjusted Question type to the actual returned value from the server ([6e5de8a](https://github.com/coachcare/sdk/commit/6e5de8a))



<a name="2.3.2"></a>
## [2.3.2](https://github.com/coachcare/sdk/compare/v2.3.1...v2.3.2) (2018-10-29)


### Bug Fixes

* **organization:** /access/organization fix ([940cbdb](https://github.com/coachcare/sdk/commit/940cbdb))



<a name="2.3.1"></a>
## [2.3.1](https://github.com/coachcare/sdk/compare/v2.3.0...v2.3.1) (2018-10-27)


### Features

* **package:** Package, PackageEnrollment and PackageOrganization providers ([f3ee737](https://github.com/coachcare/sdk/commit/f3ee737))


### Reverts

* **content:** reverted ContentPackage.request organization param ([e887212](https://github.com/coachcare/sdk/commit/e887212))



<a name="2.3.0"></a>
# [2.3.0](https://github.com/coachcare/sdk/compare/v2.2.12...v2.3.0) (2018-10-27)


### Bug Fixes

* **associations:** fixed organization association permissions ([2b8a32b](https://github.com/coachcare/sdk/commit/2b8a32b))
* **content:** adjusted ContentPackage.create ([9df1bbd](https://github.com/coachcare/sdk/commit/9df1bbd))
* **content:** missing organization in CreateContentPackageRequest ([9734de3](https://github.com/coachcare/sdk/commit/9734de3))



<a name="2.2.12"></a>
## [2.2.12](https://github.com/coachcare/sdk/compare/v2.2.11...v2.2.12) (2018-10-25)



<a name="2.2.11"></a>
## [2.2.11](https://github.com/coachcare/sdk/compare/v2.2.10...v2.2.11) (2018-10-24)


### Bug Fixes

* **alerts:** toggle group organization param added ([64094f9](https://github.com/coachcare/sdk/commit/64094f9))



<a name="2.2.10"></a>
## [2.2.10](https://github.com/coachcare/sdk/compare/v2.2.9...v2.2.10) (2018-10-23)


### Bug Fixes

* **phase:** added enrollment title to Phase.fetch ([de276d1](https://github.com/coachcare/sdk/commit/de276d1))



<a name="2.2.9"></a>
## [2.2.9](https://github.com/coachcare/sdk/compare/v2.2.8...v2.2.9) (2018-10-22)



<a name="2.2.8"></a>
## [2.2.8](https://github.com/coachcare/sdk/compare/v2.2.7...v2.2.8) (2018-10-17)


### Bug Fixes

* **FRON-533:** measurements boxes updated with the latest summary ([89092b2](https://github.com/coachcare/sdk/commit/89092b2))



<a name="2.2.7"></a>
## [2.2.7](https://github.com/coachcare/sdk/compare/v2.2.6...v2.2.7) (2018-10-16)


### Bug Fixes

* removed deprecated ContentForm provider ([3127263](https://github.com/coachcare/sdk/commit/3127263))
* variable casing in Organization Preference ([#272](https://github.com/coachcare/sdk/issues/272)) ([2087f7f](https://github.com/coachcare/sdk/commit/2087f7f))


### Features

* **measurement:** new body summary added ([712ad5b](https://github.com/coachcare/sdk/commit/712ad5b))



<a name="2.2.6"></a>
## [2.2.6](https://github.com/coachcare/sdk/compare/v2.2.5...v2.2.6) (2018-10-12)



<a name="2.2.5"></a>
## [2.2.5](https://github.com/coachcare/sdk/compare/v2.2.4...v2.2.5) (2018-10-11)


### Features

* **FRON-544:** added OrganizationPreferences provider ([#271](https://github.com/coachcare/sdk/issues/271)) ([6c89d23](https://github.com/coachcare/sdk/commit/6c89d23))



<a name="2.2.4"></a>
## [2.2.4](https://github.com/coachcare/sdk/compare/v2.2.3...v2.2.4) (2018-10-10)


### Bug Fixes

* **FRON-505:** added optional 'mimeType' parameter on GetAllContentRequest and GetListContentRequest ([#270](https://github.com/coachcare/sdk/issues/270)) ([67d0023](https://github.com/coachcare/sdk/commit/67d0023))



<a name="2.2.3"></a>
## [2.2.3](https://github.com/coachcare/sdk/compare/v2.2.2...v2.2.3) (2018-10-08)


### Bug Fixes

* **chart:** pass the device request parameter ([#267](https://github.com/coachcare/sdk/issues/267)) ([1a81e58](https://github.com/coachcare/sdk/commit/1a81e58))
* mobile client registration projectId added ([#269](https://github.com/coachcare/sdk/issues/269)) ([f6b73f7](https://github.com/coachcare/sdk/commit/f6b73f7))
* optional account for Clients on GetSummaryMeasurementActivityRequest ([#266](https://github.com/coachcare/sdk/issues/266)) ([8aa9bbc](https://github.com/coachcare/sdk/commit/8aa9bbc))


### Features

* added support for sorting on GetAllContentRequest ([#268](https://github.com/coachcare/sdk/issues/268)) ([e345ce1](https://github.com/coachcare/sdk/commit/e345ce1))



<a name="2.2.2"></a>
## [2.2.2](https://github.com/coachcare/sdk/compare/v2.2.1...v2.2.2) (2018-10-03)


### Bug Fixes

* **FRON-523:** updated all body measurements ([#265](https://github.com/coachcare/sdk/issues/265)) ([dd88731](https://github.com/coachcare/sdk/commit/dd88731))



<a name="2.2.1"></a>
## [2.2.1](https://github.com/coachcare/sdk/compare/v2.2.0...v2.2.1) (2018-10-03)


### Features

* **messaging:** added support for Messaging 2..0 ([ca20885](https://github.com/coachcare/sdk/commit/ca20885))



<a name="2.2.0"></a>
# [2.2.0](https://github.com/coachcare/sdk/compare/v2.1.9...v2.2.0) (2018-09-28)



<a name="2.1.9"></a>
## [2.1.9](https://github.com/coachcare/sdk/compare/v2.1.8...v2.1.9) (2018-09-28)


### Bug Fixes

* **form:** better typing for the responses ([810a68b](https://github.com/coachcare/sdk/commit/810a68b))



<a name="2.1.8"></a>
## [2.1.8](https://github.com/coachcare/sdk/compare/v2.1.7...v2.1.8) (2018-09-27)


### Bug Fixes

* **register:** account title type corrected ([38a4e29](https://github.com/coachcare/sdk/commit/38a4e29))



<a name="2.1.7"></a>
## [2.1.7](https://github.com/coachcare/sdk/compare/v2.1.6...v2.1.7) (2018-09-27)



<a name="2.1.6"></a>
## [2.1.6](https://github.com/coachcare/sdk/compare/v2.1.5...v2.1.6) (2018-09-24)


### Features

* **mala:** added mala preference support ([6a7838f](https://github.com/coachcare/sdk/commit/6a7838f))



<a name="2.1.5"></a>
## [2.1.5](https://github.com/coachcare/sdk/compare/v2.1.4...v2.1.5) (2018-09-22)


### Features

* **Idealshape:** added leaderboard endpoint ([e634c7c](https://github.com/coachcare/sdk/commit/e634c7c))



<a name="2.1.4"></a>
## [2.1.4](https://github.com/coachcare/sdk/compare/v2.1.3...v2.1.4) (2018-09-22)


### Bug Fixes

* **PainTracking:** update method and tests fixed ([07e06c3](https://github.com/coachcare/sdk/commit/07e06c3))



<a name="2.1.3"></a>
## [2.1.3](https://github.com/coachcare/sdk/compare/v2.1.2...v2.1.3) (2018-09-22)



<a name="2.1.1"></a>
## [2.1.1](https://github.com/coachcare/sdk/compare/v2.1.0...v2.1.1) (2018-09-21)


### Bug Fixes

* adding device for FetchActivityHistoryRequest ([#264](https://github.com/coachcare/sdk/issues/264)) ([41a9a2d](https://github.com/coachcare/sdk/commit/41a9a2d))


### Features

* **Register:** client registration update ([c203d36](https://github.com/coachcare/sdk/commit/c203d36))



<a name="2.1.0"></a>
# [2.1.0](https://github.com/coachcare/sdk/compare/v2.0.2...v2.1.0) (2018-09-21)


### Features

* **forms:** Content Form endpoints supported ([c44ff61](https://github.com/coachcare/sdk/commit/c44ff61))



<a name="2.0.2"></a>
## [2.0.2](https://github.com/coachcare/sdk/compare/v2.0.1...v2.0.2) (2018-09-12)


### Bug Fixes

* **websocket:** url fixed and log messages on test ([e734711](https://github.com/coachcare/sdk/commit/e734711))



<a name="2.0.1"></a>
## [2.0.1](https://github.com/coachcare/sdk/compare/v2.0.0...v2.0.1) (2018-09-11)


### Bug Fixes

* **conference:** removed duplicated interface and exported Call ([bbf6f81](https://github.com/coachcare/sdk/commit/bbf6f81))



<a name="2.0.0"></a>
# [2.0.0](https://github.com/coachcare/sdk/compare/v1.34.5...v2.0.0) (2018-09-11)


### Bug Fixes

* **conference:** /conference endpoints reviewed ([b4397ec](https://github.com/coachcare/sdk/commit/b4397ec))
* commented out socket console logs ([9959f0c](https://github.com/coachcare/sdk/commit/9959f0c))
* **conference:** fixed FetchCallDetailsResponse ([c7b9770](https://github.com/coachcare/sdk/commit/c7b9770))
* **conference:** fixed FetchCallsResponse ([17019d7](https://github.com/coachcare/sdk/commit/17019d7))
* **config:** determine socketUrl from apiUrl ([9110e23](https://github.com/coachcare/sdk/commit/9110e23))


### Features

* video-conference endpoints ([#259](https://github.com/coachcare/sdk/issues/259)) ([fd4e0a5](https://github.com/coachcare/sdk/commit/fd4e0a5))



<a name="1.34.5"></a>
## [1.34.5](https://github.com/coachcare/sdk/compare/v1.34.4...v1.34.5) (2018-09-11)


### Bug Fixes

* **FRON-454:** revert backend parameter change ([f5cd23c](https://github.com/coachcare/sdk/commit/f5cd23c))



<a name="1.34.4"></a>
## [1.34.4](https://github.com/coachcare/sdk/compare/v1.34.3...v1.34.4) (2018-09-10)


### Bug Fixes

* **FRON-454:** updated sleep measurements summary API ([a0dbe1b](https://github.com/coachcare/sdk/commit/a0dbe1b))



<a name="1.34.2"></a>
## [1.34.2](https://github.com/coachcare/sdk/compare/v1.34.1...v1.34.2) (2018-08-27)


### Bug Fixes

* **FRON-443:** trust the measurement sorting of the backend ([c46eda2](https://github.com/coachcare/sdk/commit/c46eda2))



<a name="1.34.1"></a>
## [1.34.1](https://github.com/coachcare/sdk/compare/v1.34.0...v1.34.1) (2018-08-14)


### Bug Fixes

* organization object is returned in all the responses ([1aa90e7](https://github.com/coachcare/sdk/commit/1aa90e7))



<a name="1.34.0"></a>
# [1.34.0](https://github.com/coachcare/sdk/compare/v1.33.9...v1.34.0) (2018-08-13)



<a name="1.33.9"></a>
## [1.33.9](https://github.com/coachcare/sdk/compare/v1.33.8...v1.33.9) (2018-08-13)



<a name="1.33.8"></a>
## [1.33.8](https://github.com/coachcare/sdk/compare/v1.33.7...v1.33.8) (2018-08-12)


### Bug Fixes

* /access endpoints synced ([4767b52](https://github.com/coachcare/sdk/commit/4767b52))



<a name="1.33.7"></a>
## [1.33.7](https://github.com/coachcare/sdk/compare/v1.33.6...v1.33.7) (2018-08-07)


### Bug Fixes

* synced measurement interfaces ([eb6e783](https://github.com/coachcare/sdk/commit/eb6e783))



<a name="1.33.4"></a>
## [1.33.4](https://github.com/coachcare/sdk/compare/v1.33.3...v1.33.4) (2018-07-31)


### Bug Fixes

* **FRON-191:** removing breaking code ([65b5022](https://github.com/coachcare/sdk/commit/65b5022))



<a name="1.33.3"></a>
## [1.33.3](https://github.com/coachcare/sdk/compare/v1.33.2...v1.33.3) (2018-07-31)


### Features

* **exercise:** add patch method ([#255](https://github.com/coachcare/sdk/issues/255)) ([7ae4556](https://github.com/coachcare/sdk/commit/7ae4556))



<a name="1.33.2"></a>
## [1.33.2](https://github.com/coachcare/sdk/compare/v1.33.1...v1.33.2) (2018-07-31)



<a name="1.33.1"></a>
## [1.33.1](https://github.com/coachcare/sdk/compare/v1.33.0...v1.33.1) (2018-07-30)


### Bug Fixes

* improve error message retrieval on ApiService ([e50e204](https://github.com/coachcare/sdk/commit/e50e204))



<a name="1.33.0"></a>
# [1.33.0](https://github.com/coachcare/sdk/compare/v1.32.4...v1.33.0) (2018-07-29)


### Bug Fixes

* **schedule:** updated interfaces and responses ([7c96fb7](https://github.com/coachcare/sdk/commit/7c96fb7))


### Features

* **content:** completion of getSingle and addition of getList ([c76407f](https://github.com/coachcare/sdk/commit/c76407f))
* **content:** initial generated providers for the Content module ([a793fda](https://github.com/coachcare/sdk/commit/a793fda))
* **FRON-369:** Content microprovider added ([#253](https://github.com/coachcare/sdk/issues/253)) ([afd82b0](https://github.com/coachcare/sdk/commit/afd82b0))



<a name="1.32.4"></a>
## [1.32.4](https://github.com/coachcare/sdk/compare/v1.32.3...v1.32.4) (2018-07-25)


### Features

* added Pagination parameters on GetAllExerciseRequest ([#252](https://github.com/coachcare/sdk/issues/252)) ([fb8e35b](https://github.com/coachcare/sdk/commit/fb8e35b))



<a name="1.32.3"></a>
## [1.32.3](https://github.com/coachcare/sdk/compare/v1.32.2...v1.32.3) (2018-07-20)


### Bug Fixes

* synced ExerciseAssociation with the backend fix ([97f0c3b](https://github.com/coachcare/sdk/commit/97f0c3b))



<a name="1.32.2"></a>
## [1.32.2](https://github.com/coachcare/sdk/compare/v1.32.1...v1.32.2) (2018-07-19)



<a name="1.32.1"></a>
## [1.32.1](https://github.com/coachcare/sdk/compare/v1.32.0...v1.32.1) (2018-07-19)


### Features

* add icon to ExerciseAssociation ([#250](https://github.com/coachcare/sdk/issues/250)) ([01ed7bb](https://github.com/coachcare/sdk/commit/01ed7bb))



<a name="1.32.0"></a>
# [1.32.0](https://github.com/coachcare/sdk/compare/v1.31.7...v1.32.0) (2018-07-18)


### Features

* **exercise:** generated code with new paradigm added ([44bedb1](https://github.com/coachcare/sdk/commit/44bedb1))



<a name="1.31.7"></a>
## [1.31.7](https://github.com/coachcare/sdk/compare/v1.31.5...v1.31.7) (2018-07-16)


### Features

* add support for Healthkit ([#248](https://github.com/coachcare/sdk/issues/248)) ([167bb1b](https://github.com/coachcare/sdk/commit/167bb1b))



<a name="1.31.7"></a>
## [1.31.7](https://github.com/coachcare/sdk/compare/v1.31.5...v1.31.7) (2018-07-16)


### Features

* add support for Healthkit ([#248](https://github.com/coachcare/sdk/issues/248)) ([167bb1b](https://github.com/coachcare/sdk/commit/167bb1b))



<a name="1.31.5"></a>
## [1.31.5](https://github.com/coachcare/sdk/compare/v1.31.4...v1.31.5) (2018-07-12)


### Features

* **register:** support for parentOrganizationId on clinic registration ([3f7bd81](https://github.com/coachcare/sdk/commit/3f7bd81))



<a name="1.31.4"></a>
## [1.31.4](https://github.com/coachcare/sdk/compare/v1.31.3...v1.31.4) (2018-07-07)


### Features

* **MOB-451:** support fetch of last authenticated and synced date ([#247](https://github.com/coachcare/sdk/issues/247)) ([6b833cf](https://github.com/coachcare/sdk/commit/6b833cf))



<a name="1.31.3"></a>
## [1.31.3](https://github.com/coachcare/sdk/compare/v1.31.2...v1.31.3) (2018-07-06)



<a name="1.31.2"></a>
## [1.31.2](https://github.com/coachcare/sdk/compare/v1.31.1...v1.31.2) (2018-06-30)


### Bug Fixes

* **affiliation:** update association moved to PATCH ([ed2dae0](https://github.com/coachcare/sdk/commit/ed2dae0))



<a name="1.31.1"></a>
## [1.31.1](https://github.com/coachcare/sdk/compare/v1.31.0...v1.31.1) (2018-06-23)


### Bug Fixes

* **affiliation:** update association synced ([e6a997f](https://github.com/coachcare/sdk/commit/e6a997f))



<a name="1.31.0"></a>
# [1.31.0](https://github.com/coachcare/sdk/compare/v1.30.3...v1.31.0) (2018-06-16)


### Features

* DieterDashboardSummary.init now returns a Promise ([c9cee1b](https://github.com/coachcare/sdk/commit/c9cee1b))



<a name="1.30.3"></a>
## [1.30.3](https://github.com/coachcare/sdk/compare/v1.30.2...v1.30.3) (2018-06-13)


### Bug Fixes

* **MOB-198:** support for isLocal on Food.fetchSingleIngredient ([#243](https://github.com/coachcare/sdk/issues/243)) ([9d748e5](https://github.com/coachcare/sdk/commit/9d748e5))



<a name="1.30.2"></a>
## [1.30.2](https://github.com/coachcare/sdk/compare/v1.30.1...v1.30.2) (2018-06-13)


### Features

* **user:** User module upgraded with v2 methods ([fae90f4](https://github.com/coachcare/sdk/commit/fae90f4))



<a name="1.30.1"></a>
## [1.30.1](https://github.com/coachcare/sdk/compare/v1.30.0...v1.30.1) (2018-06-12)


### Features

* **session:** Session module indexed and completed ([c2f5c73](https://github.com/coachcare/sdk/commit/c2f5c73))



<a name="1.30.0"></a>
# [1.30.0](https://github.com/coachcare/sdk/compare/v1.24.5...v1.30.0) (2018-06-12)


### Bug Fixes

* **MOB-288:** added acetonePpm to the final FetchBodyMeasurementResponse ([83f2eec](https://github.com/coachcare/sdk/commit/83f2eec))


### Features

* **MOB-288:** added acetonePpm to body measurement response ([#242](https://github.com/coachcare/sdk/issues/242)) ([8d68e1f](https://github.com/coachcare/sdk/commit/8d68e1f))



<a name="1.24.5"></a>
## [1.24.5](https://github.com/coachcare/sdk/compare/v1.24.4...v1.24.5) (2018-05-31)


### Bug Fixes

* DieterDashboardSummary initial activityLevel set ([#241](https://github.com/coachcare/sdk/issues/241)) ([752fce6](https://github.com/coachcare/sdk/commit/752fce6))



<a name="1.24.5"></a>
## [1.24.5](https://github.com/coachcare/sdk/compare/v1.24.4...v1.24.5) (2018-05-31)



<a name="1.24.4"></a>
## [1.24.4](https://github.com/coachcare/sdk/compare/v1.24.3...v1.24.4) (2018-05-27)


### Features

* **BodyMeasurement:** added acetonePpm to body summary data ([#238](https://github.com/coachcare/sdk/issues/238)) ([165bd78](https://github.com/coachcare/sdk/commit/165bd78))



<a name="1.24.3"></a>
## [1.24.3](https://github.com/coachcare/sdk/compare/v1.24.2...v1.24.3) (2018-05-24)


### Bug Fixes

* DieterDashboardSummary init member values ([bfab1d2](https://github.com/coachcare/sdk/commit/bfab1d2))



<a name="1.24.2"></a>
## [1.24.2](https://github.com/coachcare/sdk/compare/v1.24.1...v1.24.2) (2018-05-23)


### Bug Fixes

* **FRON-197:** updated AuthAvailableResponse for the available services ([#237](https://github.com/coachcare/sdk/issues/237)) ([33cf69b](https://github.com/coachcare/sdk/commit/33cf69b))



<a name="1.24.1"></a>
## [1.24.1](https://github.com/coachcare/sdk/compare/v1.24.0...v1.24.1) (2018-05-18)


### Features

* **API-434:** sync /access sort parameter ([f5e23bb](https://github.com/coachcare/sdk/commit/f5e23bb))



<a name="1.24.0"></a>
# [1.24.0](https://github.com/coachcare/sdk/compare/v1.23.0...v1.24.0) (2018-05-18)


### Features

* **FRON-186:** Authentication provider for third party integrations ([#236](https://github.com/coachcare/sdk/issues/236)) ([70949c7](https://github.com/coachcare/sdk/commit/70949c7))



<a name="1.23.0"></a>
# [1.23.0](https://github.com/coachcare/sdk/compare/v1.22.1...v1.23.0) (2018-05-18)


### Bug Fixes

* **FoodKey:** disabling created keys ([da5df03](https://github.com/coachcare/sdk/commit/da5df03))
* **FoodKey:** KeyOrganization.icon added, interfaces fixed ([e51e896](https://github.com/coachcare/sdk/commit/e51e896))


### Features

* **FRON-188:** sdk support of the BMR activity level ([c4b9e5f](https://github.com/coachcare/sdk/commit/c4b9e5f))



<a name="1.22.1"></a>
## [1.22.1](https://github.com/coachcare/sdk/compare/v1.22.0...v1.22.1) (2018-05-16)


### Bug Fixes

* add Notes service to the exported services ([d707bf8](https://github.com/coachcare/sdk/commit/d707bf8))



<a name="1.22.0"></a>
# [1.22.0](https://github.com/coachcare/sdk/compare/v1.21.9...v1.22.0) (2018-05-16)


### Bug Fixes

* **FRON-182:** Conference module sync ([#234](https://github.com/coachcare/sdk/issues/234)) ([e14bd73](https://github.com/coachcare/sdk/commit/e14bd73))
* **notes:** date parameter doc-mismatch ([1ad674b](https://github.com/coachcare/sdk/commit/1ad674b))


### Features

* **accountv2:** ClientData.bmr sync, refs FRON-188 ([19421cb](https://github.com/coachcare/sdk/commit/19421cb))
* **food:** free text field on consumed meals added ([4a73140](https://github.com/coachcare/sdk/commit/4a73140))
* **MOB-305:** notes v2.0 endpoints support ([#233](https://github.com/coachcare/sdk/issues/233)) ([93a3d15](https://github.com/coachcare/sdk/commit/93a3d15))



<a name="1.21.9"></a>
## [1.21.9](https://github.com/coachcare/sdk/compare/v1.21.8...v1.21.9) (2018-05-15)


### Features

* **MOB-300:** adding calorie to GoalObject.goal possible values ([#229](https://github.com/coachcare/sdk/issues/229)) ([4f0ae60](https://github.com/coachcare/sdk/commit/4f0ae60))



<a name="1.21.8"></a>
## [1.21.8](https://github.com/coachcare/sdk/compare/v1.21.7...v1.21.8) (2018-05-14)


### Bug Fixes

* **MOB-281:** add BodyMeasurementRequest aggregation parameter ([#232](https://github.com/coachcare/sdk/issues/232)) ([5a973a1](https://github.com/coachcare/sdk/commit/5a973a1))


### Features

* added conference flag on OrgPreferenceResponse ([#231](https://github.com/coachcare/sdk/issues/231)) ([e404b56](https://github.com/coachcare/sdk/commit/e404b56))



<a name="1.21.7"></a>
## [1.21.7](https://github.com/coachcare/sdk/compare/v1.21.6...v1.21.7) (2018-05-10)


### Bug Fixes

* improved prefix of the Alert Org preferences ([a3975c6](https://github.com/coachcare/sdk/commit/a3975c6))



<a name="1.21.6"></a>
## [1.21.6](https://github.com/coachcare/sdk/compare/v1.21.5...v1.21.6) (2018-05-09)



<a name="1.21.5"></a>
## [1.21.5](https://github.com/coachcare/sdk/compare/v1.21.4...v1.21.5) (2018-05-09)


### Bug Fixes

* sync Alerts.fetchNotifications request adding triggeredBy ([a117a90](https://github.com/coachcare/sdk/commit/a117a90))



<a name="1.21.4"></a>
## [1.21.4](https://github.com/coachcare/sdk/compare/v1.21.3...v1.21.4) (2018-05-05)


### Bug Fixes

* AccountV2.getSingle sync with the latest backend ([800b1d3](https://github.com/coachcare/sdk/commit/800b1d3))



<a name="1.21.3"></a>
## [1.21.3](https://github.com/coachcare/sdk/compare/v1.21.2...v1.21.3) (2018-05-05)


### Bug Fixes

* AccountV2.getPreferences now fails on 404 ([19f9240](https://github.com/coachcare/sdk/commit/19f9240))



<a name="1.21.2"></a>
## [1.21.2](https://github.com/coachcare/sdk/compare/v1.21.1...v1.21.2) (2018-05-03)


### Bug Fixes

* corrected AlertType field ([#228](https://github.com/coachcare/sdk/issues/228)) ([bcdde3c](https://github.com/coachcare/sdk/commit/bcdde3c))



<a name="1.21.1"></a>
## [1.21.1](https://github.com/coachcare/sdk/compare/v1.21.0...v1.21.1) (2018-05-02)


### Bug Fixes

* NotificationRequest parameters sync ([96c9bc0](https://github.com/coachcare/sdk/commit/96c9bc0))



<a name="1.21.0"></a>
# [1.21.0](https://github.com/coachcare/sdk/compare/v1.20.1...v1.21.0) (2018-05-02)


### Features

* **FRON-158:** Alerts module with preference endpoints ([#227](https://github.com/coachcare/sdk/issues/227)) ([ecbb71a](https://github.com/coachcare/sdk/commit/ecbb71a))



<a name="1.20.1"></a>
## [1.20.1](https://github.com/coachcare/sdk/compare/v1.20.0...v1.20.1) (2018-05-02)


### Bug Fixes

* **food:** add meal request now supports more than one ingredient ([#226](https://github.com/coachcare/sdk/issues/226)) ([ca89c0d](https://github.com/coachcare/sdk/commit/ca89c0d))



<a name="1.20.0"></a>
# [1.20.0](https://github.com/coachcare/sdk/compare/v1.19.6...v1.20.0) (2018-04-26)


### Bug Fixes

* test fixed ([faa62f3](https://github.com/coachcare/sdk/commit/faa62f3))



<a name="1.19.4"></a>

## [1.19.4](https://github.com/coachcare/sdk/compare/v1.19.3...v1.19.4) (2018-04-18)

### Bug Fixes

*   adding max = all to request params ([#223](https://github.com/coachcare/sdk/issues/223)) ([472c0b8](https://github.com/coachcare/sdk/commit/472c0b8))

<a name="1.19.3"></a>

## [1.19.3](https://github.com/coachcare/sdk/compare/v1.19.2...v1.19.3) (2018-04-18)

### Features

*   adding max all as a request param ([#222](https://github.com/coachcare/sdk/issues/222)) ([50e6699](https://github.com/coachcare/sdk/commit/50e6699))
*   adding meal plans parameter for recipeOnly ([#221](https://github.com/coachcare/sdk/issues/221)) ([7b9bfb2](https://github.com/coachcare/sdk/commit/7b9bfb2))

<a name="1.19.2"></a>

## [1.19.2](https://github.com/coachcare/sdk/compare/v1.19.1...v1.19.2) (2018-04-17)

<a name="1.19.1"></a>

## [1.19.1](https://github.com/coachcare/sdk/compare/v1.19.0...v1.19.1) (2018-04-13)

### Bug Fixes

*   added Phase.fetchHistory paginate parameter ([#214](https://github.com/coachcare/sdk/issues/214)) ([488c16a](https://github.com/coachcare/sdk/commit/488c16a))
*   conditionally sort measurements by id ([#220](https://github.com/coachcare/sdk/issues/220)) ([fe1ca59](https://github.com/coachcare/sdk/commit/fe1ca59))

<a name="1.19.0"></a>

# [1.19.0](https://github.com/coachcare/sdk/compare/v1.18.0...v1.19.0) (2018-04-11)

### Features

*   **FRON-140:** patient count streamlined report ([#218](https://github.com/coachcare/sdk/issues/218)) ([4f81d05](https://github.com/coachcare/sdk/commit/4f81d05))
*   **FRON-142:** organization preferences endpoints ([#219](https://github.com/coachcare/sdk/issues/219)) ([98133a0](https://github.com/coachcare/sdk/commit/98133a0))

<a name="1.18.1"></a>

## [1.18.1](https://github.com/coachcare/sdk/compare/v1.18.0...v1.18.1) (2018-04-09)

<a name="1.17.10"></a>

## [1.17.10](https://github.com/coachcare/sdk/compare/v1.17.9...v1.17.10) (2018-03-22)

### Bug Fixes

*   Number replaced by the number primitive ([117154e](https://github.com/coachcare/sdk/commit/117154e))

<a name="1.17.9"></a>

## [1.17.9](https://github.com/coachcare/sdk/compare/v1.17.8...v1.17.9) (2018-03-22)

### Bug Fixes

*   misc fixes to interfaces and methods ([6d35305](https://github.com/coachcare/sdk/commit/6d35305))

<a name="1.17.6"></a>

## [1.17.6](https://github.com/coachcare/sdk/compare/v1.17.5...v1.17.6) (2018-03-19)

### Bug Fixes

*   messaging module fixed ([17dfb43](https://github.com/coachcare/sdk/commit/17dfb43))

<a name="1.17.5"></a>

## [1.17.5](https://github.com/coachcare/sdk/compare/v1.17.4...v1.17.5) (2018-03-19)

### Bug Fixes

*   moved plans to meal objects ([#198](https://github.com/coachcare/sdk/issues/198)) ([3cd52b3](https://github.com/coachcare/sdk/commit/3cd52b3))

<a name="1.17.4"></a>

## [1.17.4](https://github.com/coachcare/sdk/compare/v1.17.3...v1.17.4) (2018-03-17)

### Bug Fixes

*   **FRON-101:** Sleep and Weight Report changes ([#197](https://github.com/coachcare/sdk/issues/197)) ([fb2a33d](https://github.com/coachcare/sdk/commit/fb2a33d))

<a name="1.17.3"></a>

## [1.17.3](https://github.com/coachcare/sdk/compare/v1.17.2...v1.17.3) (2018-03-16)

### Bug Fixes

*   **BUG-438:** added meal plans service ([#196](https://github.com/coachcare/sdk/issues/196)) ([c71a0df](https://github.com/coachcare/sdk/commit/c71a0df))
*   SummaryData.dieterSummary startingMeasurement.find is not a function ([#195](https://github.com/coachcare/sdk/issues/195)) ([24638bd](https://github.com/coachcare/sdk/commit/24638bd))

<a name="1.17.1"></a>

## [1.17.1](https://github.com/coachcare/sdk/compare/v1.17.0...v1.17.1) (2018-03-15)

### Features

*   **access:** reset-password endpoints updated to v2 ([86b4b4c](https://github.com/coachcare/sdk/commit/86b4b4c))

<a name="1.17.0"></a>

# [1.17.0](https://github.com/coachcare/sdk/compare/v1.16.6...v1.17.0) (2018-03-13)

<a name="1.16.6"></a>

## [1.16.6](https://github.com/coachcare/sdk/compare/v1.16.5...v1.16.6) (2018-03-08)

### Features

*   Sessions module v2 ([bb77f41](https://github.com/coachcare/sdk/commit/bb77f41))

<a name="1.16.4"></a>

## [1.16.4](https://github.com/coachcare/sdk/compare/v1.16.3...v1.16.4) (2018-03-08)

<a name="1.16.0"></a>

# [1.16.0](https://github.com/coachcare/sdk/compare/v1.15.4...v1.16.0) (2018-03-05)

### Bug Fixes

*   misc fixes all around ([eb53138](https://github.com/coachcare/sdk/commit/eb53138))

<a name="1.13.2"></a>

## [1.13.2](https://github.com/coachcare/sdk/compare/v1.13.1...v1.13.2) (2018-01-25)

### Bug Fixes

*   organization getDescendants method fixed ([987930a](https://github.com/coachcare/sdk/commit/987930a))

<a name="1.13.1"></a>

## [1.13.1](https://github.com/coachcare/sdk/compare/v1.13.0...v1.13.1) (2018-01-25)

### Bug Fixes

*   add missing cpx package for the prepublish script ([890b34d](https://github.com/coachcare/sdk/commit/890b34d))

<a name="1.13.0"></a>

# [1.13.0](https://github.com/coachcare/sdk/compare/v1.12.9...v1.13.0) (2018-01-24)

### Features

*   release and publish scripts ([7695449](https://github.com/coachcare/sdk/commit/7695449))
