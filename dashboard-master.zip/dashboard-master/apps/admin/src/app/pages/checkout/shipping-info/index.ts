export * from './shipping-info.component'
