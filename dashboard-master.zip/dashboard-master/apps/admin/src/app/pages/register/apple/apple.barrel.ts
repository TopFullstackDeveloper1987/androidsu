import { RegisterApplePageComponent } from './apple.component'
import { TranslationsComponents } from './contents'

export const RegisterAppleComponents = [
  ...TranslationsComponents,
  RegisterApplePageComponent
]
