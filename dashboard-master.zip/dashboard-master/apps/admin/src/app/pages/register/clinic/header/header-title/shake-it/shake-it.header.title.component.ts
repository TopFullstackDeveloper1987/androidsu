import { Component } from '@angular/core'

@Component({
  selector: 'ccr-register-clinic-shake-it-header-title',
  templateUrl: './shake-it.header.title.component.html'
})
export class ShakeItHeaderTitleComponent {}
