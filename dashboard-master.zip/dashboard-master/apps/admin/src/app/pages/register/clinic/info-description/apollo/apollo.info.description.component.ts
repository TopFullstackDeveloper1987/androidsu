import { Component } from '@angular/core'

@Component({
  selector: 'ccr-register-clinic-apollo-header-title',
  templateUrl: './apollo.info.description.component.html'
})
export class ApolloInfoDescriptionComponent {}
