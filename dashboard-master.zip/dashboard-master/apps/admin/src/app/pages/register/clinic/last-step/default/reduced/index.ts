export * from './default-reduced.last-step.component'
