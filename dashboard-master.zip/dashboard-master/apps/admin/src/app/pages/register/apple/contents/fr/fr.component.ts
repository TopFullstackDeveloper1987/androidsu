import { Component } from '@angular/core'

@Component({
  selector: 'ccr-page-register-apple-fr',
  templateUrl: './fr.component.html'
})
export class FRComponent {
  constructor() {}
}
