import { Component } from '@angular/core'

@Component({
  selector: 'ccr-page-register-apple-da',
  templateUrl: './da.component.html'
})
export class DAComponent {
  constructor() {}
}
