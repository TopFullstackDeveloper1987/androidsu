import { Component } from '@angular/core'

@Component({
  selector: 'ccr-page-register-apple-es',
  templateUrl: './es.component.html'
})
export class ESComponent {
  constructor() {}
}
