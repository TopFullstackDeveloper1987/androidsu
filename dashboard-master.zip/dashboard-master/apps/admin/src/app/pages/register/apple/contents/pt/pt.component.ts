import { Component } from '@angular/core'

@Component({
  selector: 'ccr-page-register-apple-pt',
  templateUrl: './pt.component.html'
})
export class PTComponent {
  constructor() {}
}
