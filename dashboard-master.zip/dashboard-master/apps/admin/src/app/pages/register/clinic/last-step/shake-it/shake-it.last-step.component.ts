import { Component } from '@angular/core'

@Component({
  selector: 'ccr-page-register-clinic-shake-it-last-step',
  templateUrl: './shake-it.last-step.component.html'
})
export class ShakeItLastStepComponent {}
