import { Component } from '@angular/core'

@Component({
  selector: 'ccr-page-register-clinic-apollo-last-step',
  templateUrl: './apollo.last-step.component.html'
})
export class ApolloLastStepComponent {}
