export * from './apollo/apollo.info.description.component'
export * from './default/default.info.description.component'
export * from './inhealth/inhealth.info.description.component'
export * from './shake-it/shake-it.info.description.component'
