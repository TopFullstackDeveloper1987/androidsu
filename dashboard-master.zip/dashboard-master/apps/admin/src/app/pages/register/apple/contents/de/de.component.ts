import { Component } from '@angular/core'

@Component({
  selector: 'ccr-page-register-apple-de',
  templateUrl: './de.component.html'
})
export class DEComponent {
  constructor() {}
}
