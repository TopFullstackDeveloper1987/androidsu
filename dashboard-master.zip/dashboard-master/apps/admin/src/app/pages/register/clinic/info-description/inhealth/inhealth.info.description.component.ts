import { Component } from '@angular/core'

@Component({
  selector: 'ccr-register-clinic-inhealth-header-title',
  templateUrl: './inhealth.info.description.component.html'
})
export class InHealthInfoDescriptionComponent {}
