export * from './default-clinic-packages.component'
