import { Component } from '@angular/core'

@Component({
  selector: 'ccr-page-register-apple-it',
  templateUrl: './it.component.html'
})
export class ITComponent {
  constructor() {}
}
