import { Component } from '@angular/core'

@Component({
  selector: 'ccr-page-register-apple-en',
  templateUrl: './en.component.html'
})
export class ENComponent {
  constructor() {}
}
