import { Component } from '@angular/core'

@Component({
  selector: 'ccr-page-register-apple-he',
  templateUrl: './he.component.html'
})
export class HEComponent {
  constructor() {}
}
