import { Component } from '@angular/core'

@Component({
  selector: 'ccr-page-register-clinic-itg-last-step',
  templateUrl: './itg.last-step.component.html'
})
export class ITGLastStepComponent {}
