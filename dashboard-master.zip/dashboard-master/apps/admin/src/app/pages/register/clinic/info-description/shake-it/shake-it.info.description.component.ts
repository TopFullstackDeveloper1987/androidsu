import { Component } from '@angular/core'

@Component({
  selector: 'ccr-register-clinic-shake-it-info-description',
  templateUrl: './shake-it.info.description.component.html'
})
export class ShakeItInfoDescriptionComponent {}
