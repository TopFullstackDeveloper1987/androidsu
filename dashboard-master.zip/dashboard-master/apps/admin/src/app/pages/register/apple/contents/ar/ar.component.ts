import { Component } from '@angular/core'

@Component({
  selector: 'ccr-page-register-apple-ar',
  templateUrl: './ar.component.html'
})
export class ARComponent {
  constructor() {}
}
