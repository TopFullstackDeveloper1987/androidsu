import { Component } from '@angular/core'

@Component({
  selector: 'ccr-register-clinic-robard-header',
  templateUrl: './robard.header.component.html',
  styleUrls: ['./robard.header.component.scss']
})
export class RobardHeaderComponent {}
