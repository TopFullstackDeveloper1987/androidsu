import { BillingSummaryItemComponent, ClinicPlanSelectorComponent } from './'

export const ClinicPackagesSharedComponents = [
  BillingSummaryItemComponent,
  ClinicPlanSelectorComponent
]
