import { Component } from '@angular/core'

@Component({
  selector: 'ccr-register-clinic-apollo-header-title',
  templateUrl: './apollo.header.title.component.html'
})
export class ApolloHeaderTitleComponent {}
