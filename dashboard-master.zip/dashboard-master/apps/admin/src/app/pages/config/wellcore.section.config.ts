import { SectionConfigDetails } from './section.config'

export const WellCoreSectionConfig: SectionConfigDetails = {
  LOGIN: {
    SHOW_REGISTER_NEW_COMPANY: false,
    USE_COOKIE_BASED_SESSION: false
  }
}
