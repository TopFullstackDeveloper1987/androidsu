import { SectionConfigDetails } from './section.config'

export const BariatricAdvantageSectionConfig: SectionConfigDetails = {
  REGISTER: {
    SELF_REGISTER: false
  }
}
