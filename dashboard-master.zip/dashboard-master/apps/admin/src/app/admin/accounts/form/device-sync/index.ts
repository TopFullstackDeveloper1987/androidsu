export * from './device-sync.component'
