import { Component } from '@angular/core'

@Component({
  selector: 'ccr-measurements',
  templateUrl: './measurements.component.html'
})
export class MeasurementsComponent {}
