export * from './app-ids.component'
