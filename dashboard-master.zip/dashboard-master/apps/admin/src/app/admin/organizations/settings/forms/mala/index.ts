export * from './mala.component'
