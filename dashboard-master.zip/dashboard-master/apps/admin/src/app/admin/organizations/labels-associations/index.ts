export * from './labels-associations.component'
