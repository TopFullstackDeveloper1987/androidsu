export * from './colors.component'
