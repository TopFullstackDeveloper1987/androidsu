import { Component, forwardRef, Input, OnInit } from '@angular/core'
import { FormBuilder, FormGroup } from '@angular/forms'
import {
  CareManagementPlanEntry,
  CareManagementPreference,
  Entity
} from '@coachcare/sdk'
import { marker as _ } from '@biesbjerg/ngx-translate-extract-marker'
import { BINDFORM_TOKEN } from '@coachcare/common/directives'
import {
  CareManagementFeaturePref,
  NotifierService
} from '@coachcare/common/services'
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy'
import { debounceTime, Subject } from 'rxjs'
import { SelectorOption } from '@coachcare/common/shared'

enum TransmissionTypes {
  Email = 1,
  Push = 2,
  MissingDataPointGeneration = 3
}

enum ServiceTypeId {
  RPM = '1',
  CCM = '2',
  RTM = '3',
  PCM = '4',
  BHI = '5'
}

const PLAN_AVAILABLE_SERVICE_IDS = [ServiceTypeId.RPM, ServiceTypeId.RTM]
const DISALLOWED_PLANS_MAP: { [serviceType: string]: string[] } = {
  [ServiceTypeId.RPM]: ['7'],
  [ServiceTypeId.RTM]: []
}

@UntilDestroy()
@Component({
  selector: 'ccr-care-preference',
  templateUrl: './care-preference.component.html',
  styleUrls: ['./care-preference.component.scss'],
  providers: [
    {
      provide: BINDFORM_TOKEN,
      useExisting: forwardRef(() => CarePreferenceComponent)
    }
  ]
})
export class CarePreferenceComponent implements OnInit {
  @Input() orgId: string
  @Input() allDataTransmissions: string[] = []
  @Input() carePlans: CareManagementPlanEntry[] = []
  @Input()
  set pref(carePref: CareManagementFeaturePref) {
    this._carePref = carePref
  }

  get pref(): CareManagementFeaturePref {
    return this._carePref
  }

  get requiresTransmission(): boolean {
    return this.allDataTransmissions.includes(this.pref.serviceType.id)
  }

  get requiredPlans() {
    return PLAN_AVAILABLE_SERVICE_IDS.includes(
      this.pref.serviceType.id as ServiceTypeId
    )
  }

  get availablePlans() {
    if (
      !PLAN_AVAILABLE_SERVICE_IDS.includes(
        this.pref.serviceType.id as ServiceTypeId
      )
    ) {
      return []
    }

    return this.carePlans.filter(
      (plan) =>
        !(DISALLOWED_PLANS_MAP[this.pref.serviceType.id] || []).includes(
          plan.id
        )
    )
  }

  public form: FormGroup
  private _carePref: CareManagementFeaturePref
  private carePref$ = new Subject<CareManagementFeaturePref>()
  public inheritedOrg: Entity
  public inherited: boolean = true
  public careManagementTypes: SelectorOption[] = [
    {
      value: 'self-service',
      viewValue: _('GLOBAL.SELF_SERVICE')
    },
    {
      value: 'managed',
      viewValue: _('GLOBAL.MANAGED')
    }
  ]

  public mapTransmissionType = (type: string): number[] => {
    switch (type) {
      case 'email-and-push':
        return [TransmissionTypes.Email, TransmissionTypes.Push]
      case 'email':
        return [TransmissionTypes.Email]
      case 'push':
        return [TransmissionTypes.Push]
      case 'missing-data-point-generation':
        return [TransmissionTypes.MissingDataPointGeneration]
      default:
        return [TransmissionTypes.Email, TransmissionTypes.Push]
    }
  }

  public mapTransmissionTypeToValue = (
    type: number[] | undefined | null
  ): 'email-and-push' | 'email' | 'push' | 'missing-data-point-generation' => {
    const types = type ?? []
    if (types.length > 1) {
      return 'email-and-push'
    }
    const [selected] = types
    switch (selected) {
      case TransmissionTypes.Email:
        return 'email'
      case TransmissionTypes.Push:
        return 'push'
      case TransmissionTypes.MissingDataPointGeneration:
        return 'missing-data-point-generation'
      default:
        return 'email-and-push'
    }
  }

  public transmissionTypes: SelectorOption[] = [
    {
      value: 'email-and-push',
      viewValue: _('GLOBAL.EMAIL_AND_PUSH')
    },
    {
      value: 'email',
      viewValue: _('GLOBAL.EMAIL_ONLY')
    },
    {
      value: 'push',
      viewValue: _('GLOBAL.PUSH_ONLY')
    },
    {
      value: 'missing-data-point-generation',
      viewValue: _('GLOBAL.MISSING_DATA_POINT_GENERATION')
    }
  ]

  constructor(
    private carePreference: CareManagementPreference,
    private notifier: NotifierService,
    private fb: FormBuilder
  ) {}

  public ngOnInit(): void {
    this.createForm()
    this.patchValues()
    this.carePref$.pipe(untilDestroyed(this)).subscribe((pref) => {
      this._carePref = pref
      this.patchValues()
    })
    this.form.valueChanges
      .pipe(untilDestroyed(this), debounceTime(1000))
      .subscribe(() => this.onSubmit())
  }

  private async onSubmit() {
    const {
      active,
      deviceSetupNotification,
      automatedTimeTracking,
      billing,
      monitoring
    } = this.form.value
    const deviceSetupNotificationValue =
      deviceSetupNotification === false ? 'disabled' : 'enabled'
    const automatedTimeTrackingValue =
      automatedTimeTracking === false ? 'disabled' : 'enabled'
    const transmissionValue = this.mapTransmissionType(
      this.form.value.transmission
    )

    const plans = Object.entries(this.form.getRawValue().plans)
      .filter(([key, value]) => value === true)
      .map(([key, value]) => Number(key))

    try {
      if (active === 'inherit') {
        if (
          !this.pref.preference ||
          this.pref.preference.organization.id !== this.orgId
        ) {
          return
        }

        await this.carePreference.deleteCareManagementPreference(
          this.pref.preference.id
        )
      } else {
        if (this.requiredPlans && !plans.length) {
          throw new Error('At least one plan must be selected')
        }

        if (
          !this.pref.preference ||
          this.pref.preference.organization.id !== this.orgId
        ) {
          await this.carePreference.createCareManagementPreference({
            organization: this.orgId,
            isActive: active,
            serviceType: this.pref.serviceType.id,
            deviceSetupNotification: deviceSetupNotificationValue,
            automatedTimeTracking: automatedTimeTrackingValue,
            billing,
            monitoring,
            dataTransmissionTypes: transmissionValue,
            plans: this.requiredPlans ? plans : undefined
          })
        } else {
          await this.carePreference.updateCareManagementPreference({
            id: this.pref.preference.id,
            isActive: active,
            deviceSetupNotification: deviceSetupNotificationValue,
            automatedTimeTracking: automatedTimeTrackingValue,
            billing,
            monitoring,
            dataTransmissionTypes: transmissionValue,
            plans: this.requiredPlans ? plans : undefined
          })
        }
      }

      await this.resolveCarePreference()
      this.notifier.success(_('NOTIFY.SUCCESS.SETTINGS_UPDATED'))
    } catch (error) {
      this.notifier.error(error)
      this.carePref$.next(this.pref)
    }
  }

  private async resolveCarePreference() {
    const res = await this.carePreference.getAllCareManagementPreferences({
      organization: this.orgId,
      serviceType: this.pref.serviceType.id
    })

    this.carePref$.next({
      serviceType: this.pref.serviceType,
      preference: res.data[0]
    })
  }

  private createForm(): void {
    this.form = this.fb.group({
      active: ['inherit'],
      deviceSetupNotification: [true],
      automatedTimeTracking: [true],
      billing: ['self-service'],
      monitoring: ['self-service'],
      transmission: ['email-and-push'],
      plans: this.fb.group({})
    })
  }

  private patchValues(): void {
    this.inheritedOrg =
      this.pref.preference?.organization.id === this.orgId
        ? null
        : this.pref.preference?.organization
    this.form.patchValue(
      {
        active:
          this.pref.preference &&
          this.pref.preference.organization.id === this.orgId
            ? this.pref.preference.isActive
            : 'inherit',
        deviceSetupNotification: this.pref.preference?.deviceSetupNotification
          ? this.pref.preference?.deviceSetupNotification === 'enabled'
          : true,
        automatedTimeTracking: this.pref.preference?.automatedTimeTracking
          ? this.pref.preference?.automatedTimeTracking === 'enabled'
          : true,
        billing: this.pref.preference?.billing || 'self-service',
        monitoring: this.pref.preference?.monitoring || 'self-service',
        transmission: this.mapTransmissionTypeToValue(
          this.pref.preference?.dataTransmissionTypes?.map((transmission) =>
            Number(transmission.id)
          )
        )
      },
      { emitEvent: false }
    )

    const plans = this.form.get('plans') as FormGroup

    if (this.availablePlans.length) {
      this.availablePlans.forEach((plan) => {
        let control = plans.get(plan.id)
        const value = this.pref.preference?.plans
          ?.map((p) => p.id)
          ?.includes(plan.id)

        if (control) {
          control.patchValue(value, { emitEvent: false })
        } else {
          control = this.fb.control(
            this.pref.preference?.plans?.map((p) => p.id)?.includes(plan.id)
          )
          plans.addControl(plan.id, control, { emitEvent: false })
        }

        if (this.inheritedOrg) {
          control.disable({ emitEvent: false })
        } else {
          control.enable({ emitEvent: false })
        }
      })
    }

    if (this.inheritedOrg) {
      this.form.controls.deviceSetupNotification.disable({ emitEvent: false })
      this.form.controls.automatedTimeTracking.disable({ emitEvent: false })
      this.form.controls.billing.disable({ emitEvent: false })
      this.form.controls.monitoring.disable({ emitEvent: false })
      this.form.controls.transmission.disable({ emitEvent: false })
    } else {
      this.form.controls.deviceSetupNotification.enable({ emitEvent: false })
      this.form.controls.automatedTimeTracking.enable({ emitEvent: false })
      this.form.controls.billing.enable({ emitEvent: false })
      this.form.controls.monitoring.enable({ emitEvent: false })
      this.form.controls.transmission.enable({ emitEvent: false })
    }
  }
}
