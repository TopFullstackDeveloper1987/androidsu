export * from './basic-info.component'
