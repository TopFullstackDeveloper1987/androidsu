export * from './display.component'
