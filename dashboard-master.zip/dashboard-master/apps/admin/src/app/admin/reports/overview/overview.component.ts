import { Component } from '@angular/core'

@Component({
  selector: 'ccr-report-overview',
  templateUrl: './overview.component.html'
})
export class ReportOverviewComponent {}
