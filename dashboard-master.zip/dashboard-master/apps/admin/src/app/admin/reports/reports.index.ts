import { OverviewComponents } from './overview'

export const ReportsComponents = [...OverviewComponents]

export const ReportsProviders = []
