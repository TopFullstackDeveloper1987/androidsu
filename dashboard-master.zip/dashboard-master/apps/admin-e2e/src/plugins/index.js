const cypressTypeScriptPreprocessor = require('./cy-ts-preprocessor')

module.exports = (on, config) => {
  on('file:preprocessor', cypressTypeScriptPreprocessor)
  on('before:browser:launch', (browser = {}, launchOptions) => {
    launchOptions.args.push('--disable-gpu')

    return launchOptions
  })
  return config
}
