export function verifyActiveOption(section, option) {
  cy.get(`[data-cy="org-settings-section-care-${section}"]`)
    .find(`[data-cy="care-preference-active-option"]`)
    .find('.mat-mdc-select')
    .should('contain', option)
}

export function verifyDeviceSetupNotification(section, element, state) {
  cy.get(`[data-cy="org-settings-section-care-${section}"]`)
    .find('[data-cy="care-preference-device-setup-notification"]')
    .find(element)
    .should(state)
}

export function verifyAutomaticTimeTracking(section, option) {
  cy.get(`[data-cy="org-settings-section-care-${section}"]`)
    .find('[data-cy="care-preference-automated-time-tracking-option"]')
    .find('.mat-mdc-select')
    .should('contain', option)
}

export function verifyBillingType(
  section: string,
  should: string,
  option?: string
) {
  cy.get(`[data-cy="org-settings-section-care-${section}"]`)
    .find('[data-cy="care-preference-billing-option"]')
    .find('.mat-mdc-select')
    .should(should, option)
}

export function verifyMonitoringType(
  section: string,
  should: string,
  option?: string
) {
  cy.get(`[data-cy="org-settings-section-care-${section}"]`)
    .find('[data-cy="care-preference-monitoring-option"]')
    .find('.mat-mdc-select')
    .should(should, option)
}

export function verifyPlans(section: string, should: string, plans?: string[]) {
  cy.get(`[data-cy="org-settings-section-care-${section}"]`)
    .find('[data-cy="care-preference-plans"]')
    .should(should)
    .as('planSection')

  if (plans?.length) {
    cy.get('@planSection').find('mat-checkbox').as('plan')

    for (let i = 0; i < plans.length; i += 1) {
      cy.get('@plan').eq(i).should('contain', plans[i])
    }
  }
}

export function selectPlan(section: string, plan: string) {
  cy.get(`[data-cy="org-settings-section-care-${section}"]`)
    .find('[data-cy="care-preference-plans"]')
    .find('mat-checkbox')
    .contains(plan)
    .click({ force: true })
  cy.tick(5000)
}

export function selectActiveOption(type, option) {
  cy.get(`[data-cy="org-settings-section-care-${type}"]`)
    .find('[data-cy="care-preference-active-option"]')
    .find('.mat-mdc-select')
    .eq(0)
    .click()

  cy.get('.mat-mdc-select-panel').find('mat-option').contains(option).click()

  cy.tick(5000)
}
